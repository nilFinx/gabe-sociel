module BusinessesHelper
  def inline_status_style(business)
    base_style = "font-size:14px;font-weight:600;text-transform:uppercase;padding:5px 10px;border-radius: 15px;color: white;"
  
    case
    when business.pending_business_status?
      "background-color:orange;color:black!important; #{base_style}"
    when business.rejected_business_status?
      "background-color: red; #{base_style}"
    else # Approved
      "background-color: #2AC874; #{base_style}"
    end
  end

  def inline_pro_tier_style(business)
    base_style = "font-size:14px;font-weight:600;text-transform:uppercase;padding:5px 10px;border-radius: 15px;color: white;"
  
    case
    when business.bronze_business_pro_tier?
      "background-color:brown; #{base_style}"
    when business.silver_business_pro_tier?
      "background-color:silver;color:black!important; #{base_style}"
    when business.gold_business_pro_tier?
      "background-color:gold;color:black!important; #{base_style}"
    else # Approved
      ""
    end
  end
  
end
