# frozen_string_literal: true
require 'down'
require 'fileutils'
require 'pp'

module RoutingHelper
  extend ActiveSupport::Concern
  #include Rails.application.routes.url_helpers
  include ActionView::Helpers::AssetTagHelper
  include Webpacker::Helper
  include Redisable

  included do
    def default_url_options
      ActionMailer::Base.default_url_options
    end
  end

  def full_asset_url(source, **options)
    cloudflare_options = options.delete(:cloudflare_options)
    if use_storage?
      source = ActionController::Base.helpers.asset_url(source, options)
      uri = URI.join(root_url, source)
      return(uri.to_s.sub('http://', 'https://'))
    end
    source
  end

  def media_proxy_object(object, subtype = "file", width = nil)    
    if object.is_a?(Account)
      if subtype == "avatar"
        if !object.avatar?
          return 'https://gab.com/avatars/original/missing.png'
        end
        if !object.avatar_cdn_url.nil?
          return object.avatar_cdn_url
        end
        BunnyMigrateWorker.perform_async('Account', object.id)
        return s3_url_by_attachment(object.avatar, :original)
      else
        if !object.header?
          return 'https://gab.com/headers/original/missing.png'
        end
        if !object.header_cdn_url.nil?
          return object.header_cdn_url
        end
        BunnyMigrateWorker.perform_async('Account', object.id)
        return s3_url_by_attachment(object.header, :original)
      end
    end
    if object.is_a?(Group)
      if !object.cover_image?
        return 'https://gab.com/headers/original/gab-cover-placeholder-2.png'
      end
      if subtype == "cover_image" && !object.header_cdn_url.nil?
        return object.header_cdn_url
      end
      BunnyMigrateWorker.perform_async('Group', object.id)
      return s3_url_by_attachment(object.cover_image, :original)
    end
    if object.is_a?(Business)
      if !object.avatar?
        return 'https://gab.com/avatars/original/missing.png'
      end
      if subtype == "avatar" 
        if !object.avatar_cdn_url.nil?
          return object.avatar_cdn_url
        end
        BunnyMigrateWorker.perform_async('Business', object.id)
        return s3_url_by_attachment(object.avatar, :original)
      else
        if !object.cover?
          return 'https://gab.com/headers/original/gab-cover-placeholder-2.png'
        end
        if !object.cover_cdn_url.nil?
          return object.cover_cdn_url
        end
        BunnyMigrateWorker.perform_async('Business', object.id)
        return s3_url_by_attachment(object.cover, :original)
      end
    end
    if object.is_a?(MediaAttachment)
      if object.type == "audio"
        return object.cdn_url
      end
      if subtype == "file" || object.type != "video"
        if !object.cdn_url.nil?
          return object.cdn_url
        end
        BunnyMigrateWorker.perform_async('MediaAttachment', object.id)
        return s3_url_by_attachment(object.file, object.type == "video" ? :playable : :original)
      else
        if !object.small_cdn_url.nil?
          return object.small_cdn_url
        end
        BunnyMigrateWorker.perform_async('MediaAttachment', object.id)
        return s3_url_by_attachment(object.file, object.type == "video" ? :small : :original)
      end
    end
    if object.is_a?(CustomEmoji)
      if object.respond_to?(:cdn_url) && !object.cdn_url.nil?
        return object.cdn_url
      end
      BunnyMigrateWorker.perform_async('CustomEmoji', object.id)
      return s3_url_by_attachment(object.image, :original)
    end
    if object.is_a?(ReactionType)
      if !object.cdn_url.nil?
        return object.cdn_url
      end
      BunnyMigrateWorker.perform_async('ReactionType', object.id)
      return s3_url_by_attachment(object.image, :original)
    end
    if object.is_a?(PreviewCard)
      if !object.image?
        return 'https://gab.com/headers/original/gab-cover-placeholder-2.png'
      end
      if !object.cdn_url.nil?
        return object.cdn_url
      end
      BunnyMigrateWorker.perform_async('PreviewCard', object.id)
      return s3_url_by_attachment(object.image, :original)
    end
    if object.is_a?(MarketplaceListingCategory)
      if !object.cover_image?
        return 'https://gab.com/headers/original/gab-cover-placeholder-2.png'
      end
      if !object.cdn_url.nil?
        return object.cdn_url
      end
      BunnyMigrateWorker.perform_async('MarketplaceListingCategory', object.id)
      return s3_url_by_attachment(object.cover_image, :original)
    end
    if object.is_a?(PendingMediaAttachment)
      if subtype == "file" 
        if !object.cdn_url.blank?
          return object.cdn_url
        end
        BunnyMigrateWorker.perform_async('PendingMediaAttachment', object.id)
        return s3_url_by_attachment(object.file, object.type == "video" ? :playable : :original)
      else
        if !object.small_cdn_url.blank?
          return object.small_cdn_url
        end
        BunnyMigrateWorker.perform_async('PendingMediaAttachment', object.id)
        return s3_url_by_attachment(object.file, object.type == "video" ? :small : :original)
      end
    end
    #if object.is_a?(MediaAttachment) && !object.file_fingerprint.blank? && subtype == "file"
    #  return "/api/v4/media/f/#{object.file_fingerprint}/#{object.id}"
    #else
    #  return "/api/v4/media/#{object.class.name.downcase}/#{subtype}/#{object.id}"
    #end
  end

  def full_pack_url(source, **options)
    full_asset_url(asset_pack_path(source, options))
  end

  def bunny_url_by_object(object, attachment, subtype, skip_host = false, use_cdn = true)
    host = use_cdn ? ENV['BUNNYNET_CDN_URL'] : "#{ENV['BUNNYNET_STORAGE_URL']}/#{ENV['BUNNYNET_STORAGE_ZONE']}"
    if object.is_a?(MediaAttachment) && !object.file_fingerprint.blank? && subtype == "file"
      path = Paperclip::Interpolations.interpolate("media_attachments/#{object.file_fingerprint[0..1]}/#{object.file_fingerprint[2..3]}/#{object.file_fingerprint[4..5]}/#{object.file_fingerprint}.:extension", attachment, "playable")
      if path.end_with?(".qt")
        path = path.sub(".qt", ".mp4")
      end
      x =  (skip_host ? path : "#{host}/#{path}")
      return x
    else
      target = :original
      if object.is_a?(MediaAttachment)
        if object.type == "audio"
          target = :original
        elsif subtype == "file" && object.type != "image"
          target = :playable
        elsif object.type == "image"
          target = :original
        elsif subtype == "small"
          target = :small
        end
      end
      path = Paperclip::Interpolations.interpolate(":class/:attachment/:id_partition/:style/:filename", attachment, target)
      if object.is_a?(Account) && subtype == "avatar" && !object.avatar_remote_url.blank?
        path = "legacy/#{object.avatar_remote_url.sub("gab://avatar/", "")}"
      elsif object.is_a?(Account) && subtype == "header" && !object.header_remote_url.blank?
        path = "legacy/#{object.header_remote_url.sub("gab://header/", "")}"
      end
      x = (skip_host ? path : "#{host}/#{path}")
      x = x.sub("gab://groups/", "")
      return x
    end
    nil
  end

  def s3_url_by_attachment(attachment, style = :original)
    object = attachment.instance
    if object.is_a?(Account) && attachment.name == :avatar && object.avatar_file_name.blank?
      return nil
    end
    if object.is_a?(Account) && attachment.name == :header && object.header_file_name.blank?
      return nil
    end
    if object.is_a?(Group) && attachment.name == :header && object.header_file_name.blank?
      return nil
    end
    if object.is_a?(Business) && attachment.name == :avatar && object.avatar_file_name.blank?
      return nil
    end
    if object.is_a?(Business) && attachment.name == :cover && object.cover_file_name.blank?
      return nil
    end
    if object.is_a?(MarketplaceListingCategory) && attachment.name == :cover_image && object.cover_image_file_name.blank?
      return nil
    end

    host = ENV['S3_CLOUDFRONT_HOST']
    x = Paperclip::Interpolations.interpolate("https://#{host}/:class/:attachment/:id_partition/:style/:filename", attachment, style)
    # problem is, the url might come back like this:
    # "https://media.gab.com/system/media_attachments/files/004/683/750/original/gab://media/https://gab.com/media/image/bq-5c47825a0d818.jpeg%7Chttps://gab.com/media/image/bq-5c47825a0d85a.jpeg"
    # if gab://media is present, we know this url is invalid, and need to split out the final url, after a %7C or |
    if x.include?("gab://media")
      x = x.split("gab://media/")[1]
      x = x.split("%7C")[0]
      x = x.split("|")[0]
    end
    if x.include?("gab://groups")
      x = x.split("gab://groups/")[1]      
      x = "https://gab.com/media/user/#{x}"
    end
    if x.include?("gab://avatar")
      x = x.split("gab://avatar/")[1]
      x = "https://gab.com/media/user/#{x}"
    end
    if x.include?("gab://header")
      x = x.split("gab://header/")[1]
      x = "https://gab.com/media/user/#{x}"
    end
    if x.end_with?(".qt") && style == :playable
      x = x.sub(".qt", ".mp4")
    end
    if x.end_with?(".mov") && style == :playable
      x = x.sub(".mov", ".mp4")
    end
    if attachment.instance.is_a?(Account) && attachment.name == :avatar && !attachment.instance.avatar_remote_url.blank?
      x = attachment.instance.avatar_remote_url.sub("gab://avatar/", "https://gab.com/media/user/")
    elsif attachment.instance.is_a?(Account) && attachment.name == :header && !attachment.instance.header_remote_url.blank?
      x = attachment.instance.header_remote_url.sub("gab://header/", "https://gab.com/media/user/")
    end
    x
  end

  def migrate_url_to_bunny(source_url, target_url, object, media_type)
    puts "XXXCCCVVV migrate_url_to_bunny %%% #{source_url} ^^^ #{target_url}"
    begin
      if source_url.start_with?("/system")
        source_url = source_url.sub("/system", "")
      end
      if !source_url.start_with?("http")
        source_url = "https://#{ENV['S3_CLOUDFRONT_HOST']}#{source_url}"
      end
      tmp = nil
      begin
        tmp = Down.download(source_url)
      rescue => e
        raise "Failed to download #{source_url}: #{e.message}"        
      end
      upload_to_bunny(tmp, target_url)
      case object
      when MediaAttachment
        if media_type == "file"
          bu = bunny_url_by_object(object, object.file, "file")
          object.update(cdn_url: bu)
        elsif media_type == "small"
          bu = bunny_url_by_object(object, object.file, "small")
          object.update(small_cdn_url: bu)
        end
      when Account
        if media_type == "avatar"
          bu = bunny_url_by_object(object, object.avatar, "avatar")
          object.update(avatar_cdn_url: bu)
        elsif media_type == "header"
          bu = bunny_url_by_object(object, object.header, "header")
          object.update(header_cdn_url: bu)
        end
      when Group
        if media_type == "header"
          bu = bunny_url_by_object(object, object.header, "header")
          object.update(header_cdn_url: bu)
        end
      when Business
        if media_type == "avatar"
          bu = bunny_url_by_object(object, object.avatar, "avatar")
          object.update(avatar_cdn_url: bu)
        elsif media_type == "cover"
          bu = bunny_url_by_object(object, object.cover, "cover")
          object.update(cover_cdn_url: bu)
        end
      when PreviewCard
        if media_type == "image"
          bu = bunny_url_by_object(object, object.image, "image")
          object.update(cdn_url: bu)
        end
      when CustomEmoji
        if media_type == "file"
          bu = bunny_url_by_object(object, object.image, "file")
          object.update(cdn_url: bu)
        end
      when ReactionType
        if media_type == "file"
          bu = bunny_url_by_object(object, object.image, "file")
          object.update(cdn_url: bu)
        end
      when MarketplaceListingCategory
        if media_type == "cover_image"
          bu = bunny_url_by_object(object, object.cover_image, "cover_image")
          object.update(cdn_url: bu)
        end
      when PendingMediaAttachment
        if media_type == "file"
          bu = bunny_url_by_object(object, object.file, "file")
          object.update(cdn_url: bu)
        end
        if media_type == "small"
          bu = bunny_url_by_object(object, object.file, "small")
          object.update(small_cdn_url: bu)
        end
      end
    rescue => e
      puts "Error migrating url to bunny: #{e.message}"
      raise e
    end
  end

  def upload_to_bunny(file, url)
    uri = URI.parse(url)
    request = Net::HTTP::Put.new(uri)
    request['AccessKey'] = ENV['BUNNYNET_API_KEY']
    request['Content-Type'] = MIME::Types.type_for(file.original_filename).first.to_s
    request.body = file.read
  
    response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: uri.scheme == 'https') do |http|
      http.request(request)
    end
  
    if response.is_a?(Net::HTTPSuccess)
      true
    else
      raise "Failed to upload to #{url} Bunny.net: #{response.body}"
    end
  end

  #def default_images()      
  #  if url.present?
  #    return url
  #  end
  #    case class_name
  #    when 'accounts'
  #      return (media_type == 'header' ? '/headers/original/missing.png' : '/avatars/original/missing.png')
  #    when 'group'
  #      return '/headers/original/gab-cover-placeholder-2.png'
  #    when 'business'
  #      return (media_type == 'cover' ? '/headers/original/gab-cover-placeholder-2.png' : '/avatars/original/missing.png')
  #    when 'mediaattachment' || 'pendingmediaattachment'
  #      return '/headers/original/gab-cover-placeholder-2.png'
  #    when 'previewcard'
  #      return '/headers/original/gab-cover-placeholder-2.png'
  #    when 'marketplace_listing_category'
  #      return '/headers/original/gab-cover-placeholder-2.png'
  #    else
  #      return '/headers/original/missing.png'
  #    end
  #  end
  
  def check_head(url)
    begin
      response = HTTP.head(url)
      if response.status.success?
        return true
      else
        return false
      end
    rescue => e
      return false
    end
  end

  private

  def use_storage?
    Rails.configuration.x.use_s3 || Rails.configuration.x.use_swift || Rails.configuration.x.use_bunny
  end
end
