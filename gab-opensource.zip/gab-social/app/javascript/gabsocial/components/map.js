import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents, Circle, LayerGroup } from "react-leaflet";
import React, { useState, useEffect } from "react";
// import L from "leaflet";

// import _s from 'gab-components/dist/styles/global.module.css'

import "../../styles/leaflet.css"
// import "leaflet/dist/leaflet.css";

function LocationMarker() {
  const [position, setPosition] = useState(null)
  const map = useMapEvents({
    click() {
      map.locate()
    },
    locationfound(e) {
      // console.log("e:", e)
      setPosition(e.latlng)
      map.flyTo(e.latlng, map.getZoom())
    },
  })

  return position === null ? null : (
    <Marker position={position}>
      <Popup>You are here</Popup>
    </Marker>
  )
}

function Centerer({ center })  {
  const map = useMap()

  useEffect(() => {
    map.setView(center)
  }, [center, map])

  return null
}

function Map({ lat, lon, display_name }) {

  const position = [lat, lon]

  return (
    <MapContainer
      className={[_s.d, _s.h100PC, _s.w100PC].join(' ')}
      center={position}
      zoom={10}
      scrollWheelZoom={false}
      zoomControl={false}
      dragging={false}
    >
      <Centerer center={position} />
      <TileLayer
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> 
        contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <LayerGroup>
        <Circle center={position} pathOptions={{ fillColor: 'blue' }} radius={500} />
      </LayerGroup>
      {/* <Marker position={position}>
        <Popup>{display_name}</Popup>
      </Marker> */}
      {/* <LocationMarker /> */}
      {/* <MapView /> */}
    </MapContainer>
  );
}


export default Map