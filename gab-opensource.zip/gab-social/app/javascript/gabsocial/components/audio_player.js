import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { CX } from '../constants'
import Icon from './icon'
import audioController from '../utils/audio_controller'

class AudioPlayer extends ImmutablePureComponent {
  constructor(props) {    
    super(props)
    this.audio = null
    this.state = {
      isPlaying: false,
      currentTime: 0,
      duration: 0,
    }
  }

  componentDidMount() {
    this.audio = new Audio(this.props.src)
    this.audio.addEventListener('timeupdate', this.handleTimeUpdate)
    this.audio.addEventListener('loadedmetadata', this.handleLoadedMetadata)
    this.audio.addEventListener('ended', this.handleEnded)
    audioController.register(this)
  }

  componentWillUnmount() {
    console.log('in audio player componentWillUnmount');
    this.handlePause()
    this.audio.removeEventListener('timeupdate', this.handleTimeUpdate)
    this.audio.removeEventListener('loadedmetadata', this.handleLoadedMetadata)
    this.audio.removeEventListener('ended', this.handleEnded)
    audioController.unregister(this)
  }

  handlePlay = () => {
    audioController.play(this)
    this.audio.play()
    this.setState({ isPlaying: true })
  }

  handlePause = () => {
    this.audio.pause()
    this.setState({ isPlaying: false })
  }

  handleTimeUpdate = () => {
    this.setState({ currentTime: this.audio.currentTime })
  }

  handleLoadedMetadata = () => {
    this.setState({ duration: this.audio.duration })
  }

  handleEnded = () => {
    this.setState({ isPlaying: false, currentTime: 0 })
  }

  handleSeek = (e) => {
    const seekTime = (e.nativeEvent.offsetX / e.target.offsetWidth) * this.state.duration
    this.audio.currentTime = seekTime
    this.setState({ currentTime: seekTime })
  }

  formatTime = (time) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60).toString().padStart(2, '0')
    return `${minutes}:${seconds}`
  }

  pause = () => {
    if (this.audio) {
      this.audio.pause()
      this.setState({ isPlaying: false })
    }
  }

  render() {
    const { isPlaying, currentTime, duration } = this.state
    const { isPending, title } = this.props
    const progressBarClasses = CX({
      d: 1,
      h5: 1,
      w100PC: 1,
      bgSecondary: 1,
      cursorPointer: 1,
    })

    const progressClasses = CX({
      d: 1,
      h5: 1,
      bgBrand: 1,
    })

    return (
      <div className={[_s.d, _s.px10, _s.py5, _s.radiusSmall, _s.bgSubtle, _s.flexRow, _s.aiCenter, _s.ml5, _s.mr5].join(' ')}>
        <button
          className={[_s.d, _s.jcCenter, _s.aiCenter, _s.radiusCircle, _s.bgTransparent, _s.outlineNone, _s.cursorPointer, _s.mr10].join(' ')}
          onClick={isPlaying ? this.handlePause : this.handlePlay}
        >
          <Icon id={isPlaying ? 'pause' : 'play'} size='18px' className={_s.cBrand} />
        </button>
        {!isPending && (
          <div className={[_s.d, _s.flexGrow1, _s.maxW100PC].join(' ')}>
            <div className={progressBarClasses} onClick={this.handleSeek}>
              <div className={progressClasses} style={{ width: `${(currentTime / duration) * 100}%`, height: '8px'}} />
            </div>
            <div className={[_s.d, _s.flexRow, _s.jcSpaceBetween, _s.aiCenter, _s.mt5].join(' ')}>
              <span className={[_s.text, _s.cSecondary, _s.fsXSmall].join(' ')}>{this.formatTime(currentTime)}</span>
              <span className={[_s.text, _s.cSecondary, _s.fsXSmall].join(' ')}>{title}</span>
              <span className={[_s.text, _s.cSecondary, _s.fsXSmall].join(' ')}>{this.formatTime(duration)}</span>
            </div>
          </div>
        )}
      </div>
    )
  }
}

AudioPlayer.propTypes = {
  src: PropTypes.string.isRequired,
  title: PropTypes.string,
  isPending: PropTypes.bool,
}

export default React.forwardRef((props, ref) => {
  return <AudioPlayer {...props} forwardedRef={ref} />
})