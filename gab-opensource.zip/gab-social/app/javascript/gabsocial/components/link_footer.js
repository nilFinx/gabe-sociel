import React from 'react'
import { me } from '../initial_state'
import { DEFAULT_REL } from '../constants'
import Text from './text'
import Button from './button'

class LinkFooter extends React.PureComponent {

  render() {
    const currentYear = new Date().getFullYear()

    const linkFooterItems = [
      {
        href: 'https://help.gab.com',
        text: 'Help',
      },
      {
        href: '/auth/edit',
        text: 'Security',
        requiresUser: true,
      },
      {
        to: '/about',
        text: 'About',
      },
      {
        to: '/about/investors',
        text: 'Investors',
      },
      {
        to: '/about/sales',
        text: 'Terms of Sale',
      },
      {
        to: '/about/dmca',
        text: 'DMCA',
      },
      {
        to: '/about/tos',
        text: 'Terms of Service',
      },
      {
        to: '/about/privacy',
        text: 'Privacy Policy',
      },
      {
        href: 'https://gab.ai?f=lf-uai',
        text: 'Gab AI',
      },
      {
        href: 'https://gab.ai/start/gabby?f=lf-uai-gabby',
        text: 'Generate Uncensored AI Images',
      },
      {
        href: '/auth/sign_out',
        text: 'Logout',
        requiresUser: true,
        logout: true,
      },
    ]

    return (
      <div key='link-footer' className={[_s.d, _s.mb15].join(' ')}>
        <nav aria-label='Footer' role='navigation' className={[_s.d, _s.flexWrap, _s.flexRow].join(' ')}>
          {
            linkFooterItems.map((linkFooterItem, i) => {
              if (linkFooterItem.requiresUser && !me) return null

              return (
                <div key={`link-footer-item-${i}`} className={[_s.d, _s.flexRow, _s.aiCenter, _s.jcCenter].join(' ')}>
                  <Button
                    isText
                    underlineOnHover
                    color='none'
                    backgroundColor='none'
                    key={`link-footer-item-${i}`}
                    to={linkFooterItem.to}
                    href={linkFooterItem.href}
                    data-method={linkFooterItem.logout ? 'delete' : null}
                    onClick={linkFooterItem.onClick || null}
                    className={[_s.mt5].join(' ')}
                  >
                    <Text size='small' color='tertiary'>
                      {linkFooterItem.text}
                    </Text>
                  </Button>
                  { !linkFooterItem.logout && <Text size='small' color='secondary' className={[_s.pt2, _s.mr5, _s.ml5].join(' ')}>·</Text> }
                </div>
              )
            })
          }
        </nav>

        <Text size='small' color='tertiary' className={_s.mt10}>
          © {currentYear} Gab AI, Inc.
        </Text>

        <Text size='small' color='tertiary' tagName='p' className={_s.mt10}>
          Gab Social is open source software.
          <a href='https://code.gab.com/gab/gab-open-source' className={[_s.displayInlineBlock, _s.inherit].join(' ')} rel={DEFAULT_REL} target='_blank'>
            code.gab
          </a>
        </Text>
      </div>
    )
  }

}

export default LinkFooter