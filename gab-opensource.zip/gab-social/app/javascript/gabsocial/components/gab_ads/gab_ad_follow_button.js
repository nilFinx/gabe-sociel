import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { me, loggedOut } from '../../initial_state'
import { makeGetAccount } from '../../selectors'
import {
  fetchAccount,
  followAccount
} from '../../actions/accounts'
import Button from '../button'
import Text from '../text'

class GabAdFollowButton extends ImmutablePureComponent {

  componentDidMount() {
    const { account, accountId } = this.props
    if (!account && accountId) {
      this.props.onFetchAccount(accountId)
    }
  }

  componentDidUpdate() {
    if (!this.props.account) {
      this.props.onFetchAccount(this.props.accountId)
    }
  }

  handleFollow = () => {
    const { accountId } = this.props
    if (accountId && accountId !== -1) {
      this.props.onFollow(accountId)
    }
  }

  render() {
    const {
      account,
      isBlockedBy,
      isMe,
      isBlocking,
      isRequested,
      isFollowing
    } = this.props

    let buttonText = 'Learn More'
    let buttonOptions = {
      color: 'primary',
      backgroundColor: 'tertiary'
    }

    if (account && !loggedOut) {

      if (isRequested || isFollowing) {
        buttonText = "Following"
        buttonOptions = {
          color: 'white',
          backgroundColor: 'brand',
        }
      } else if (isBlocking || isMe || isBlockedBy) {
        buttonText = "Learn More"
        buttonOptions = {
          color: 'primary',
          backgroundColor: 'tertiary',
        }
      } else {
        buttonText = "Follow"
        buttonOptions = {
          onClick: this.handleFollow,
          color: 'primary',
          backgroundColor: 'tertiary'
        }
      }
    }

    return (
      <Button
        {...buttonOptions}
        radiusSmall
      >
        <Text color='inherit' weight='medium'>
          {buttonText}
        </Text>
      </Button>
    )
    
  }

}

const mapStateToProps = (state, { accountId }) => {
  accountId = `${accountId}`
  const account = state.getIn(['accounts', accountId])
  const isBlockedBy = state.getIn(['relationships', accountId, 'blocked_by'], false)
  const isBlocking = state.getIn(['relationships', accountId, 'blocking'], false)
  const isFollowing = state.getIn(['relationships', accountId, 'following'], false)
  const isRequested = state.getIn(['relationships', accountId, 'requested'], false)
  const isMe = me === accountId
  
  const getAccount = makeGetAccount()

  return {
    isMe,
    isBlockedBy,
    isBlocking,
    isFollowing,
    isRequested,
    accountId,
    account: accountId !== -1 ? getAccount(state, accountId) : null,
  }
}

const mapDispatchToProps = (dispatch) => ({
  onFollow (accountId) {
    dispatch(followAccount(accountId))
  },
  onFetchAccount(accountId) {
    dispatch(fetchAccount(accountId))
  }
})

GabAdFollowButton.propTypes = {
  account: ImmutablePropTypes.map,
  onFollow: PropTypes.func.isRequired,
  onFetchAccount: PropTypes.func.isRequired,
  accountId: PropTypes.string.isRequired,
  isMe: PropTypes.bool.isRequired,
  isBlockedBy: PropTypes.bool.isRequired,
  isBlocking: PropTypes.bool.isRequired,
  isFollowing: PropTypes.bool.isRequired,
  isRequested: PropTypes.bool.isRequired,
}

export default connect(mapStateToProps, mapDispatchToProps)(GabAdFollowButton)
