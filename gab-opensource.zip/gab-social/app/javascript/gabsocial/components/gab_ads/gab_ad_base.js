import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import isObject from 'lodash/isObject'
import axios from 'axios'
import {
  GAB_AD_PLACEMENTS
} from '../../constants'
import { pagePosition, removePagePosition } from '../../actions/advertisements'
import Button from '../button'
import { isMobile, getWindowDimension } from '../../utils/is_mobile'

const REQUIRED_KEYS = [
  'id',
  'title',
  'subtitle',
  'image',
  'url',
]

const initialState = getWindowDimension()

// TODO configurable URL for gab grow such as dotenv and url-join
const growBaseUrl = 'https://grow.gab.com/get/'

class GabAdBase extends React.Component {

  state = { ad: null, fetchedAd: false }

  /**
   * Getter which is true if pageKey and position props were provided.
   * @returns {boolean}
   */
  get hasPagePosition() {
    const { pageKey, position } = this.props
    return typeof pageKey === 'string' && typeof position === 'number'
  }

  /**
   * Getter creating a string key for caching.
   * @returns {string}
   */
  get pagePositionKey() {
    const { pageKey, position } = this.props
    return `${pageKey}-${position}`
  }

  get isAdBlank() {
    const { ad } = this.state
    return ad === undefined ||
      ad === null ||
      (typeof ad === 'object' && Object.keys(ad).length === 0) ||
      REQUIRED_KEYS.every(key => Object.keys(ad).includes(key)) === false
  }

  /**
   * Return a cached at at the page position, if any.
   * @returns {object}
   */
  cachedAd() {
    if (this.hasPagePosition === false) {
      return
    }
    const ad = this.props.pagePositionAdsCache.get(this.pagePositionKey)
    if (ad !== undefined) {
      // it was cached
      return ad.toJS()
    }
  }

  /**
   * If we fetched a new ad then save it at the current position.
   * @param {object} ad
   */
  savePosition(ad) {
    if (this.hasPagePosition === false) {
      return
    }
    const { pageKey, position } = this.props
    this.props.onPagePosition({ pageKey, position, ad })
  }

  /**
   * Fetch a new ad and save it at the page position.
   */
  loadFreshAd() {
    const { placement, groupCategory, chatAdType, pageKey, position } = this.props
    let adUrl

    const mobile = isMobile(initialState.width)

    // makes a huge assumption on the positions being correct.
    // if the distance between ad injections is changed
    // this will fail silently and not use 3rd party ads.
    // intention atm: [gab, armanet, gab, gab, gab, armanet, gab+]
    const armanetSlotPositions = [14, 42]

    if (placement === GAB_AD_PLACEMENTS.status) {
      if (position > 63) {
        let pad = {}
        this.savePosition(pad)
        this.setState({ ad: pad, fetchedAd: true })
        return;
      }
      if (armanetSlotPositions.includes(position)) {
        let pad = { armanetActive: true }
        this.savePosition(pad)
        this.setState({ ad: pad, fetchedAd: true })
        return;
      }
      adUrl = `${growBaseUrl}status`
    } else if (placement === GAB_AD_PLACEMENTS.panel) {
      adUrl = `${growBaseUrl}sidebar`
    } else if (placement === GAB_AD_PLACEMENTS.buyout) {
      adUrl = `${growBaseUrl}buyout`
    }

    if (groupCategory && groupCategory != '') {
      adUrl += `?category=${groupCategory}`
    } else if (chatAdType && chatAdType != '') {
      adUrl += '?chatad=1'
    }

    axios.get(adUrl).then(({ data: ad }) => {
      this.savePosition(ad)
      this.setState({ ad, fetchedAd: true })
    }).catch(err => {
      const { message, stack } = err
      console.error('error requesting from grow', message, stack)
      // on error save a blank spot to prevent jumping scroll Y
      const ad = {}
      this.savePosition(ad)
      this.setState({ ad, fetchedAd: true })
    })
  }

  componentDidMount() {
    const ad = this.cachedAd()
    const { bottomPanelUrl, pageKey, position } = this.props
    if (ad !== undefined) {
      // cached
      this.setState({ ad, fetchedAd: true })
      if (!!bottomPanelUrl) {
        this.props.onPagePosition({ pageKey, position, undefined })
      }
      return
    }
    // dont fetch bottom sidebar panel ads, they use panel.top ones
    if (!this.props.bottomPanelUrl) {
      this.loadFreshAd()
    }
  }

  componentDidUpdate(prevProps) {
    const { bottomPanelUrl, pagePositionAdsCache, pageKey, position } = this.props
    // if is panel.bottom, doesn't have ad, and cache changed
    if (!!bottomPanelUrl && !this.state.ad && prevProps.pagePositionAdsCache !== pagePositionAdsCache) {
      // check to see if we have the cached ad
      // since ad.pageKey && ad.position is equal for panel.top and panel.bottom...
      const ad = this.cachedAd()
      if (ad !== undefined) { // cached, set
        this.setState({ ad, fetchedAd: true })
        this.props.onPagePosition({ pageKey, position, undefined })
      }
    }
  }

  render() {
    const { ad, fetchedAd } = this.state
    const { children, bottomPanelUrl, chatAdType, placement, isComments, adNumber, adModalClose, pageKey, position } = this.props

    if (!fetchedAd) {
      return null
    }

    if (this.isAdBlank) {
      if (pageKey == 'interstitial') {
        adModalClose()
        return null
      }
      if (ad && ad.armanetActive && placement === GAB_AD_PLACEMENTS.status) {
        // put the armanet med rec here...
        return (
          <div
            className={[_s.d, _s.bgTransparent, widthClass, _s.hAuto].join(' ')}
          >
            {children({ armanetActive: true })}
          </div>
        )
      } else {
        return null
      }
    }

    // Update classes for chat specific ads
    let widthClass = _s.w100PC
    if (chatAdType) {
      widthClass = _s.wChatAd
    }

    // dont allow clicking on whole ad if is video ad
    const noClick = (ad && !!ad.video)
    if (noClick) {
      return (
        <div
          className={[_s.d, _s.bgTransparent, widthClass, _s.hAuto].join(' ')}
        >
          {children(ad)}
        </div>
      )
    }

    // Render the ad content in a div with an onClick handler instead of using Button
    return (
      <div
        className={[_s.d, _s.bgTransparent, _s.cursorPointer, _s.outlineNone, widthClass, _s.hAuto, _s.noUnderline].join(' ')}
        onClick={() => {
          const url = bottomPanelUrl ? (ad.url + bottomPanelUrl) : ad.url
          window.open(url, '_blank', 'noopener')
        }}
      >
        {children(ad)}
      </div>
    )
  }

}

function mapStateToProps(state) {
  const pagePositionAdsCache = state.getIn(['advertisements', 'pagePositionAdsCache']);
  return { pagePositionAdsCache }
}

const mapDispatchToProps = (dispatch) => ({
  onPagePosition({ pageKey, position, ad }) {
    dispatch(pagePosition({ pageKey, position, ad }))
  },
  onRemovePosition(pagePositionKey) {
    dispatch(removePagePosition(pagePositionKey))
  }
})

GabAdBase.propTypes = {
  children: PropTypes.func.isRequired,
  placement: PropTypes.oneOf(Object.keys(GAB_AD_PLACEMENTS)),
  bottomPanelUrl: PropTypes.string,
  chatAdType: PropTypes.string,
  onPagePosition: PropTypes.func.isRequired,
  onRemovePosition: PropTypes.func.isRequired,
  pageKey: PropTypes.string,
  position: PropTypes.number,
  groupCategory: PropTypes.string,
  pagePositionAdsCache: ImmutablePropTypes.map,
  isComments: PropTypes.bool,
  adNumber: PropTypes.number
}

export default connect(mapStateToProps, mapDispatchToProps)(GabAdBase)
