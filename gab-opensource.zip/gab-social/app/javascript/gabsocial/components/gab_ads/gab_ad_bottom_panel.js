import React, { useState, useEffect } from 'react'
import { GAB_AD_PLACEMENTS, DEFAULT_REL } from '../../constants'
import GabAdPanelBottomListItem from './gab_ad_panel_bottom_list_item'
import GabAdRoot from './gab_ad_root'
import GabAdBase from './gab_ad_base'
import PanelLayout from '../panel/panel_layout'
import Text from '../text'


const BottomAdSlotWrapper = ({ ad }) => {

  // todo: put the armanet med rec here...
  return (
    <div className={[_s.mauto].join(' ')}>
    </div>
  )

};

const GabAdBottomPanel = ({ pageKey, position }) => {
  return (
    <GabAdRoot key='gab-ad-bottom-panel' force={true} placement={GAB_AD_PLACEMENTS.buyout}>
      <GabAdBase placement={GAB_AD_PLACEMENTS.buyout} bottomPanelUrl="?b=1" pageKey={pageKey} position={position}>
        {(ad) => {
          if (!ad) return null
          return (
            <PanelLayout noPadding>
              <div className={[_s.d].join(' ')}>
                <GabAdPanelBottomListItem ad={ad} />
              </div>
            </PanelLayout>
          )
        }}
      </GabAdBase>
      <div key='link-ad-footer' className={[_s.d, _s.stickymb680].join(' ')}>
        <Text size='small' color='tertiary' tagName='p' className={_s.mt10}>
          Want to advertise on Gab? 
          <a href='https://grow.gab.com' className={[_s.displayInlineBlock, _s.inherit].join(' ')} rel={DEFAULT_REL} target='_blank'>
            grow.gab
          </a>
        </Text>
      </div>
    </GabAdRoot>
  )
}

export default GabAdBottomPanel
