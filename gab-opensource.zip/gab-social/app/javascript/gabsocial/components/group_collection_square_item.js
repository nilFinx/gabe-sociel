import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { NavLink } from 'react-router-dom'
import { PLACEHOLDER_MISSING_HEADER_SRC, CX } from '../constants'
import { shortNumberFormat } from '../utils/numbers'
import Image from './image'
import Icon from './icon'
import Text from './text'
import GroupActionButton from './group_action_button'

class GroupCollectionSquareItem extends ImmutablePureComponent {

  render() {
    const { group } = this.props

    if (!group) return null
    
    const coverSrc = group.get('cover_image_thumbnail_url') || group.get('cover_image_medium_url') || group.get('cover_image_url') || ''
    const coverMissing = coverSrc.indexOf(PLACEHOLDER_MISSING_HEADER_SRC) > -1 || !coverSrc

    const navLinkClasses = CX({
      d: 1,
      noUnderline: 1,
      bgTertiary: 1,
      overflowHidden: 1,
      radiusSmall: 1,
      w115PX: 1,
      h115PX: 1,
    })

    let groupTitle = group.get('title') || ''
    const max = 26
    if (groupTitle.length > max) groupTitle = `${groupTitle.substring(0, max).trim()}...`

    return (
      <div className={[_s.d, _s.w115PX, _s.h115PX, _s.mr10].join(' ')}>
        <NavLink
          to={`/groups/${group.get('id')}`}
          className={navLinkClasses}
        >
          <Image
            isLazy
            cfWidthPX='115px'
            src={!coverMissing ? coverSrc : undefined}
            alt={group.get('title')}
            height='100%'
            width='100%'
            className={[_s.d, _s.posAbs, _s.h100PC, _s.w100PC, _s.z1, _s.right0, _s.left0, _s.top0, _s.bottom0].join(' ')}
          />
          <div className={[_s.d, _s.posAbs, _s.bottom0, _s.pt10, _s.newsBackground, _s.left0, _s.right0, _s.z3, _s.pb5, _s.px5].join(' ')}>
            <Text weight='medium' color='white' className={_s.textShadow}>{groupTitle}</Text>
          </div>
        </NavLink>
      </div>
    )
  }

}

const mapStateToProps = (state, { id }) => ({
  group: state.getIn(['groups', id]),
})

GroupCollectionSquareItem.propTypes = {
  group: ImmutablePropTypes.map,
}

export default connect(mapStateToProps)(GroupCollectionSquareItem)
