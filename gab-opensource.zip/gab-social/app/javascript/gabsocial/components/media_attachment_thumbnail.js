import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import Button from './button'
import Icon from './icon'
import Image from './image'
import Text from './text'
import Blurhash from './blurhash'
import { toHHMMSS } from '../utils/time'
import { displayMedia } from '../initial_state'

class MediaAttachmentThumbnail extends React.PureComponent {
  state = {
    isLoaded: false,
    isVisible: this.props.visible !== undefined ? this.props.visible : (displayMedia !== 'hide_all' && !this.props.sensitive || displayMedia === 'show_all'),
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.mediaAttachmentId !== this.props.mediaAttachmentId && nextProps.isVisible === undefined) {
      this.setState({
        visible: displayMedia !== 'hide_all' && !nextProps.sensitive || displayMedia === 'show_all',
      })
    } else if (nextProps.isVisible !== this.props.isVisible && nextProps.isVisible !== undefined) {
      this.setState({ isVisible: nextProps.isVisible });
    }
  }

  onImageLoad = () => {
    this.setState({ isLoaded: true })
  }

  handleOnClick = () => {
    const { mediaAttachment, onClick } = this.props
    !!onClick && onClick(mediaAttachment)
  }

  render() {
    const { mediaAttachment } = this.props
    const { isLoaded, isVisible } = this.state

    if (!mediaAttachment) return null

    const csd = {}
    // const status = attachment.get('status')
    // const csd = canShowMediaItem(attachment, account)
    // if (!csd.canShow) return null

    const title = mediaAttachment.get('description')
    const attachmentType = mediaAttachment.get('type')

    let badge = null

    if (attachmentType === 'video') {
      badge = toHHMMSS(mediaAttachment.getIn(['meta', 'duration']))
    } else if (attachmentType === 'gifv') {
      badge = 'GIF'
    }

    return (
      <div className={[_s.d, _s.flex1].join(' ')}>
        <Button
          noClasses
          onClick={this.handleOnClick}
          className={[_s.d, _s.noUnderline, _s.cursorPointer, _s.outlineNone, _s.bgTransparent, _s.flexGrow1].join(' ')}
          // to={mediaAttachment.get('status_url')}
          title={!!csd.label ? csd.label : title}
        >
          <div className={[_s.d, _s.flexGrow1].join(' ')}>
            <div className={[_s.d, _s.pt100PC].join(' ')}>
              <div className={[_s.d, _s.posAbs, _s.top0, _s.right0, _s.left0, _s.bottom0].join(' ')}>
                <div className={[_s.d, _s.h100PC, _s.aiCenter, _s.jcCenter, _s.overflowHidden].join(' ')}>
                  {
                    (!isLoaded || !isVisible || !!csd.label) &&
                    <Blurhash
                      className={[_s.d, _s.w100PC, _s.h100PC, _s.z2, _s.top0].join(' ')}
                      hash={mediaAttachment.get('blurhash')}
                    />
                  }
                  {
                    (isVisible && !csd.label) &&
                    <Image
                      height='100%'
                      width='100%'
                      cfWidthPX='120px'
                      src={mediaAttachment.get('preview_url')}
                      alt={mediaAttachment.get('description')}
                      title={mediaAttachment.get('description')}
                      onLoad={this.onImageLoad}
                      className={_s.z1}
                    />
                  }
                  {
                    (!isVisible || !!badge || !!csd.label) &&
                    <div className={[_s.d, _s.aiCenter, _s.jcCenter, _s.h100PC, _s.w100PC, _s.z3, _s.posAbs].join(' ')}>
                      {
                        (!isVisible || !!csd.label) &&
                        <Icon id='hidden' size='22px' className={_s.cWhite} />
                      }
                      {
                        !!badge &&
                        <div className={[_s.d, _s.posAbs, _s.radiusSmall, _s.bgBlackOpaque, _s.px5, _s.py5, _s.mr5, _s.mt5, _s.mb5, _s.bottom0, _s.right0].join(' ')}>
                          <Text size='extraSmall' color='white'>{badge}</Text>
                        </div>
                      }
                    </div>
                  }
                </div>
              </div>
            </div>
          </div>
        </Button>
      </div>
    )
  }
}

const mapStateToProps = (state, { mediaAttachmentId }) => {
  const mediaAttachment = state.getIn(['media_attachments', 'items', `${mediaAttachmentId}`], null)

	return {
    mediaAttachmentId,
    mediaAttachment,
  }
}

MediaAttachmentThumbnail.propTypes = {
  mediaAttachmentId: PropTypes.string,
  to: PropTypes.func, //generator
  onClick: PropTypes.func,
}

export default connect(mapStateToProps)(MediaAttachmentThumbnail)