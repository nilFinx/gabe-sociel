import React from 'react'
import Button from '../button'
import Text from '../text'
import { me } from '../../initial_state'
import Input from '../input'
import Icon from '../icon'
import BusinessCoupon from './business_coupon'
import { connect } from 'react-redux'
import { BREAKPOINT_EXTRA_SMALL } from '../../constants'
import { updateBusinessCoupons } from '../../actions/businesses'

class BusinessCouponsInput extends React.Component {
  state = {
    coupons: [],
    newCoupon: { type: 'Discount', code: '', amount: '' },
    editingIndex: null
  }

  componentDidMount() {
    const { business } = this.props

    if (!!business) {
      const existingCoupons = business.get('coupons')
      const setCoupons = !!existingCoupons ? existingCoupons.toJS() : []
      if (!!setCoupons) {
        this.setState({ coupons: setCoupons })
      }
		}
  }
  
  handleInputChange = (field, value) => {
    this.setState(prevState => ({
      newCoupon: {
        ...prevState.newCoupon,
        [field]: value
      }
    }))
  }

  addCoupon = () => {
    if (!this.state.newCoupon.code) return window.alert('You need to enter a code first')

    this.setState(prevState => ({
      coupons: [...prevState.coupons, prevState.newCoupon],
      newCoupon: { type: 'Discount', code: '', amount: '' } // Reset form
    }))
  }

  editCoupon = index => {
    this.setState(prevState => ({
      newCoupon: { ...prevState.coupons[index] },
      editingIndex: index
    }))
  }

  updateCoupon = () => {
    this.setState(prevState => {
      const updatedCoupons = [...prevState.coupons]
      updatedCoupons[prevState.editingIndex] = prevState.newCoupon
      return {
        coupons: updatedCoupons,
        newCoupon: { type: 'Discount', code: '', amount: '' }, // Reset form
        editingIndex: null
      }
    })
  }

  deleteCoupon = index => {
    if (window.confirm("Are you sure")) {
      this.setState(prevState => ({
        coupons: prevState.coupons.filter((_, i) => i !== index)
      }))
    }
  }

  renderCouponInput = () => {
    const { newCoupon, editingIndex } = this.state
    const isEditing = editingIndex !== null

    // : todo : add percent and $ amount for discounts

    return (
      <div className={[_s.d, _s.w100PC].join(' ')}>
        <select
          value={newCoupon.type}
          className={[_s.d, _s.mb10, _s.w100PC, _s.px10, _s.fs14PX, _s.h40PX, _s.outlineNone, _s.radiusTiny, _s.borderColorInput, _s.border1PX, _s.cursorPointer, _s.pt10, _s.jcCenter].join(' ')}
          onChange={(e) => this.handleInputChange('type', e.target.value)}
        >
          <option value="Free Shipping">Free Shipping</option>
          <option value="Coupon">Coupon</option>
          <option value="Discount">Discount</option>
        </select>

        <Input
          type="text" 
          placeholder="Code" 
          value={newCoupon.code} 
          maxLength={64}
          className={[_s.mb10].join(' ')}
          onChange={(value) => this.handleInputChange('code', value)} 
        />

        {newCoupon.type !== 'Free Shipping' && (
          <Input 
            type="text" 
            placeholder={newCoupon.type === 'Discount' ? "Dollar or Percent (e.g. $10 or 10%)" : 'Offer or coupon (e.g. Free Shirt, Two Month Trial, etc.)'}
            max={9999}
            maxLength={64}
            value={newCoupon.amount}
            className={[_s.mb10].join(' ')}
            onChange={(value) => this.handleInputChange('amount', value)} 
          />
        )}
        <Button
          radiusSmall
          isBlock
          color='secondary'
          backgroundColor='tertiary'
          className={[_s.mb10].join(' ')}
          onClick={isEditing ? this.updateCoupon : this.addCoupon}
        >
          <Text align='center' weight='medium' color='inherit'>{isEditing ? 'Update' : 'Add'} Coupon</Text>
        </Button>
      </div>
    )
  }

  renderCoupons = () => {
    return this.state.coupons.map((coupon, index) => (
      <div className={[_s.d, _s.bgSecondary, _s.w100PC, _s.px10, _s.py10, _s.mt10, _s.radiusSmall].join(' ')} key={index}>
        <BusinessCoupon type={coupon.type} amount={coupon.amount} code={coupon.code} />
        <div className={[_s.d, _s.flexRow, _s.w100PC].join(' ')}>
          <Button
            radiusSmall
            color='secondary'
            backgroundColor='secondary'
            className={[_s.mr10].join(' ')}
            onClick={() => this.editCoupon(index)}
          >
            <Text color='inherit'>Edit</Text>
          </Button>
          <Button
            radiusSmall
            color='white'
            backgroundColor='danger'
            onClick={() => this.deleteCoupon(index)}
          >
            <Text color='inherit'>Delete</Text>
          </Button>
        </div>
      </div>
    ))
  }

  handleOnSubmit = (event) => {
    const { businessId, onSubmit } = this.props
    // event.preventDefault()
    !!onSubmit && onSubmit(businessId, this.state.coupons)
  }

  render() {
    const { onClose } = this.props

    return (
      <div>
        <div>
          <div className={[_s.d, _s.mb10, _s.py5].join(' ')}>
            <Text weight='medium' color='primary'>
              Create new Offer
            </Text>
          </div>
          {this.renderCouponInput()}

          {this.state.coupons.length > 0 && <div className={[_s.d, _s.mb10, _s.py5].join(' ')}>
            <Text weight='medium' color='primary'>
              Your Offers
            </Text>
          </div>
          } 
          {this.renderCoupons()}
        </div>
        <div className={[_s.d, _s.w100PC, _s.pt15, _s.borderTop1PX, _s.mt15, _s.borderColorSecondary].join(' ')}>
          <Button
            isBlock
            radiusSmall
            backgroundColor='secondary'
            color='primary'
            onClick={this.handleOnSubmit}
          >
            <Text align='center' weight='medium' color='inherit'>Save Coupons</Text>
          </Button>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state, { businessId }) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
  business: state.getIn(['businesses', 'items', businessId]),
})

const mapDispatchToProps = (dispatch) => ({
  onSubmit(businessId, coupons) {
    dispatch(updateBusinessCoupons(businessId, coupons))
  },
})

export default connect(mapStateToProps, mapDispatchToProps)(BusinessCouponsInput)