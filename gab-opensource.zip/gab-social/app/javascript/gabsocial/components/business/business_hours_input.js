import React from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import get from 'lodash/get'
import Button from '../button'
import Text from '../text'
import { BREAKPOINT_EXTRA_SMALL, CX } from '../../constants'
import { updateBusinessHours } from '../../actions/businesses'

class BusinessHoursInput extends React.PureComponent {
  
  state = {
    is247: false,
    hours: {
      mon: { o: '00:00', c: '00:00' },
      tue: { o: '00:00', c: '00:00' },
      wed: { o: '00:00', c: '00:00' },
      thur: { o: '00:00', c: '00:00' },
      fri: { o: '00:00', c: '00:00' },
      sat: { o: '00:00', c: '00:00' },
      sun: { o: '00:00', c: '00:00' },
    }
  }

  componentDidMount() {
    const { business } = this.props

    if (!!business) {
      const existingHours = business.get('hours')
      const setHours = !!existingHours ? existingHours.toJS() : {}
      // console.log("existing, set:", existingHours, setHours)
      if (Array.isArray(setHours) && setHours.length === 1 && setHours[0] === 0) {
        // console.log("setting here:")
        this.setState({ is247: true })
      } else {
        this.setState({ hours: setHours })
      }
		}
  }

  handleInputChange = (day, openOrClose, value) => {
    this.setState(prevState => ({
      hours: {
        ...prevState.hours,
        [day]: {
          ...prevState.hours[day],
          [openOrClose]: value
        }
      }
    }))
  }

  handleToggle247 = () => {
    this.setState(prevState => ({
      is247: !prevState.is247,
      hours: {
        ...prevState.hours,
      }
    }))
  }

  handleSubmit = (event) => {
    const { businessId, onSubmit } = this.props
    event.preventDefault()
    !!onSubmit && onSubmit(businessId, this.state.hours, this.state.is247)
  }
  
  render() {
    const { hours, is247 } = this.state;
    const { onClose, isXS, business } = this.props

    const containerClasses = CX({
      d: 1,
      aiCenter: 1,
      w100PC: 1,
      flexRow: !isXS,
      mb5: !isXS,
      mb10: isXS,
    })

    // console.log("hours", hours)

    return (
      <form className={[_s.d, _s.w100PC].join(' ')} onSubmit={this.handleSubmit}>
        <div className={[_s.d, _s.mb10, _s.py5].join(' ')}>
          <Text weight='medium' color='primary'>
            Hours
          </Text>
        </div>
        <div className={[_s.d, _s.w100PC, _s.pb15, _s.mt5].join(' ')}>
          <div className={[_s.d, _s.flexRow, _s.mrAuto].join(' ')}>
            <Text align={isXS ? 'center' : 'left'} weight='medium' htmlFor='openbox'>
              Are you always open?
              <Text color='secondary' weight='normal'>&nbsp;(Online, 24/7, etc.)</Text>
            </Text>
            <input
              name='openbox'
              type='checkbox'
              checked={is247}
              onChange={(e) => this.handleToggle247(e)} 
            />
          </div>
        </div>
        {!is247 && ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun'].map((day) => (
          <div className={containerClasses} key={`hours-modal-${day}`}>
            <Text align={isXS ? 'center' : 'left'} weight='bold' className={[_s.mb10, _s.w60PX, _s.capitalize].join(' ')}>{day}: </Text>
            <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.jcCenter].join(' ')}>
              <input 
                type="time" 
                className={[_s.d, _s.w115PX, _s.borderColorInput, _s.border1PX, _s.radiusTiny, _s.flexRow, _s.h30PX, _s.pl5, _s.aiCenter].join(' ')}
                value={get(hours, `${day}.o`)}
                onChange={(e) => this.handleInputChange(day, 'o', e.target.value)} 
              />
              <Text className={_s.px10}>to</Text>
              <input 
                type="time" 
                className={[_s.d, _s.w115PX, _s.borderColorInput, _s.border1PX, _s.radiusTiny, _s.flexRow, _s.h30PX, _s.pl5, _s.aiCenter].join(' ')}
                value={get(hours, `${day}.c`)}
                onChange={(e) => this.handleInputChange(day, 'c', e.target.value)} 
              />
            </div>
          </div>
        ))}
        <div className={[_s.d, _s.w100PC, _s.pt15].join(' ')}>
          <Button
            isBlock
            backgroundColor='secondary'
            color='primary'
            radiusSmall
            type='submit'
            onClick={this.handleSubmit}
          >
            <Text align='center' weight='medium' color='inherit'>Save Hours</Text>
          </Button>
        </div>
      </form>
    )
  }
}

const mapStateToProps = (state, { businessId }) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
  business: state.getIn(['businesses', 'items', businessId]),
})

const mapDispatchToProps = (dispatch) => ({
  onSubmit(businessId, hours, is247) {
    dispatch(updateBusinessHours(businessId, hours, is247))
  },
})

BusinessHoursInput.propTypes = {
  onChange: PropTypes.func,
}

export default connect(mapStateToProps, mapDispatchToProps)(BusinessHoursInput)