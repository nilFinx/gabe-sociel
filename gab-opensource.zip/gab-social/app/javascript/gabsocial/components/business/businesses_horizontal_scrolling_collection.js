import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import debounce from 'lodash/debounce'
import {
  CX,
  BREAKPOINT_EXTRA_SMALL,
  BREAKPOINT_MEDIUM,
  BREAKPOINT_LARGE,
} from '../../constants'
import BusinessCard from '../business/business_card'
import BusinessCardPlaceholder from '../placeholder/business_card_placeholder'
import Text from '../text'
import ScrollableList from '../scrollable_list'
import Button from '../button'

class BusinessesHorizontalScrollingCollection extends ImmutablePureComponent {

  handleScroll = () => {
    if (this.scrollNode) {
      this.scrollNode.scrollBy({ left: 300, behavior: 'smooth' })
    }
  }

  setScrollNode = (n) => {
    this.scrollNode = n
  }

  render() {
    const {
      isLoading,
      data,
      title,
      width,
      unwrapped,
      noPadding,
    } = this.props

    // const hasListings = Array.isArray(data) && data.length > 0

    const isXS = width <= BREAKPOINT_EXTRA_SMALL
    const isMD = width <= BREAKPOINT_MEDIUM
    const isLG = width <= BREAKPOINT_LARGE

    const wrapperClasses = CX({
      d: 1,
      maxW100PC: 1,
      w100PC: 1,
      pt15: isXS && !noPadding,
    })

    const mainClasses = CX({
      d: 1,
      w100PC: 1,
      pb10: !noPadding,
      pt15: !noPadding,
      px15: !isXS && !unwrapped,
      px10: isXS && !unwrapped,
    })

    const titlePLClass = isXS ? _s.pl5 : _s.pl10

    return (
      <div className={wrapperClasses}>
        <div className={mainClasses}>
          {
            Array.isArray(data) && data.map((block, i) => {
              let mbClass = isXS ? _s.d : _s.mb10
              let mClass = i === 0 ? _s.d : _s.mt15
              let pbClass = isXS ? i === 0 ? _s.pb10 : _s.pb5 : _s.pb15
              let wClass = isXS ? _s.w300PX : isLG ? _s.w33PC : _s.w20PC
              let minWClass = noPadding ? _s.minW252PX : _s.d
              let hasMany = Array.isArray(block.ids) && block.ids.length > 1

              return (
                <div key={`mlhc-${block.title}`} className={[_s.d, _s.w100PC, mClass, mbClass, pbClass, _s.borderBottom1PX, _s.borderColorInput].join(' ')}>
                  <div className={[_s.d, _s.flexRow, _s.w100PC, _s.aiCenter, titlePLClass, _s.pr5, pbClass, _s.mb10].join(' ')}>
                    {
                      !!block.title && <Text size={isXS ? 'large' : 'extraExtraLarge'} weight='bold'>{block.title}</Text>
                    }
                    {
                      !!block.to &&
                      <div className={[_s.d, _s.mlAuto].join(' ')}>
                        <Button
                          radiusSmall
                          backgroundColor='none'
                          color='brand'
                          to={block.to}
                          className={_s.bgSubtle_onHover}
                        >
                          <Text color='inherit' size={isXS ? 'normal' : 'medium'} weight='medium'>See all</Text>
                        </Button>
                      </div>
                    }
                  </div>
                  <div ref={this.setScrollNode} className={[_s.d, titlePLClass, _s.maxW100PC, _s.w100PC, _s.flexRow, _s.overflowXScroll, _s.overflowHidden, _s.pb15].join(' ')}>
                    {Array.isArray(block.ids) && block.ids.map((listingId) => {
                      return (
                        <div className={[_s.d, wClass, minWClass, _s.mr10].join(' ')}>
                          <BusinessCard
                            isFeatured
                            key={`business-card-${listingId}`}
                            id={listingId}
                          />
                        </div>
                      )
                    })}
                  </div>
                  {
                    hasMany &&
                    <Button
                      tabIndex='0'
                      backgroundColor='white'
                      className={[_s.py15, _s.posAbs, _s.top50PC, _s.mtNeg19PX, _s.right0, _s.mr10, _s.z4].join(' ')}
                      onClick={this.handleScroll}
                      color='black'
                      aria-label='Next'
                      icon='arrow-right'
                      iconSize='18px'
                    />
                  }
                </div>
              )
            })
          }
        </div>
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  width: state.getIn(['settings', 'window_dimensions', 'width']),
})

BusinessesHorizontalScrollingCollection.propTypes = {
  listingIds: ImmutablePropTypes.list,
  isLoading: PropTypes.bool,
  unwrapped: PropTypes.bool,
  title: PropTypes.string,
}

export default connect(mapStateToProps)(BusinessesHorizontalScrollingCollection)
