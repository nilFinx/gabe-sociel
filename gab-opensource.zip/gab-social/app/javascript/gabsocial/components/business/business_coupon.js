import React from 'react'
import Icon from '../icon'
import Text from '../text'

function BusinessCoupon({ type, code, amount }) {
  return (
    <div className={[_s.d, _s.flexRow, _s.flexWrap, _s.aiCenter, _s.radiusSmall, _s.bgTertiary, _s.w100PC, _s.mb10, _s.px10, _s.pt15, _s.pb10].join(' ')}>
      <Text weight='bold' size='medium' color='white' className={[_s.d, _s.circle, _s.bgBrandDark, _s.px10, _s.py2, _s.mb5, _s.mr10].join(' ')}>
        <Icon id='shop' size='10px' className={_s.mr5} />
        {type}
      </Text>
      <Text size='medium' weight='medium' className={[_s.mb5, _s.maxW100PC].join(' ')}>
        {amount ? `${amount} ` : ''}with code&nbsp;
        <Text size='medium' weight='extraBold'>{code}</Text>
      </Text>
    </div>
  )
}

export default BusinessCoupon
