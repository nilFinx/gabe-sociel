import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { CX } from '../../constants'
import Text from '../text'

class BusinessStatusTag extends ImmutablePureComponent {

  render() {
    const { business } = this.props

    if (!business) return null

    const status = business.get('status')

    return (
      <div className={[_s.d, _s.flexRow].join(' ')}>
        <span
          className={[_s.text, _s.outlineNone, _s.capitalize, _s.radiusSmall, _s.fw600, _s.overflowHidden, _s.font, _s.px5, _s.py5].join(' ')}
          style={{
            backgroundColor: status === 'pending' ? 'orange' : status === 'rejected' ? '#EB524A' : '#2AC874',
            color: status === 'pending' ? '#000' : status === 'rejected' ? '#fff' : '#fff',
          }}
        >
          {status}
        </span>
      </div>
    )
  }
}

const mapStateToProps = (state, { id }) => ({
  business: state.getIn(['businesses', 'items', `${id}`]),
})

BusinessStatusTag.propTypes = {
  id: PropTypes.string,
  business: ImmutablePropTypes.map,
}

export default withRouter(connect(mapStateToProps)(BusinessStatusTag))
