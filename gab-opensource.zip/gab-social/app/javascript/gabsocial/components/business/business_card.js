import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { CX } from '../../constants'
import { fetchBusinessById } from '../../actions/businesses'
import Text from '../text'
import Image from '../image'
import VerifiedBusinessIcon from '../verified_business_icon'

class BusinessCard extends ImmutablePureComponent {

  state = {
    isHovering: false,
  }

  componentDidMount() {
    const { item, onFetchBusinessById, id } = this.props

    // if (!item) onFetchBusinessById(id)
  }

  handleOnMouseEnter = () => {
    this.setState({ isHovering: true })
  }

  handleOnMouseLeave = () => {
    this.setState({ isHovering: false })
  }

  handleOnClick = (e) => {
    const { item, history } = this.props
    const url = `/business/${item.get('id')}`
    history.push(url)
  }

  render() {
    const { item, isInline, isFeatured } = this.props
    const { isHovering } = this.state

    if (!item) return null

    const hasImg = !!item.get('logo_thumbnail_url') && item.get('logo_thumbnail_url').indexOf('missing.png') === -1

    const theImage = hasImg ? (
      <Image
        src={item.get('logo_thumbnail_url')}
        width={isFeatured ? 42 : 26}
        height={isFeatured ? 42 : 26}
        className={[_s.mr10, _s.displayInline, _s.radiusTiny].join(' ')}
      />
    ) : (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className={[_s.mr10, _s.displayInline, _s.radiusTiny].join(' ')}
        fill="#62CB82"
        height={isFeatured ? '42px' : '26px'}
        width={isFeatured ? '42px' : '26px'}
        version="1.1"
        viewBox="0 0 32 32"
        xmlSpace="preserve"
      >
        <g>
          <path d="M5,8v17c0,0.6,0.4,1,1,1h20c0.6,0,1-0.4,1-1V8c0.6,0,1-0.4,1-1s-0.4-1-1-1h-4h-7H9H5C4.4,6,4,6.4,4,7S4.4,8,5,8z M15,21h-5   v-3h5V21z M17,18h5v3h-5V18z M22,16h-5v-3h5V16z M15,16h-5v-3h5V16z M22,11h-5V8h5V11z M15,8v3h-5V8H15z"/>
          <path d="M9,5h14c0.6,0,1-0.4,1-1s-0.4-1-1-1H9C8.4,3,8,3.4,8,4S8.4,5,9,5z"/>
          <path d="M29,27H3c-0.6,0-1,0.4-1,1s0.4,1,1,1h26c0.6,0,1-0.4,1-1S29.6,27,29,27z"/>
        </g>
      </svg>
    )


    const nameClasses = CX({
      flexRow: 1,
      lineHeight15: 1,
      verticalAlignTop: 1,
      // underline: isHovering,
    })


    const hasCover = !!item.get('cover_image_url') && item.get('cover_image_url').indexOf('missing.png') === -1
    const theCover = hasCover ? item.get('cover_image_url') : '/headers/original/gab-cover-placeholder-2.png'

    return (
      <button
        className={[_s.d, _s.border1PX, _s.borderColorInput, _s.outlineNone, _s.radiusSmall, _s.bgTransparent, _s.cursorPointer, _s.flexGrow1, _s.noUnderline, _s.overflowHidden].join(' ')}
        onClick={this.handleOnClick}
        onMouseEnter={this.handleOnMouseEnter}
        onMouseLeave={this.handleOnMouseLeave}
      >
        <div className={[_s.d].join(' ')}>
          <div className={[_s.d, _s.w100PC].join(' ')}>
            <Image className={hasCover ? undefined : _s.opacity075} height={isFeatured ? '110px' : '120px'} width='100%' src={theCover} />
          </div>
          <div className={[_s.d, _s.w100PC, _s.px10, _s.py10].join(' ')}>
            {!isInline && theImage}
            <span className={[_s.text, _s.textAlignLeft].join(' ')}>
              {isInline && theImage}
              <Text weight='bold' size='medium' className={nameClasses}>
                {item.get('name')}
              </Text>
              <VerifiedBusinessIcon className={[_s.ml2, _s.mb2].join(' ')} size='20px' proTier={item.get('pro_tier')} />
            </span>
            <Text color='secondary' className={[_s.mt2].join(' ')}>{item.get('tagline')}</Text>
            { /*
              isFeatured &&
              <div className={[_s.d, _s.flexRow, _s.flexWrap, _s.mt5].join(' ')}>
                <Text className={[_s.bgSecondary, _s.radiusTiny, _s.px5, _s.mt2, _s.py2].join(' ')}>Featured</Text>
                <Text className={[_s.bgSecondary, _s.radiusTiny, _s.px5, _s.mt2, _s.py2, _s.ml5].join(' ')}>Shop Now</Text>
              </div>
            */}
          </div>
        </div>
      </button>
    )
  }
}

const mapStateToProps = (state, { id }) => ({
  item: state.getIn(['businesses', 'items', `${id}`]),
})

const mapDispatchToProps = (dispatch) => ({
  onFetchBusinessById(id) {
    dispatch(fetchBusinessById(id))
  },
})

BusinessCard.propTypes = {
  id: PropTypes.string,
  item: ImmutablePropTypes.map,
  onFetchBusinessById: PropTypes.func,
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(BusinessCard))
