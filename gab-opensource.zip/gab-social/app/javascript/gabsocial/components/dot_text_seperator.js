import React from 'react'
import Text from './text'

const DotTextSeperator = () => (
  <Text size='small' color='secondary' className={_s.ml5}>·</Text>
)

export default DotTextSeperator