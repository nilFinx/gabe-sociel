import React, { Fragment } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import Avatar from './avatar'
import AccountActionButton from './account_action_button'
import DisplayName from './display_name'
import Divider from './divider'
import Icon from './icon'
import Text from './text'
import moment from 'moment-mini'
import { makeGetAccount } from '../selectors'
import { NavLink } from 'react-router-dom'

/**
 *
 */
class AccountCard extends React.PureComponent {

  render() {
    const { account, id } = this.props

    if (!account || !id) return null

    // const fields = account.get('fields')
    const content = { __html: account.get('note') }
    const memberSinceDate = account.get('created_at')
    const hasNote = !!content ? (account.get('note').length > 0 && account.get('note') !== '<p></p>') : false
    const isPro = account.get('is_pro')
    const isDonor = account.get('is_donor')
    const isInvestor = account.get('is_investor')
    const hasBadges = isPro || isDonor || isInvestor
    const proBadgeTitle = isPro && account.get('show_pro_life') ? 'PRO Life' : 'PRO'
    const to = `/${account.get('acct')}`
    
    return (
      <div className={[_s.d, _s.w100PC].join(' ')}>
        <div className={[ _s.d, _s.flexNormal].join(' ')}>
          <div className={[_s.d, _s.w100PC, _s.px10, _s.pt10, _s.pb5].join(' ')}>
            <div className={[_s.d, _s.w100PC, _s.flexRow, _s.aiCenter, _s.jcSpaceBetween].join(' ')}>
              <NavLink
                to={to}
                className={[_s.d, _s.noUnderline, _s.flexGrow1].join(' ')}
              >
                <Avatar size={42} account={account} />
              </NavLink>
              <AccountActionButton account={account} />
            </div>
            <NavLink to={to} className={[_s.d, _s.mt10, _s.noUnderline].join(' ')}>
              <DisplayName relationshipsNextLine account={account} className={[_s.d, _s.cPrimary, _s.noUnderline].join(' ')} isMultiline />
            </NavLink>
            <div className={[_s.d, _s.mt10].join(' ')}>
              <div>
                <div className={[_s.d].join(' ')}>
                  {hasNote && (
                    <Fragment>
                      <div
                        dangerouslySetInnerHTML={content}
                        className={[_s.dangerousContent, _s.pb5].join(' ')}
                      />
                      <div className={[_s.d, _s.w100PC, _s.borderColorSecondary, _s.borderTop1PX].join(' ')} />
                    </Fragment>
                  )}

                  <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.py5, _s.mb5].join(' ')}>
                    <Icon id="calendar" size="14px" className={_s.cSecondary} />
                    <Text color="secondary" className={_s.ml5}>{`Joined ${moment(memberSinceDate).format('MMMM YYYY')}`}</Text>
                  </div>

                  {hasBadges && (
                    <Fragment>
                      <div className={[_s.d, _s.py10, _s.flexRow, _s.aiCenter, _s.borderBottom1PX, _s.borderTop1PX, _s.borderColorSecondary].join(' ')}>
                        {isPro && (
                          <div className={[_s.mr5, _s.radiusSmall, _s.bgPro, _s.py2, _s.px5].join(' ')}>
                            <Text weight="bold" className={_s.colorBGPrimary}>{proBadgeTitle}</Text>
                          </div>
                        )}
                        {isInvestor && (
                          <div className={[_s.mr5, _s.radiusSmall, _s.bgInvestor, _s.py2, _s.px5].join(' ')}>
                            <Text weight="bold" className={_s.colorBGPrimary}>INVESTOR</Text>
                          </div>
                        )}
                        {isDonor && (
                          <div className={[_s.mr5, _s.radiusSmall, _s.bgDonor, _s.py2, _s.px5].join(' ')}>
                            <Text weight="bold" className={_s.colorBGPrimary}>DONOR</Text>
                          </div>
                        )}
                      </div>
                    </Fragment>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

const makeMapStateToProps = (state, props) => ({
  account: makeGetAccount()(state, props.id),
})

AccountCard.propTypes = {
  id: PropTypes.string,
}

export default connect(makeMapStateToProps)(AccountCard)