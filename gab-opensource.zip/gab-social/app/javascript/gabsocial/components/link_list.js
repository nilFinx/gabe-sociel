import React from 'react'
import PropTypes from 'prop-types'
import { List as ImmutableList } from 'immutable'
import { connect } from 'react-redux'
import { Map as ImmutableMap } from 'immutable'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { many } from '../utils/arrays'
import PreviewCardItem from '../components/preview_card_item'
import TrendsItemPlaceholder from '../components/placeholder/trends_item_placeholder'
import ScrollableList from './scrollable_list'
import Text from './text'

class LinkList extends ImmutablePureComponent {

  load = () => {
    const { id, dispatch, params, onExpand } = this.props
    if (!id || id === -1) return
    dispatch(onExpand(id, params))
  }

  componentDidMount() {
    this.load()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.id && prevProps.id !== this.props.id) {
      this.load()
    }
  }

	render() {
		const {
      id,
      ids,
      type,
      isLoading,
      isFetched,
      hasNext,
      onClick,
      max,
      noPagination,
    } = this.props

    const showLoading = hasNext && isLoading
    const hasItems = ids && ids.size > 0
    const finalIds = !!max && !isNaN(max) && hasItems ? ids.slice(0, Math.min(ids.size, max)) : ids

    return (
      <ScrollableList
        scrollKey={`${type}-${id}-links`}
        onLoadMore={noPagination ? undefined : this.load}
        isLoading={isLoading}
        hasMore={!!hasNext}
      >
        {!hasItems && isFetched && 
        <div className={[_s.d, _s.px15, _s.pt5, _s.pb15, _s.mt15, _s.w100PC].join(' ')}>
          <Text color='tertiary' align='center'>No links found</Text>
        </div>
        }
        {hasItems && finalIds.map((id, i) => (
          <PreviewCardItem
            id={id}
            isExpanded
            key={`preview-card-${id}-${i}`}
          />
        ))}
        
        {showLoading && many(4, (i) => (
          <TrendsItemPlaceholder key={`trends-item-placeholder-${i}`} />
        ))}
      </ScrollableList>
    )
	}

}

const mapStateToProps = (state, { type, id }) => {
  const data = state.getIn(['links', type, id], ImmutableMap())

	return {
    ids: data.get('items', ImmutableList()),
    isLoading: data.get('isLoading'),
    isFetched: data.get('isFetched'),
    hasNext: !!data.get('next'),
  }
}

LinkList.propTypes = {
	id: PropTypes.map,
  max: PropTypes.number,
  minWidth: PropTypes.number,
  type: PropTypes.string,
  onClick: PropTypes.func,
  params: PropTypes.object,
  noPagination: PropTypes.bool,
}

export default connect(mapStateToProps)(LinkList)
