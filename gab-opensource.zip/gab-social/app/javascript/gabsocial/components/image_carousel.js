import React, { useState } from 'react'
import PropTypes from 'prop-types'
import ReactSwipeableViews from 'react-swipeable-views'
import Button from './button'
import Image from './image'
import { CX } from '../constants'

class ImageCarousel extends React.PureComponent {
  
  state = {
    index: this.props.initialIndex || 0,
  }
  
  handleSwipe = (i) => {
    const { images } = this.props
    const imagesCount = images.length
    this.setState({index: i % imagesCount})
  }

  handleNextClick = () => {
    const { images } = this.props
    const { index } = this.state
    const imagesCount = images.length
    this.setState({index: (index + 1) % imagesCount})
  }

  handlePrevClick = () => {
    const { images } = this.props
    const { index } = this.state
    const imagesCount = images.length
    this.setState({index: (imagesCount + index - 1) % imagesCount})
  }

  handleOnChangeIndex = (i) => {
    const { onChangeIndex } = this.props
    const newIndex = i
    this.setState({ index: newIndex })
    !!onChangeIndex && onChangeIndex(newIndex)
  }

  render() {
    const { images, initialIndex, onChangeIndex } = this.props
    const { index, navigationHidden } = this.state
  
    const imagesCount = images.length
  
    // you can't use 100vh, because the viewport height is taller
    // than the visible part of the document in some mobile
    // browsers when it's address bar is visible.
    // https://developers.google.com/web/updates/2016/12/url-bar-resizing
    const minimapTotalHeight = imagesCount > 1 ? '70px' : '0px'
    const adjustedWrapperHeight = `calc(100% - ${minimapTotalHeight})`
    const swipeableViewsStyle = {
      height: '100%',
      width: '100%',
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
      position: 'absolute',
    }
    const mediaSwipeableViewsStyle = {
      ...swipeableViewsStyle,
      height: adjustedWrapperHeight,
    }
    const containerStyle = {
      alignItems: 'center',
      width: '100%',
      height: '100%',
    }
    const slideStyle = {
      height: '100%',
      width: '100%',
      alignItems: 'center',
      justifyContent: 'center',
    }

    const navigationClasses = CX({
      d: 1,
      posAbs: 1,
      top50PC: 1,
      right0: 1,
      left0: 1,
      z2: 1,
    })

    const blurs = []
    const medias = []
    images.forEach((image) => {
      blurs.push(
        <div className={[_s.d, _s.flex1, _s.bgTransparent, _s.h100PC, _s.w100PC].join(' ')}>
          <div className={[_s.d, _s.posAbs, _s.top0, _s.right0, _s.bottom0, _s.left0].join(' ')} style={{ filter: 'blur(25px)', transform: 'scale(1.5)' }}>
            <Image cfWidthPX='1000px' src={image} height='100%' width='100%' />
          </div>
        </div>
      )
        medias.push(
          <div className={[_s.d, _s.flex1, _s.bgTransparent, _s.h100PC, _s.w100PC].join(' ')}>
            <Image
              src={image}
              cfWidthPX='1000px'
              width='100%'
              height='100%'
              fit='contain'
              className={[_s.posAbs, _s.right0, _s.left0, _s.bottom0, _s.top0].join(' ')}
            />
          </div>
        )
    })

    return (
      <div className={[_s.d, _s.w100PC, _s.h100PC, _s.aiCenter, _s.jcCenter].join(' ')}>
        <div
          role='presentation'
          className={[_s.d, _s.h100PC, _s.w100PC].join(' ')}
          data-presentation='carousel'
        >
          <ReactSwipeableViews
            style={swipeableViewsStyle}
            containerStyle={containerStyle}
            slideStyle={slideStyle}
            onChangeIndex={this.handleOnChangeIndex}
            index={index}
          >
            {blurs}
          </ReactSwipeableViews>
          <ReactSwipeableViews
            style={mediaSwipeableViewsStyle}
            containerStyle={containerStyle}
            slideStyle={slideStyle}
            onChangeIndex={this.handleOnChangeIndex}
            index={index}
          >
            {medias}
          </ReactSwipeableViews>

          <div className={navigationClasses}>
            {
              imagesCount > 1 && (
                <Button
                circle
                  tabIndex='0'
                  backgroundColor='black'
                  className={[
                    _s.py15,
                    _s.posAbs,
                    _s.top50PC,
                    _s.left0,
                    _s.mtNeg26PX,
                    _s.ml10,
                    _s.z4,
                  ].join(' ')}
                  onClick={this.handlePrevClick}
                  aria-label='Previous'
                  icon='arrow-left'
                  iconSize='18px'
                />
              )
            }

            {
              imagesCount > 1 && (
                <Button
                  circle
                  tabIndex='0'
                  backgroundColor='black'
                  className={[
                    _s.py15,
                    _s.posAbs,
                    _s.top50PC,
                    _s.right0,
                    _s.mtNeg26PX,
                    _s.mr10,
                    _s.z4,
                  ].join(' ')}
                  onClick={this.handleNextClick}
                  aria-label='Next'
                  icon='arrow-right'
                  iconSize='18px'
                />
              )
            }
          </div>
        </div>

        {
          imagesCount > 1 &&
          <div
            className={[
              _s.d,
              _s.aiCenter,
              _s.jcCenter,
              _s.mt10,
              _s.pl15,
              _s.pr5,
              _s.overflowXScroll,
              _s.posAbs,
              _s.bottom0,
              _s.right0,
              _s.left0,
              _s.flexRow,
              _s.w100PC,
              _s.h60PX,
              _s.noSelect,
            ].join(' ')}
          >
            {images.map((image, i) => {
              return (
                <button
                  key={`carousel-minimap-item-${i}`}
                  className={[
                    _s.d,
                    _s.outlineNone,
                    _s.overflowHidden,
                    _s.bgTransparent,
                    _s.noUnderline,
                    _s.cursorPointer,
                    _s.h40PX,
                    _s.w40PX,
                    _s.radiusSmall,
                    _s.mr10,
                    index !== i && _s.animations_button,
                    index !== i && _s.opacity05,
                    index !== i && _s.opacity1_onHover,
                  ].filter(Boolean).join(' ')}
                  onClick={() => this.handleOnChangeIndex(i)}
                >
                  <Image
                    src={image}
                    cfWidthPX='40px'
                    width='100%'
                    height='100%'
                    fit='cover'
                    className={[_s.posAbs, _s.right0, _s.left0, _s.bottom0, _s.top0].join(' ')}
                  />
                </button>
              )
            })}
          </div>
        }
      </div>
    )
  }
}

ImageCarousel.defaultProps = {
  initialIndex: 0,
}

ImageCarousel.propTypes = {
  images: PropTypes.array,
  initialIndex: PropTypes.number,
  onChangeIndex: PropTypes.func,
  showPagination: PropTypes.bool,
}

export default ImageCarousel
