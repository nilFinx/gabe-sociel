import React, { useState } from 'react'
import PropTypes from 'prop-types'
import ImmutablePropTypes from 'react-immutable-proptypes'
import isObject from 'lodash/isObject'
import Blurhash from './blurhash'
import Icon from './icon'
import Video from './video'
import GifVideo from './gif_video'
import Gif from './gif'
import Image from './image'
import LoadingIcon from './loading'
import ZoomableImage from './zoomable_image'
import { isPortrait, isPanoramic, isNonConformingRatio } from '../utils/media_aspect_ratio'
import { MEDIA_SINGLE_MAX_HEIGHT } from '../constants'

function RenderVideo({ attachment, height, width, size, isInModal, isInline, controls, autoplay, startTime, loop }) {
  if (size > 1) {
    return (
      <div className={[_s.cursorPointer, _s.d, _s.w100PC, _s.h100PC, _s.z1].join(' ')}>
        <img className={[_s.d, _s.h100PC, _s.objectFitCover].join(' ')} src={attachment.get('preview_url')} /> 
        <div className={[_s.d, _s.posAbs, _s.top0, _s.bottom0, _s.right0, _s.left0, _s.aiCenter, _s.jcCenter].join(' ')}>
          <div className={[_s.d, _s.cursorPointer, _s.aiCenter, _s.jcCenter, _s.circle, _s.w60PX, _s.h60PX, _s.border2PX, _s.bgBlackOpaquest, _s.borderColorWhite].join(' ')}>
            <Icon id='play' className={[_s.ml2, _s.cWhite].join(' ')} size='22px' />
          </div>
        </div>
      </div>
    )
  }

  return (
    <Video
      inline={isInline}
      controls={controls}
      autoplay={!!autoplay ? 'true' : undefined}
      height={height}
      width={width}
      loop={loop}
      size={size}
      startTime={startTime}
      className={[
        _s.w100PC,
        _s.h100PC,
        isInModal ? _s.objectFitContain : _s.objectFitCover,
        isInModal ? _s.z2 : undefined,
        isInModal ? 'in-gallery-modal' : undefined
      ].join(' ')}
      preview={attachment.get('preview_url')}
      blurhash={attachment.get('blurhash')}
      src={attachment.get('url')}
      key={attachment.get('url') || attachment.get('source_mp4')}
      sourceMp4={attachment.get('source_mp4')}
      alt={attachment.get('description')}
      aspectRatio={attachment.getIn(['meta', 'small', 'aspect']) || attachment.getIn(['meta', 'original', 'aspect']) || 1.4}
      fileContentType={attachment.get('file_content_type')}
      meta={attachment.get('meta')}
      shouldStopAllOtherPlayers={isInModal}
    />
  )
}

function RenderWebm({ attachment, height, width, size, isInModal, isInline, controls, autoplay, startTime, loop }) {
  return (
    <Video
      inline={isInline}
      controls={controls}
      autoplay={!!autoplay ? 'true' : undefined}
      height={height}
      width={width}
      loop={loop}
      size={size}
      startTime={startTime}
      className={[
        _s.w100PC,
        _s.h100PC,
        isInModal ? _s.objectFitContain : _s.objectFitCover,
        isInModal ? _s.z2 : undefined,
        isInModal ? 'in-gallery-modal' : undefined
      ].join(' ')}
      blurhash={attachment.get('blurhash')}
      src={attachment.get('url')}
      key={attachment.get('url') || attachment.get('source_mp4')}
      sourceMp4={attachment.get('source_mp4')}
      alt={attachment.get('description')}
      aspectRatio={attachment.getIn(['meta', 'small', 'aspect']) || attachment.getIn(['meta', 'original', 'aspect']) || 1.4}
      fileContentType={attachment.get('file_content_type')}
      meta={attachment.get('meta')}
      shouldStopAllOtherPlayers={isInModal}
    />
  )
}

function MediaGalleryItemWrapper(props) {
  return <MediaGalleryItem {...props} />
}

function MediaGalleryItem({
  index,
  photo,
  margin,
  direction,
  top,
  left,
  onClick = () => {},
}) {
  const [isLoaded, setIsLoaded] = useState(false)

  const { attachment, styles, size, isInModal, noBlurhash, autoplayVideo, blurhashOnly, onLoad, isInline, controls, startTime, loop, overflowed } = photo

  const aspectRatio = attachment.getIn(['meta', 'small', 'aspect']) || attachment.getIn(['meta', 'original', 'aspect']) || 1.4;

  const isGifV = attachment.get('type') === 'gifv'
  const isGif = !isGifV && (attachment.get('url') || '').split(/[#?]/)[0].split('.').pop().trim() == 'gif'
  const isWebm = (attachment.get('preview_url') || '').split(/[#?]/)[0].split('.').pop().trim() == 'webm'
  const isVideo = !isGif && !isGifV && attachment.get('type') === 'video'
  const isImage = !isVideo && !isGif && !isGifV

  // Calculate dimensions while respecting max height for portrait images
  let width = photo.width;
  let height = photo.height || (width == '100%' ? '100%' : width / aspectRatio);

  // Videos use fixed 1.4 aspect ratio
  if (isVideo && !isInModal) {
    height = Math.min(height, Math.floor(photo.width / 1.4));
  } else {
    height = width == '100%' ? '100%' : Math.floor(photo.width / aspectRatio);
  }

  // If it's a single image and portrait orientation, adjust the width to maintain aspect ratio
  if (size === 1 && !isVideo && isPortrait(aspectRatio) && !isInModal) {
    const maxHeight = MEDIA_SINGLE_MAX_HEIGHT;
    if (height == '100%' || height > maxHeight) {
      // Recalculate width based on max height while maintaining aspect ratio  
      height = maxHeight;
      width = width == '100%' ? '100%' : Math.floor(maxHeight * aspectRatio);
    }
  }

  photo.height = height;
  photo.width = width;

  let cont = {
    margin,
    zIndex: 2,
    height: photo.height,
    width: photo.width,
    position: 'relative',
    overflow: 'hidden',
  }

  // For single portrait images, center the image container
  if (size === 1 && isPortrait(aspectRatio)) {
    cont = {
      ...cont,
      margin: 'auto',
      width: '100%',
      height: '100%', 
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      objectFit: 'contain',
    }
  }

  if (direction === 'column') {
    //cont.position = 'absolute'
    //cont.left = left
    //cont.top = top
  }
  if (isObject(styles)) {
    cont = {
      ...cont,
      ...styles,
    }
  }

  // Adjust container styles for modal view
  if (isInModal) {
    cont = {
      ...cont,
      width: '100%',
      height: '100%',
      margin: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      maxHeight: 'none', // Remove max-height constraint in modal
    }
  }

  function handleOnClick(e) {
    if (typeof onClick === 'function') {
      onClick(e, { index });
    }
  }

  function handleOnLoad() {
    setIsLoaded(true)
    !!onLoad && onLoad()
  }

  const ImageWrapper = isInModal ? ZoomableImage : Image
  const showBlurhash = (!isLoaded && !noBlurhash) || size === 1

  const containerStyle = {
    width: isInModal ? '100%' : width,
    height: isInModal ? '100%' : height,
    position: 'relative',
    zIndex: isInModal ? 2 : 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    ...(isInModal && isVideo ? { height: '90vh' } : {}), // Set full height for videos in modal
  }

  return (
    <div style={cont} onClick={handleOnClick} data-container='true' className={[
      isInModal ? 'media-gallery-item-in-modal' : undefined,
      isInModal ? _s.d : undefined,
      isInModal ? _s.w100PC : undefined,
      isInModal ? _s.h100PC : undefined,
      isInModal ? _s.aiCenter : undefined,
      isInModal ? _s.jcCenter : undefined,
    ].join(' ')}>
      {
        !isVideo && showBlurhash && attachment.get('blurhash') &&
        <Blurhash 
          hash={attachment.get('blurhash')} 
          className={[
            _s.d,
            _s.h100PC,
            _s.w100PC,
            _s.posAbs,
            _s.right0,
            _s.left0,
            _s.bottom0,
            _s.top0,
            isInModal ? _s.z0 : _s.z1
          ].join(' ')} 
        />
      }
      <div style={containerStyle}>
        {isVideo && !isWebm && !blurhashOnly && <RenderVideo isInline={isInline === undefined ? true : isInline} height={photo.height} width={photo.width} isInModal={isInModal} size={size} attachment={attachment} controls={controls === undefined ? true : controls} autoplay={autoplayVideo} startTime={startTime} loop={loop} />}
        {isWebm && !blurhashOnly && <RenderWebm isInline={isInline === undefined ? true : isInline} height={photo.height} width={photo.width} isInModal={isInModal} size={size} attachment={attachment} controls={controls === undefined ? true : controls} autoplay={autoplayVideo} startTime={startTime} loop={loop} />}
        {isGifV && !blurhashOnly && <GifVideo attachment={attachment} autoplay={isInModal} />}
        {isGif && !blurhashOnly && <Gif attachment={attachment} autoplay={isInModal} fit='cover' />}
        {(isImage || !isLoaded) && !isWebm && !blurhashOnly && (
          <ImageWrapper 
            isLazy 
            cfWidthPX={cont.width} 
            alt={attachment.get('description')} 
            src={photo.src} 
            height='100%'
            onError={onLoad} 
            onLoad={handleOnLoad} 
            fit={(isInModal || overflowed) ? 'contain' : 'cover'}
            style={isInModal ? {
              maxWidth: isGif ? '70%' : '100%',
              maxHeight: isGif ? '70%' : '100%',
              objectFit: 'contain',
            } : undefined}
          />
        )}
      </div>
      {
        (!isLoaded && noBlurhash && !blurhashOnly) &&
        <div className={[_s.d, _s.h100PC, _s.w100PC, _s.aiCenter, _s.jcCenter].join(' ')}>
          <LoadingIcon />
        </div>
      }
    </div>
  )
}

MediaGalleryItemWrapper.propTypes = {
  attachment: ImmutablePropTypes.map,
  index: PropTypes.number,
  onClick: PropTypes.func,
  isVisible: PropTypes.bool,
}

export default MediaGalleryItemWrapper
