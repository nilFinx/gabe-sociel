import React from 'react'
import { connect } from 'react-redux'
import { openModal } from '../actions/modal'
import { CX, MODAL_CONFIRM, MODAL_PRO_UPGRADE, MODAL_AD, MODAL_DONATE } from '../constants'
import { isPro } from '../initial_state'
import Button from './button'
import Text from './text'

class HomeCallToAction extends React.PureComponent {

  state = {
    dismissed: false,
    cta: null,
  }

  componentDidMount() {
    // set new cta
    this.selectRandomCta()
    let ran = Math.random()
    if (!isPro && ran <= 0.23) {
      this.props.dispatch(openModal(MODAL_AD))
    }
  }

  componentDidUpdate(prevProps) {
    if (prevProps.ctas && this.props.ctas && prevProps.ctas.size === 0 && this.props.ctas.size > 0 && !this.state.cta) {
      this.selectRandomCta()
    } else if (!this.state.cta) {
      this.selectRandomCta()
    }
  }
  
  selectRandomCta = () => {
    const { ctas } = this.props
    const validCtas = ctas.filter((cta) => cta && localStorage.getItem(cta.get('id')) !== '2')

    if (validCtas.size > 0) {
      const randomIndex = Math.floor(Math.random() * validCtas.size)
      const selectedCta = validCtas.get(randomIndex)
      this.setState({ cta: selectedCta.toJS() })
    }
  }

  handleOnDismissNow = () => {
    const { cta } = this.state
    if (cta) {
      localStorage.setItem(cta.id, '2')
      this.setState({ dismissed: true, cta:null })
    }
  }

  handleOnGoPro = () => {
    const { cta } = this.state

    if (!isPro) {
      this.props.dispatch(openModal(MODAL_PRO_UPGRADE, { ctaId: cta?.id }))      
    }
  }

  handleOnDonate = () => {
    const { cta } = this.state
    this.props.dispatch(openModal(MODAL_DONATE, { ctaId: cta?.id }))
  }

  handleOnDismiss = () => {
    this.handleOnDismissNow()
  }

  render() {
    const { isXS } = this.props
    const { dismissed, cta } = this.state
    
    if (dismissed || !cta) return null
    const localStorageDismissed = localStorage.getItem(cta.id) === '2'
    if (localStorageDismissed) return null

    const containerClasses = CX({
      d: 1,
      px15: 1,
      mt15: isXS,
      pt10: 1,
      pb15: 1,
      mb15: !isXS,
      w100PC: 1,
      bgPrimary: 1,
      radiusSmall: !isXS,
      boxShadowBlock: 1,
    })

    return (
      <div className={containerClasses}>
        <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.mb5].join(' ')}>
          <Text size='large' weight='bold' className={_s.maxW80PC}>{cta.title}</Text>
          <Button
            circle
            icon='close'
            iconSize='10px'
            backgroundColor='secondary'
            color='secondary'
            onClick={this.handleOnDismiss}
            className={[_s.h30PX, _s.w30PX, _s.aiCenter, _s.jcCenter, _s.mlAuto].join(' ')}
          />
        </div>
        <Text>{cta.content}</Text>
        <div className={[_s.d, _s.flexRow, _s.flexWrap].join(' ')}>
          {
            (!!cta.secondaryBtnTitle && !!cta.secondaryBtnAction) &&
            <Button
              radiusSmall
              backgroundColor='tertiary'
              color='primary'
              onClick={
                cta.secondaryBtnAction === 'go-pro' ? this.handleOnGoPro : 
                cta.secondaryBtnAction === 'donate' ? this.handleOnDonate :
                undefined
              }
              href={
                ['donate', 'go-pro'].indexOf(cta.secondaryBtnAction) === -1 ? cta.secondaryBtnAction : undefined
              }
              className={[_s.mt15, _s.mr10].join(' ')}
            >
              <Text color='inherit' weight='medium' size={isXS ? '' : 'medium'}>{cta.secondaryBtnTitle}</Text>
            </Button>
          }
          {
            (!!cta.primaryBtnTitle && !!cta.primaryBtnAction) &&
            <Button
              radiusSmall
              isBlock={isXS}
              target='_blank'
              onClick={
                cta.primaryBtnAction === 'go-pro' ? this.handleOnGoPro : 
                cta.primaryBtnAction === 'donate' ? this.handleOnDonate :
                undefined
              }
              href={
                ['donate', 'go-pro'].indexOf(cta.primaryBtnAction) === -1  ? cta.primaryBtnAction : undefined
              }
              className={[_s.mt15].join(' ')}
            >
              <Text color='inherit' align='center' weight='bold' size={isXS ? '' : 'medium'}>{cta.primaryBtnTitle}</Text>
            </Button>
          }
        </div>
      </div>
    )
  }
}


const mapStateToProps = (state) => ({
  ctas: state.getIn(['call_to_actions', 'items']),
})

export default connect(mapStateToProps)(HomeCallToAction)
