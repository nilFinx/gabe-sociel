import React from 'react'
import PropTypes from 'prop-types'
import { CX } from '../constants'

function Badge({ children, text, className }) {
  
  const classes = CX(className, {
    displayInlineBlock: 1,
    text: 1,
    textAlignCenter: 1,
    lineHeight125: 1,
    fs12PX: 1,
    px10: 1,
    py2: 1,
    circle: 1,
    bgRed: 1,
    cWhite: 1,
  })

  
  return (
    <span className={classes}>
      {children || text}
    </span>
  )
}

Badge.propTypes = {
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  text: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  className: PropTypes.string,
}

export default Badge
