import React,{ memo } from 'react'
import { me } from '../initial_state'
import Pills from './pills'

function ExploreTimelinePills() {
  const exploreItems = [
    {
      title: 'Explore',
      to: !!me ? '/explore' : '/',
    },
    {
      title: 'PRO Feed',
      to: '/timeline/pro',
    },
    {
      title: 'Gab TV',
      to: '/timeline/videos',
    },
    {
      title: 'Photos',
      to: '/timeline/photos',
    },
    {
      title: 'Clips',
      to: '/timeline/clips',
    },
    {
      title: 'Polls',
      to: '/timeline/polls',
    },
  ]
  
  return (
    <div className={[_s.d, _s.overflowYHidden, _s.bgPrimary, _s.borderBottom1PX, _s.borderColorSecondary, _s.pt10, _s.pb5, _s.flexRow].join(' ')}>
      <Pills pills={exploreItems} wrap />
    </div>
  )
}


export default memo(ExploreTimelinePills)