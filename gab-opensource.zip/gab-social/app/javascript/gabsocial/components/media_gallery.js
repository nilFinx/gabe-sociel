import React from 'react'
import PropTypes from 'prop-types'
import Gallery from 'react-photo-gallery'
import { connect } from 'react-redux'
import { parse, format } from 'url'
import ImmutablePropTypes from 'react-immutable-proptypes';
import ImmutablePureComponent from 'react-immutable-pure-component';
import { is } from 'immutable';
import { displayMedia } from '../initial_state'
import { BREAKPOINT_EXTRA_SMALL, CX, MEDIA_SINGLE_MAX_HEIGHT } from '../constants'
import Button from './button'
import SensitiveMediaItem from './sensitive_media_item'
import MediaGalleryItem from './media_gallery_item'
import { isPanoramic, isPortrait, maximumAspectRatio, minimumAspectRatio } from '../utils/media_aspect_ratio'
import { withRouter } from 'react-router-dom'

class MediaGallery extends ImmutablePureComponent {

  state = {
    visible: this.props.visible !== undefined ? this.props.visible : (displayMedia !== 'hide_all' && !this.props.sensitive || displayMedia === 'show_all'),
    loaded: false,
  };

  componentDidUpdate(prevProps) {
    if (this.props.mediaAttachmentId !== prevProps.mediaAttachmentId && this.props.isVisible === undefined) {
      this.setState({
        isVisible: displayMedia !== 'hide_all' && !this.props.sensitive || displayMedia === 'show_all',
      });
    } else if (this.props.isVisible !== prevProps.isVisible && this.props.isVisible !== undefined) {
      this.setState({ isVisible: this.props.isVisible });
    }
  }

  handleOpen = () => {
    this.setState({ visible: !this.state.visible });
  }

  handleClick = (e, { index }) => {
    const { isXS, history, media, onOpenMedia, isFromChat } = this.props
    
    if (isXS || isFromChat) {
      if (typeof onOpenMedia === 'function') {
        window.location.hash = `${Math.random().toString(36).substring(2, 15)}`;
        setTimeout(() => {
          onOpenMedia(media, index);
        }, 100);
      } else {
        console.warn('onOpenMedia is not defined or is not a function');
      }
    } else {
      const mediaItem = media.get(index)
      // if is video, and only 1 media then just play it right in feed
      if (media.size === 1 && mediaItem.get('type') === 'video') {
        return true
      } else {
        // otherwise open up in media page
        const url = `${mediaItem.get("status_url")}/media/${index + 1}`
        history.push(url, { state: history.location })
      }
    }
  }

  handleOnLoad = () => {
    this.setState({ loaded: true })
  }

  handleOnClick = () => {
    const { mediaAttachment, onClick } = this.props;
    if (typeof onClick === 'function') {
      onClick(mediaAttachment);
    }
  };

  render() {
    const { media, sensitive, isXS, isComment, isNotification, blurhashOnly } = this.props
    const { visible, loaded } = this.state

    const size = media.size

    let limitNodeSearch = size
    let targetRowHeight = 320 //default
    let targetMediaWidth = 568 //default

    if (size === 8) {
      limitNodeSearch = 3
      targetRowHeight = 180
      targetMediaWidth = 320
    } else if (size === 7) {
      limitNodeSearch = 3
      targetRowHeight = 200
      targetMediaWidth = 355
    } else if (size === 6) {
      limitNodeSearch = 3
      targetRowHeight = 220
      targetMediaWidth = 390
    } else if (size === 5) {
      limitNodeSearch = 4
      targetRowHeight = 240
      targetMediaWidth = 426
    } else if (size === 4) {
      targetRowHeight = 260
      targetMediaWidth = 462
    } else if (size === 3) {
      targetRowHeight = 280
      targetMediaWidth = 498
    }

    if (isXS) {
      limitNodeSearch = size
      targetRowHeight = targetRowHeight - 40
    }
    if (isComment) {
      targetRowHeight = targetRowHeight - 40
    }
    if (isNotification) {
      limitNodeSearch = 8
      targetRowHeight = 112
    }

    let minHeight = targetRowHeight * limitNodeSearch

    const children = media.map((attachment) => {
      let src = attachment.get('preview_url')
      const originalUrl = attachment.get('url');
      if (!!originalUrl) {
          const parts = parse(originalUrl)
          parts.query = parts.query || {}
          parts.query.width = targetMediaWidth
          src = format(parts)
      }
      
      let height = targetRowHeight
      let width
      let overflowed = false
      
      if (size === 1) {
        // Single image can use original aspect ratio with max height
        const aspectRatio = attachment.getIn(['meta', 'small', 'aspect']) || attachment.getIn(['meta', 'original', 'aspect']) || 1.4
        if (isPanoramic(aspectRatio)) {
          width = height * maximumAspectRatio
        } else if (isPortrait(aspectRatio)) {
          height = Math.min(targetRowHeight, MEDIA_SINGLE_MAX_HEIGHT)
          width = height * minimumAspectRatio
          overflowed = height === MEDIA_SINGLE_MAX_HEIGHT
        } else {
          width = height * aspectRatio
        }
        if (isNotification) height = 100
      } else {
        // Multi-image layout: maintain aspect ratio within constraints
        const originalAspect = attachment.getIn(['meta', 'small', 'aspect']) || attachment.getIn(['meta', 'original', 'aspect']) || 1
        const maxAspectRatio = 5 // Maximum width:height ratio for grid items
        const minAspectRatio = 0.35 // Minimum width:height ratio for grid items
        
        // Constrain aspect ratio to ensure uniform cells
        const aspectRatio = Math.max(minAspectRatio, Math.min(maxAspectRatio, originalAspect))
        width = height * aspectRatio
      }

      return {
        attachment,
        size,
        src,
        blurhashOnly,
        height,
        width,
        overflowed,
        onLoad: this.handleOnLoad,
      }
    }).toJS()
  
    const containerClasses = CX({
      d: 1,
      displayBlock: 1,
      overflowHidden: 0,
      borderColorSecondary: size === 1 && visible,
      borderTop1PX: size === 1 && visible,
      borderBottom1PX: size === 1 && visible,
    })

    return (
      <div className={containerClasses}>
        {
          !visible && sensitive &&
          <SensitiveMediaItem
            onClick={this.handleOpen}
            message='The author of this gab has added a warning to this media.'
            btnTitle='View'
          />
        }
        
        {
          visible &&
          <div
            className={[_s.d, _s.displayBlock, _s.w100PC, _s.h100PC, _s.overflowHidden].join(' ')}
            style={!loaded ? {minHeight: `${minHeight}px`} : undefined}
          >
            <Gallery
              margin={1}
              limitNodeSearch={limitNodeSearch}
              targetRowHeight={targetRowHeight}
              photos={children}
              renderImage={MediaGalleryItem}
              onClick={this.handleClick}
            />
          </div>
        }

        {
          visible && sensitive &&
          <div className={[_s.posAbs, _s.z2, _s.top0, _s.right0, _s.mt10, _s.mr10].join(' ')}>
            <Button
              title='Hide media'
              icon='hidden'
              backgroundColor='black'
              className={[_s.px10, _s.bgBlackOpaque_onHover].join(' ')}
              onClick={this.handleOpen}
            />
          </div>
        }
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

MediaGallery.propTypes = {
  sensitive: PropTypes.bool,
  media: ImmutablePropTypes.list.isRequired,
  size: PropTypes.object,
  onOpenMedia: PropTypes.func,
  visible: PropTypes.bool,
  onToggleVisibility: PropTypes.func,
  reduced: PropTypes.bool,
  isComment: PropTypes.bool,
  isNotification: PropTypes.bool,
  blurhashOnly: PropTypes.bool,
}

export default withRouter(connect(mapStateToProps)(MediaGallery))
