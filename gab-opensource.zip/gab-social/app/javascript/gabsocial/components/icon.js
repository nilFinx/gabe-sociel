import React from 'react'
import PropTypes from 'prop-types'
import { CX } from '../constants'
import Logo from './logo'
import Loading from './loading'
import VerifiedAccountIcon from './verified_account_icon'
import VerifiedGroupIcon from './verified_group_icon'

class Icon extends React.PureComponent {

  render() {
    const {
      className,
      id,
      size,
      minimizeLogo,
    } = this.props

    if (id === 'logo') {
      if (minimizeLogo) {
        return (
          <div className={[_s.d, _s.px5, _s.py5, _s.circle, _s.bgNavigationBlendLight].join(' ')}>
            <i className={[_s.gfi, _s['gfi-gab-g'], _s.px5, _s.py5, _s.fillNavigationBrand].join(' ')} style={{fontSize: '22px'}} />
          </div>
        )
      }
      return <Logo className={className} />
    }
    else if (id === 'loading') return <Loading size={size} className={className} />
    else if (id === 'verified-account') return <VerifiedAccountIcon size={size} className={className} />
    else if (id === 'verified-group') return <VerifiedGroupIcon size={size} className={className} />
    else if (id === 'ai-robot') {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" className={className} width={size} height={size} viewBox="0 0 45.342 45.342">
          <g>
            <path d="M40.462,19.193H39.13v-1.872c0-3.021-2.476-5.458-5.496-5.458h-8.975v-4.49c1.18-0.683,1.973-1.959,1.973-3.423   c0-2.182-1.771-3.95-3.951-3.95c-2.183,0-3.963,1.769-3.963,3.95c0,1.464,0.785,2.74,1.965,3.423v4.49h-8.961   c-3.021,0-5.448,2.437-5.448,5.458v1.872H4.893c-1.701,0-3.091,1.407-3.091,3.108v6.653c0,1.7,1.39,3.095,3.091,3.095h1.381v1.887   c0,3.021,2.427,5.442,5.448,5.442h2.564v2.884c0,1.701,1.393,3.08,3.094,3.08h10.596c1.701,0,3.08-1.379,3.08-3.08v-2.883h2.578   c3.021,0,5.496-2.422,5.496-5.443V32.05h1.332c1.701,0,3.078-1.394,3.078-3.095v-6.653C43.54,20.601,42.165,19.193,40.462,19.193z    M10.681,21.271c0-1.999,1.621-3.618,3.619-3.618c1.998,0,3.617,1.619,3.617,3.618c0,1.999-1.619,3.618-3.617,3.618   C12.302,24.889,10.681,23.27,10.681,21.271z M27.606,34.473H17.75c-1.633,0-2.957-1.316-2.957-2.951   c0-1.633,1.324-2.949,2.957-2.949h9.857c1.633,0,2.957,1.316,2.957,2.949S29.239,34.473,27.606,34.473z M31.056,24.889   c-1.998,0-3.618-1.619-3.618-3.618c0-1.999,1.62-3.618,3.618-3.618c1.999,0,3.619,1.619,3.619,3.618   C34.675,23.27,33.055,24.889,31.056,24.889z"/>
          </g>
        </svg>
      )
    }

    const additionalClasses = {}
    additionalClasses.gfi = 1
    additionalClasses[`gfi-${id}`] = 1
      
    const classes = CX(className, additionalClasses)

    return <i style={{ fontSize: size }} className={classes} />

  }

}

Icon.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string.isRequired,
  size: PropTypes.string,
  minimizeLogo: PropTypes.bool,
}

export default Icon