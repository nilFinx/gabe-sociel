import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { NavLink } from 'react-router-dom'
import { BREAKPOINT_EXTRA_SMALL, CX } from '../constants'
import { PLACEHOLDER_MISSING_HEADER_SRC } from '../constants'
import { shortNumberFormat } from '../utils/numbers'
import Icon from './icon'
import Image from './image'
import Text from './text'
import Dummy from './dummy'
import GroupActionButton from './group_action_button'
import { parse, format } from 'url'


class GroupListItem extends ImmutablePureComponent {

  render() {
    const {
      group,
      isAddable,
      isLast,
      isHidden,
      isStatic,
      size,
      relationships,
      withDescription,
      withVisibility,
      padded,
      isXS,
    } = this.props

    if (!group) return null

    if (isHidden) {
      return (
        <React.Fragment>
          {group.get('title')}
        </React.Fragment>
      )
    }

    const isLarge = size === 'large'

    const containerClasses = CX({
      d: 1,
      overflowHidden: 1,
      bgSubtle_onHover: 1,
      radiusSmall: padded,
      borderColorSecondary: !padded,
      borderBottom1PX: !isLast && !padded,
      flexRow: !isXS,
      py5: !isLarge,
      py10: isLarge,
      pr5: !isXS && isAddable,
      w100PC: 1,
    })

    const containerLinkClasses = CX({
      d: 1,
      flexRow: 1,
      noUnderline: 1,
      w100PC: 1,
      flexGrow1: isAddable,
      flexShrink1: isAddable,
    })

    const coverImageClasses = CX({
      radiusSmall: 1,
      ml15: isLarge,
      ml10: !isLarge,
      h50PX: !isLarge,
      w50PX: !isLarge,
      h84PX: isLarge && !isXS,
      w158PX: isLarge && !isXS,
    })

    const btnContainerClasses = CX({
      d: 1,
      jcCenter: 1,
      flexGrow1: 1,
      px10: isXS,
      pt5: isXS,
    })
    
    const isVisible = group.get('is_visible')
    const coverSrc = group.get('cover_image_thumbnail_url') || group.get('cover_image_url') || ''
    const coverMissing = coverSrc.indexOf(PLACEHOLDER_MISSING_HEADER_SRC) > -1 || !coverSrc
    const memCount = group.get('member_count')
    const memCountFormatted = shortNumberFormat(memCount)
    const memberTitle = ` member${memCount === 0 || memCount > 1 ? 's' : '' }`
    const imageWidth = isXS ? '80px' : isLarge ? '158px' : '50px'

    const parts = parse(coverSrc)
    let pathname = parts.pathname
    //if (pathname.indexOf('cdn-cgi') === -1) {
    //  parts.pathname = `/cdn-cgi/image/width=120,quality=100,fit=scale-down${pathname}`
    //}
    const imgUrl = format(parts)

    let correctedDescription = group.get('description_html')
    const maxDescription = 160
    correctedDescription = correctedDescription.length >= maxDescription ? `${correctedDescription.substring(0, maxDescription).trim()}...` : correctedDescription

    const Wrapper = !isStatic ? NavLink : Dummy

    return (
      <div className={containerClasses}>
        <Wrapper
          to={`/groups/${group.get('id')}`}
          className={containerLinkClasses}
        >

          <Image
            isLazy
            cfWidthPX={imageWidth}
            width={imageWidth}
            height={isXS ? '50px' : 'auto'}
            src={coverMissing ? null : imgUrl}
            alt={group.get('title')}
            className={coverImageClasses}
          />

          <div className={[_s.d, _s.px10, _s.flexShrink1].join(' ')}>
            <div className={[_s.d, _s.flexRow, _s.mt2, _s.aiCenter].join(' ')}>
              <Text weight='bold' size={isLarge ? 'medium' : 'normal'}>
                {group.get('title')}
              </Text>
              {
                group.get('is_verified') &&
                <Icon id='verified-group' size='14px' className={_s.ml5} />
              }
            </div>
            
            <div className={[_s.d, _s.flexRow, _s.mt5].join(' ')}>
              {
                withVisibility &&
                <Text color='secondary' size='small' className={_s.mr5}>
                  {isVisible ? 'Visible group' : 'Invisible group'}
                  &nbsp;·
                </Text>
              }
              <Text color='secondary' size='small'>
                {memCountFormatted}
                {memberTitle}
              </Text>
            </div>
            
            {
              withDescription &&
              <div className={[_s.d, _s.pt5].join(' ')}>
                <Text color='secondary'>
                  <div
                    className={_s.dangerousContent}
                    dangerouslySetInnerHTML={{ __html: correctedDescription }}
                  />
                </Text>
              </div>
            }

          </div>
        </Wrapper>
        {
          isAddable &&
          <div className={btnContainerClasses}>
            <GroupActionButton
              group={group}
              relationships={relationships}
              size='small'
            />
          </div>
        }
      </div>
    )
  }

}

const mapStateToProps = (state, { id }) => ({
  group: state.getIn(['groups', id]),
  relationships: state.getIn(['group_relationships', id]),
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

GroupListItem.propTypes = {
  group: ImmutablePropTypes.map,
  isAddable: PropTypes.bool,
  isHidden: PropTypes.bool,
  isLast: PropTypes.bool,
  isStatic: PropTypes.bool,
  size: PropTypes.oneOf([
    'normal',
    'large',
  ]),
  withDescription: PropTypes.bool,
  withVisibility: PropTypes.bool,
  relationships: ImmutablePropTypes.map,
}

GroupListItem.defaultProps = {
  isLast: false,
  size: 'normal',
}

export default connect(mapStateToProps)(GroupListItem)
