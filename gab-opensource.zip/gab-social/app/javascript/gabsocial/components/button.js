import React from 'react'
import PropTypes from 'prop-types'
import isFunction from "lodash/isFunction"
import { NavLink } from 'react-router-dom'
import { CX } from '../constants'
import Icon from './icon'
import Tooltip from './tooltip'

// Define colors for enumeration for Button component `color`, `backgroundColor` props
const COLORS = {
  primary: 'primary',
  secondary: 'secondary',
  tertiary: 'tertiary',
  white: 'white',
  black: 'black',
  brand: 'brand',
  brandLight: 'brandLight',
  danger: 'danger',
  none: 'none',
}

/**
 * Renders a button component
 * @param {string} [props.backgroundColor='brand'] - background color of the button
 * @param {func|node} [props.buttonRef] - ref to send to button component
 * @param {string} [props.className] - add custom className
 * @param {string} [props.color='white'] - text color of the button
 * @param {string} [props.href] - href to send to on click
 * @param {string} [props.icon] - prepend icon id
 * @param {string} [props.iconClassName] - add custom className to icon
 * @param {string} [props.iconSize] - size of the icon
 * @param {bool} [props.isBlock] - if button is width: 100%
 * @param {bool} [props.isDisabled] - if the button is disabled
 * @param {bool} [props.isNarrow] - if the button is narrow
 * @param {bool} [props.isOutline] - if the button is outline design
 * @param {bool} [props.noClasses] - if the button has no default classes
 * @param {func} [props.onClick] - function to call on button click
 * @param {func} [props.onMouseEnter] - function to call on button mouse enter
 * @param {func} [props.onMouseLeave] - function to call on button mouse leave
 * @param {func} [props.onTouchStart] - function to call on button touch start
 * @param {func} [props.onTouchEnd] - function to call on button touch end
 * @param {bool} [props.radiusSmall] - if the button has small radius
 * @param {bool} [props.rel] - rel for the button
 * @param {bool} [props.target] - target for the button
 * @param {bool} [props.text] - if the button is just text (i.e. link)
 * @param {bool} [props.title] - `title` attribute for button
 * @param {bool} [props.to] - `to` to send to on click
 * @param {bool} [props.tooltip] - add a tooltip to the button on hover/click
 * @param {bool} [props.type] - `type` attribute for button
 * @param {bool} [props.underlineOnHover] - if the button has underline on hover
 */
class Button extends React.PureComponent {

  state = {
    isHovering: false,
  }

  handleClick = (e) => {
    const { onClick, isDisabled } = this.props
    if (!isDisabled && !!onClick) onClick(e)
  }

  handleOnTouchStart = (e) => {
    if (!this.props.isDisabled && !!this.props.onTouchStart) {
      this.props.onTouchStart(e)
    }
  }

  handleOnTouchEnd = (e) => {
    if (!this.props.isDisabled && !!this.props.onTouchEnd) {
      this.props.onTouchEnd(e)
    }
  }

  handleOnMouseEnter = () => {
    if (!this.props.isDisabled && !!this.props.onMouseEnter) {
      this.props.onMouseEnter()
    }
    if (this.props.tooltip) {
      this.setState({ isHovering: true }) 
    }
  }
  
  handleOnMouseLeave = () => {
    if (!this.props.isDisabled && !!this.props.onMouseLeave) {
      this.props.onMouseLeave()
    }
    if (this.props.tooltip) {
      this.setState({ isHovering: false })
    }
  }

  setRef = (c) => {
    const { buttonRef } = this.props
    try {
      this.node = c
      if (isFunction(buttonRef)) {
        buttonRef(c)
      }
    } catch (error) {
      // Handle error if necessary
    }
  }

  focus() {
    this.node.focus()
  }

  render() {
    const {
      backgroundColor,
      children,
      className,
      color,
      href,
      icon,
      iconClassName,
      iconSize,
      isBlock,
      isDisabled,
      isNarrow,
      isOutline,
      isText,
      noClasses,
      onClick,
      onMouseEnter,
      onMouseLeave,
      onTouchStart,
      onTouchEnd,
      radiusSmall,
      rel,
      target,
      title,
      to,
      tooltip,
      type,
      underlineOnHover,
      noAnimations,
    } = this.props
    const { isHovering } = this.state

    // Style the component according to props
    const classes = noClasses ? className : CX(className, {
      d: 1,
      noUnderline: 1,
      font: 1,
      cursorPointer: 1,
      textAlignCenter: 1,
      outlineNone: !isDisabled && !isText,
      outlineBrand_onFocus: !isDisabled && !isText,
      flexRow: !!children && !!icon,
      cursorNotAllowed: isDisabled,
      opacity05: isDisabled,
      animations_button: !noAnimations && !isDisabled && !isText,

      bgPrimary: backgroundColor === COLORS.primary,
      bgWhite: backgroundColor === COLORS.white,
      bgBlack: backgroundColor === COLORS.black,
      bgBrand: backgroundColor === COLORS.brand,
      bgBrandLightOpaque: backgroundColor === COLORS.brandLight,
      bgTransparent: backgroundColor === COLORS.none,
      bgSecondary: backgroundColor === COLORS.tertiary,
      bgSubtle: backgroundColor === COLORS.secondary,
      bgDanger: backgroundColor === COLORS.danger,
      
      cPrimary: color === COLORS.primary,
      cSecondary: color === COLORS.secondary,
      cTertiary: color === COLORS.tertiary,
      cWhite: color === COLORS.white,
      cBlack: color === COLORS.black,
      cBrand: color === COLORS.brand,

      borderColorBrand: color === COLORS.brand && isOutline,
      borderColorWhite: color === COLORS.white && isOutline,
      border1PX: isOutline,

      circle: !isText,
      radiusSmall: radiusSmall,

      py5: isNarrow,
      py10: !isText && !isNarrow,
      px15: !isText,

      w100PC: isBlock,

      underline_onHover: underlineOnHover,

      bgSecondaryDark_onHover: backgroundColor === COLORS.tertiary || backgroundColor === COLORS.secondary && !isDisabled,
      bgBlackOpaque_onHover: backgroundColor === COLORS.black && !isDisabled,
      bgBrandDark_onHover: backgroundColor === COLORS.brand && !isDisabled,
      bgDangerDark_onHover: backgroundColor === COLORS.danger && !isDisabled,
      bgBrand_onHover: (color === COLORS.brand && isOutline && !isDisabled) || (backgroundColor === COLORS.brandLight && !isDisabled),

      cWhite_onHover: (color === COLORS.brand && isOutline && !isDisabled) || (color === COLORS.black && !isDisabled) || (backgroundColor === COLORS.brandLight && !isDisabled),
    })

    const style = isDisabled ? {
      opacity: 0.6,
      cursor: 'not-allowed'
    } : undefined

    const theIcon = !!icon ? (
      <Icon
        id={icon}
        size={iconSize}
        className={iconClassName}
      />
    ) : undefined

    const theTooltip = !!tooltip && isHovering ? (
      <Tooltip
        message={tooltip}
        targetRef={this.node}
      />
    ) : undefined

    const theChildren = !!icon || !!tooltip ? (
      <React.Fragment>
        {theIcon}
        {children}
        {theTooltip}
      </React.Fragment>
    ) : children

    const handlers = {
      onClick: !!onClick ? this.handleClick : undefined,
      onMouseEnter: !!onMouseEnter || !!tooltip ? this.handleOnMouseEnter : undefined,
      onMouseLeave: !!onMouseLeave || !!tooltip ? this.handleOnMouseLeave : undefined,
      onTouchStart: !!onTouchStart ? this.handleOnTouchStart : undefined,
      onTouchEnd: !!onTouchEnd ? this.handleOnTouchEnd : undefined,
    }

    if (to) {
      return (
        <NavLink
          title={title}
          className={classes}
          disabled={isDisabled}
          to={to}
          ref={this.setRef}
          aria-label={title}
          {...handlers}
          style={style}
        >
          {theChildren}
        </NavLink>
      )
    }

    if (href) {
      const isLogout = href === '/auth/sign_out'
      const dataMethod = isLogout ? 'delete' : undefined

      return (
        <a
          rel={rel}
          target={target}
          title={title}
          aria-label={title}
          type={type}
          disabled={isDisabled}
          className={classes}
          href={href}
          ref={this.setRef}
          data-method={dataMethod}
          {...handlers}
          style={style}
        >
          {theChildren}
        </a>
      )
    }

    return (
      <button
        title={title}
        aria-label={title}
        type={type}
        disabled={isDisabled}
        className={classes}
        ref={this.setRef}
        {...handlers}
        style={style}
      >
        {theChildren}
      </button>
    )
  }
}

Button.propTypes = {
  backgroundColor: PropTypes.string,
  buttonRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.node,
  ]),
  children: PropTypes.node,
  className: PropTypes.string,
  color: PropTypes.string,
  href: PropTypes.string,
  icon: PropTypes.string,
  iconClassName: PropTypes.string,
  iconSize: PropTypes.string,
  isBlock: PropTypes.bool,
  isDisabled: PropTypes.bool,
  isNarrow: PropTypes.bool,
  isText: PropTypes.bool,
  noClasses: PropTypes.bool,
  onClick: PropTypes.func,
  onMouseEnter: PropTypes.func,
  onMouseLeave: PropTypes.func,
  onTouchStart: PropTypes.func,
  onTouchEnd: PropTypes.func,
  isOutline: PropTypes.bool,
  radiusSmall: PropTypes.bool,
  rel: PropTypes.string,
  target: PropTypes.string,
  title: PropTypes.string,
  to: PropTypes.string,
  type: PropTypes.string,
  underlineOnHover: PropTypes.bool,
  noAnimations: PropTypes.bool,
}

Button.defaultProps = {
  color: COLORS.white,
  backgroundColor: COLORS.brand,
}

export default Button
