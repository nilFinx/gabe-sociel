import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { connect } from 'react-redux'
import { fetchGroupsByTab } from '../actions/groups'
import GroupCollectionSquareItem from './group_collection_square_item'

class GroupsScrollableCollection extends ImmutablePureComponent {
  componentDidMount() {
    const { isFetched, isLoading } = this.props
    if (!isFetched && !isLoading) this.props.onFetch()
  }

  render() {
    const {
      groupIds,
      groupType,
    } = this.props

    const count = !!groupIds ? groupIds.count() : 0

    if (count === 0) return null

    return (
      <div className={[_s.d, _s.w100PC, _s.py10, _s.bgPrimary, _s.borderBottom1PX, _s.borderTop1PX, _s.borderColorSecondary, _s.px10, _s.flexRow, _s.overflowHidden, _s.overflowXScroll, _s.noScrollbar].join(' ')}>
        {
          groupIds.map((groupId, i) => (
            <GroupCollectionSquareItem
              key={`group-square-item-${groupId}`}
              id={groupId}
            />
          ))
        }
      </div>
    )
  }

}

const mapStateToProps = (state, { groupType }) => ({
  groupIds: state.getIn(['group_lists', groupType, 'items']),
  isLoading: state.getIn(['group_lists', groupType, 'isLoading']),
  isFetched: state.getIn(['group_lists', groupType, 'isFetched']),
})

const mapDispatchToProps = (dispatch, { groupType }) => ({
  onFetch() {
    dispatch(fetchGroupsByTab(groupType))
  },
})

GroupsScrollableCollection.propTypes = {
  groupIds: ImmutablePropTypes.list,
  isLazy: PropTypes.bool, 
  shouldLoad: PropTypes.bool,
  groupType: PropTypes.string,
}

GroupsScrollableCollection.defaultProps = {
  groupType: 'member'
}

export default connect(mapStateToProps, mapDispatchToProps)(GroupsScrollableCollection)