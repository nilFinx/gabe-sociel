import React from 'react'
import PropTypes from 'prop-types'
import Icon from './icon'
import Text from './text'

const titles = {
  loading: 'Loading..' ,
  missing: 'This resource could not be found.',
}

class ColumnIndicator extends React.PureComponent {

  render() {
    const { type, message } = this.props

    const title = type !== 'error' && !message ? titles[type] : message

    return (
      <div className={[_s.d, _s.w100PC, _s.jcCenter, _s.aiCenter, _s.py15, _s.px10].join(' ')}>
        <Icon id={type} size='30px' className={_s.cPrimary} />
        {
          type !== 'loading' &&
          <Text
            align='center'
            size='medium'
            className={_s.mt10}
          >
            {title}
          </Text>
        }
      </div>
    )
  }

}

ColumnIndicator.propTypes = {
  type: PropTypes.oneOf([
    'loading',
    'missing',
    'error',
  ]),
  message: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
}

export default ColumnIndicator