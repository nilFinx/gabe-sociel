import React from 'react'
import PropTypes from 'prop-types'
import { CX } from '../constants'
import Button from './button'
import Icon from './icon'
import Text from './text'

class Input extends React.PureComponent {
  
  state = {
    stateHasError: this.props.hasError,
    stateValue: this.props.value,
    isFocused: false
  }

  componentDidUpdate(prevProps) {
    const { value, hasError } = this.props
    if (prevProps.value !== value) {
      this.setState({ stateValue: value })
    }
    if (prevProps.hasError !== hasError) {
      this.setState({ stateHasError: hasError })
    }
  }

  handleOnChange = (e) => {
    const { value } = e.target
    this.props.onChange && this.props.onChange(value)
    if (this.state.stateHasError) this.setState({ stateHasError: false })
    this.setState({ stateValue: value })
  }

  handleOnFocus = () => {
    this.setState({ isFocused: true })
    this.props.onFocus && this.props.onFocus()
  }

  handleOnBlur = () => {
    this.setState({ isFocused: false })
    this.props.onBlur && this.props.onBlur()
  }

  handleOnClear = () => {
    this.setState({ stateValue: '' })
    this.props.onChange && this.props.onChange('')
    this.props.onClear && this.props.onClear()
  }

  render() {
    const {
      isDisabled,
      placeholder,
      prependIcon,
      value,
      hasClear,
      onKeyPress,
      onKeyUp,
      onClear,
      title,
      small,
      readOnly,
      inputRef,
      id,
      hideLabel,
      maxLength,
      max,
      isRequired,
      hasButtonAppended,
      type,
      className,
    } = this.props
    const { stateHasError, stateValue, isFocused } = this.state

    const inputClasses = CX({
      d: 1,
      text: 1,
      outlineNone: 1,
      lineHeight125: !small,
      lineHeight1: small,
      displayBlock: 1,
      py10: !small,
      py5: small,
      bgTransparent: !readOnly,
      bgSecondary: readOnly,
      bgTertiary: hasButtonAppended, // && not focused
      cPrimary: !readOnly,
      cSecondary: readOnly,
      fs16PX: !small,
      fs13PX: small,
      flexGrow1: 1,
      radiusTiny: 1,
      topRightRadius0: hasButtonAppended,
      bottomRightRadius0: hasButtonAppended,
      px5: !!prependIcon,
      pl15: !prependIcon,
      pr15: !hasClear,
      cursorNotAllowed: isDisabled,
    })

    const containerClasses = CX(className, {
      d: 1,
      flexGrow1: 1,
      bgPrimary: 1,
      border1PX: 1,
      borderColorInput: !stateHasError,
      borderColorError: stateHasError,
      flexRow: 1,
      radiusTiny: 1,
      topRightRadius0: hasButtonAppended,
      bottomRightRadius0: hasButtonAppended,
      aiCenter: 1,
      borderColorInputFocused: isFocused,
      outlineBrand: isFocused,
    })

    const btnClasses = CX({
      displayNone: !value || value.length === 0,
      px10: 1,
      mr5: 1,
    })

    return (
      <React.Fragment>
        {
          !!title && !hideLabel &&
          <div className={[_s.d, _s.mb5, _s.pb5].join(' ')}>
            <Text htmlFor={id} weight='medium' color='primary' tagName='label'>
              {title}
            </Text>
          </div>
        }
        <div className={containerClasses}>
          {
            !!prependIcon &&
            <Icon id={prependIcon} size='16px' className={[_s.cPrimary, _s.ml15, _s.mr5].join(' ')} />
          }

          {
            !!title && hideLabel &&
            <label className={_s.visiblyHidden} htmlFor={id}>{title}</label>
          }
          
          <input
            id={id}
            className={inputClasses}
            type={type}
            placeholder={placeholder}
            ref={inputRef}
            value={value}
            onChange={!isDisabled ? this.handleOnChange : undefined}
            onKeyUp={!isDisabled && !!onKeyUp ? onKeyUp : undefined}
            onFocus={!isDisabled ? this.handleOnFocus : undefined}
            onBlur={!isDisabled ? this.handleOnBlur : undefined}
            onKeyPress={!isDisabled && !!onKeyPress ? onKeyPress : undefined}
            readOnly={readOnly}
            maxLength={maxLength}
            max={max}
            disabled={isDisabled}
            required={isRequired ? true : undefined}
          />

          {
            hasClear &&
            <Button
              className={btnClasses}
              tabIndex='0'
              title='Clear'
              onClick={onClear}
              icon='close'
              iconClassName={_s.inheritFill}
              iconSize='10px'
            />
          }
        </div>
      </React.Fragment>
    )
  }
}

Input.propTypes = {
  placeholder: PropTypes.string,
  prependIcon: PropTypes.string,
  value: PropTypes.string,
  hasClear: PropTypes.bool,
  onChange: PropTypes.func,
  onKeyPress: PropTypes.func,
  onKeyUp: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  onClear: PropTypes.func,
  title: PropTypes.string,
  small: PropTypes.bool,
  readOnly: PropTypes.string,
  inputRef: PropTypes.func,
  id: PropTypes.string.isRequired,
  isRequired: PropTypes.bool,
  hideLabel: PropTypes.bool,
  maxLength: PropTypes.number,
  isDisabled: PropTypes.bool,
  type: PropTypes.string,
  hasButtonAppended: PropTypes.bool,
}

Input.defaultProps = {
  type: 'text',
}

export default Input
