import React from 'react'
import PropTypes from 'prop-types'
import { List as ImmutableList } from 'immutable'
import { connect } from 'react-redux'
import { Map as ImmutableMap } from 'immutable'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { many } from '../utils/arrays'
import MediaAttachmentThumbnail from '../components/media_attachment_thumbnail'
import MediaAttachmentThumbnailPlaceholder from '../components/placeholder/media_attachment_thumbnail_placeholder'
import ScrollableList from './scrollable_list'
import Text from './text'

class MediaAttachmentList extends ImmutablePureComponent {

  load = () => {
    const { id, dispatch, params, onExpand } = this.props
    if (!id || id === -1) return
    dispatch(onExpand(id, params))
  }

  componentDidMount() {
    this.load()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.id && prevProps.id !== this.props.id) {
      this.load()
    }
  }

	render() {
		const {
      id,
      ids,
      type,
      isLoading,
      isFetched,
      hasNext,
      onClick,
      minWidth,
      max,
      noPagination,
    } = this.props

    const showLoading = hasNext && isLoading
    const hasItems = ids && ids.size > 0
    const finalIds = !!max && !isNaN(max) && hasItems ? ids.slice(0, Math.min(ids.size, max)) : ids

    return (
      <ScrollableList
        scrollKey={`${type}-${id}-media-attachments`}
        onLoadMore={noPagination ? undefined : this.load}
        isLoading={isLoading}
        hasMore={!!hasNext}
      >
        {!hasItems && isFetched && 
        <div className={[_s.d, _s.px15, _s.pt15, _s.mt15, _s.w100PC].join(' ')}>
          <Text color='tertiary' align='center'>No media found</Text>
        </div>
        }
        <div
          className={[_s.d, _s.py5, _s.px5, _s.displayGrid].join(' ')}
          style={{
            gridGap: '5px',
            gridTemplateColumns: `repeat(auto-fill, minmax(${minWidth}px, 1fr))`,
          }}
        >
          {hasItems && finalIds.map((mediaAttachmentId) => (
            <MediaAttachmentThumbnail
              key={`media-attachment-thumbnail-placeholder-${mediaAttachmentId}`}
              mediaAttachmentId={mediaAttachmentId}
              onClick={onClick}
            />
          ))}
          
          {showLoading && many(12, (i) => (
            <MediaAttachmentThumbnailPlaceholder key={`media-attachment-thumbnail-placeholder-${i}`} />
          ))}
        </div>
      </ScrollableList>
    )
	}

}

const mapStateToProps = (state, { type, id, params }) => {
  const path = ['media_attachments', type, id]
  const mediaType = params?.mediaType
  if (!!mediaType) path.push(mediaType)
  
  const data = state.getIn(path, ImmutableMap())

	return {
    ids: data.get('items', ImmutableList()),
    isLoading: data.get('isLoading'),
    isFetched: data.get('isFetched'),
    hasNext: !!data.get('next'),
  }
}

MediaAttachmentList.defaultProps = {
  minWidth: 140,
}

MediaAttachmentList.propTypes = {
	id: PropTypes.string,
  max: PropTypes.number,
  minWidth: PropTypes.number,
  type: PropTypes.string,
  onClick: PropTypes.func,
  params: PropTypes.object,
  noPagination: PropTypes.bool,
}

export default connect(mapStateToProps)(MediaAttachmentList)
