import React from 'react'
import PropTypes from 'prop-types'
import Button from './button'
import Heading from './heading'
import Icon from './icon'
import Logo from './logo'
import Text from './text'
import ResponsiveClassesComponent from '../features/ui/util/responsive_classes_component'
import { NavLink } from 'react-router-dom'
import Search from './search'
import { connect } from 'react-redux'
import { BREAKPOINT_EXTRA_SMALL } from '../constants'
import { me } from '../initial_state'

function GlobalFooter({ isXS }) {

  const links = [
    !me && {
      href: '/auth/sign_up',
      text: 'Sign Up',
    },
    !me && {
      href: '/auth/sign_up',
      text: 'Log in',
    },
    {
      to: '/about',
      text: 'About',
    },
    me && {
      href: '/settings/blocks',
      text: 'Blocks',
    },
    {
      to: '/businesses',
      text: 'Businesses',
    },
    me && {
      href: '/messages',
      text: 'Chat',
    },
    {
      to: '/timeline/clips',
      text: 'Clips',
    },
    {
      href: 'https://grow.gab.com',
      text: 'Create Ad',
    },
    {
      href: '/marketplace/business/join',
      text: 'Create Business',
    },
    {
      href: 'https://shop.gab.com',
      text: 'Dissenter Shop',
    },
    {
      to: '/about/dmca',
      text: 'DMCA',
    },
    {
      to: '/explore',
      text: 'Explore',
    },
    {
      href: '/feeds',
      text: 'Feeds',
    },
    {
      href: 'https://gab.ai?f=gs-f',
      text: 'Gab AI',
    },
    me && {
      to: '/deck',
      text: 'Gab Deck',
    },
    {
      href: 'https://news.gab.com',
      text: 'Gab News',
    },
    {
      href: 'https://pro.gab.com?f=gs-f',
      text: 'Gab PRO',
    },
    {
      to: '/groups',
      text: 'Groups',
    },
    {
      href: 'https://help.gab.com',
      text: 'Help',
    },
    {
      to: '/about/investors',
      text: 'Investors',
    },
    {
      href: '/marketplace',
      text: 'Marketplace',
    },
    me && {
      href: '/settings/mutes',
      text: 'Mutes',
    },
    {
      to: '/news',
      text: 'News',
    },
    me && {
      to: '/notifications',
      text: 'Notifications',
    },
    {
      href: 'https://gabstatus.com/',
      text: 'Platform Status',
    },
    {
      to: '/about/privacy',
      text: 'Privacy Policy',
    },
    {
      to: '/timeline/pro',
      text: 'PRO Feed',
    },
    {
      title: 'Gab TV',
      to: '/timeline/videos',
    },
    {
      href: '/search',
      text: 'Search',
    },
    me && {
      href: '/auth/edit',
      text: 'Security',
    },
    me && {
      href: '/suggestions',
      text: 'Suggestions',
    },
    {
      to: '/about/sales',
      text: 'Terms of Sale',
    },
    {
      to: '/about/tos',
      text: 'Terms of Service',
    },
    me && {
      href: '/auth/sign_out',
      text: 'Logout',
      logout: true,
    },
  ].filter(Boolean)

  return (
    <div className={[_s.d, _s.z3, _s.w100PC, _s.bgPrimary].join(' ')}>
      <div className={[_s.d, _s.left0, _s.right0, _s.bottom0, _s.w100PC, _s.bgPrimary, _s.borderTop1PX, _s.aiCenter, _s.borderColorSecondary].join(' ')}>
        <div className={[_s.d, _s.w100PC, _s.aiCenter].join(' ')}>

          <div className={isXS ? [_s.d, _s.w100PC, _s.py15, _s.px15].join(' ') : [_s.d, _s.w1255PX, _s.pt10, _s.aiCenter].join(' ')}>
            <div className={[_s.d, _s.mb5, _s.pt5, _s.pb10, _s.w100PC, _s.borderColorInput, _s.borderBottom1PX].join(' ')}>
              
              <div className={isXS ? [_s.d, _s.w100PC, _s.aiCenter].join(' ') : [_s.d, _s.w100PC, _s.aiCenter, _s.jcCenter, _s.flexRow, _s.flexWrap].join(' ')}>
                <div className={isXS ? [_s.d, _s.aiCenter, _s.jcCenter, _s.w100PC].join(' ') : [_s.d, _s.mrAuto].join(' ')}>
                  <Logo height='21px' width='35px' />
                  <Text weight='medium' className={_s.mt5} align={isXS ? 'center': ''} color='secondary'>Gab is the Home of Free Speech and the Parallel Economy.</Text>
                  <div className={isXS ? [_s.d, _s.w100PC].join(' ') : undefined}>
                    <Search className={[_s.circle, _s.bgSecondary].join(' ')} />
                  </div>
                </div>
                <div className={isXS ? [_s.d, _s.flexColumnReverse, _s.w100PC, _s.aiCenter, _s.jcCenter].join(' ') : [_s.d, _s.h100PC, _s.jcEnd, _s.pb5].join(' ')}>
                  <div className={[_s.d, _s.flexRow, _s.mbAuto, _s.jcEnd].join(' ')}>
                    <NavLink
                      to='/gab'
                      className={[_s.d, _s.font, _s.noUnderline, _s.cursorPointer, _s.underline_onHover, _s.mr5, _s.fs14PX, _s.cTertiary].join(' ')}
                    >
                      @gab
                    </NavLink>
                    <NavLink
                      to='/support'
                      className={[_s.d, _s.font, _s.noUnderline, _s.cursorPointer, _s.underline_onHover, _s.fs14PX, _s.cTertiary].join(' ')}
                    >
                      @support
                    </NavLink>
                  </div>
                  <Button
                    radiusSmall
                    color='white'
                    backgroundColor='brand'
                    href='https://help.gab.com/article/gab-mobile-app'
                    className={isXS ? [_s.mt5, _s.mb15, _s.w100PC].join(' ') : [_s.w158PX, _s.mb2].join(' ')}
                  >
                    <Text align='center' size='medium' weight='medium' color='inherit'>Get the Gab App</Text>
                  </Button>
                </div>
              </div>

            </div>

            <nav aria-label='Footer' role='navigation' className={isXS ? [_s.d, _s.w100PC, _s.pt10, _s.pb5, _s.flexRow, _s.flexWrap, _s.aiCenter, _s.jcCenter].join(' ') : [_s.d, _s.w100PC, _s.py5, _s.flexWrap, _s.flexRow].join(' ')}>
              {
                links.map((linkFooterItem, i) => {
                  return (
                    <div key={`link-footer-item-${i}`} className={[_s.d, _s.flexRow, _s.aiCenter, _s.jcCenter].join(' ')}>
                      <Button
                        isText
                        underlineOnHover
                        color='none'
                        backgroundColor='none'
                        key={`link-footer-item-${i}`}
                        to={linkFooterItem.to}
                        href={linkFooterItem.href}
                        data-method={linkFooterItem.logout ? 'delete' : null}
                        onClick={linkFooterItem.onClick || null}
                        className={[_s.mt5].join(' ')}
                      >
                        <Text size='small' color='tertiary'>
                          {linkFooterItem.text}
                        </Text>
                      </Button>
                      { !linkFooterItem.logout && <Text size='small' color='tertiary' className={[_s.pt2, _s.mr10, _s.ml10].join(' ')}></Text> }
                    </div>
                  )
                })
              }
            </nav>
          </div>
        </div>
        <div className={[_s.d, _s.aiCenter, _s.bgPrimary, _s.minH40PX, _s.w100PC, _s.saveAreaInsetPB, _s.jcSpaceAround].join(' ')}>
          <div className={isXS ? [_s.d, _s.aiCenter, _s.jcCenter, _s.w100PC, _s.px15, _s.py15].join(' ') : [_s.d, _s.w1255PX, _s.pb10, _s.flexRow, _s.aiCenter].join(' ')}>
            <div className={[_s.d, _s.flexRow, _s.aiCenter].join(' ')}>
              <Text size='small' color='tertiary'>
                © 2023
              </Text>
              <Text size='small' color='tertiary'>
                &nbsp;Copyright ·&nbsp;
              </Text>
              <Button
                isText
                color='tertiary'
                backgroundColor='none'
                className={_s.displayInline}
                href='https://gab.com'
              >
                <Text size='small' color='inherit'>Gab AI Inc.</Text>
              </Button>
            </div>
              
            <div className={isXS ? [_s.d, _s.mt15, _s.mb15, _s.aiCenter].join(' ') : [_s.d, _s.aiCenter, _s.mlAuto].join(' ')} >
              <Text size='small' color='tertiary'>
                Made in USA 🇺🇸
              </Text>
            </div>

          </div>
        </div>

      </div>
    </div>
  )
}


const mapStateToProps = (state, { id }) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

export default connect(mapStateToProps)(GlobalFooter)
