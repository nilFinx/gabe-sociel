import React, { useRef, useEffect }  from 'react'
import PropTypes from 'prop-types'
import { decode, isBlurhashValid } from 'blurhash'

// Lookup table for base 83 encoding used in blurhash
const chars83 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#$%*+,-.:;=?@[]^_{}~";

// Decodes a base 83 encoded string to an integer
function decode83(str) {
  let value = 0
  for (let i = 0; i < str.length; i++) {
    const char = str[i]
    const digit = chars83.indexOf(char)
    value = value * 83 + digit
  }
  return value
}

// Extracts average color from a blurhash
export const getAverageColorFromBlurhash = (blurhash) => {
  if (!isBlurhashValid(blurhash)) return null
  const averageColorStr = `${blurhash}`.substring(2, 6)
  const averageColorInt = decode83(averageColorStr)
  
  // Bitwise operations to extract RGB values
  const r = (averageColorInt >> 16) & 255
  const g = (averageColorInt >> 8) & 255
  const b = averageColorInt & 255
  
  return [r, g, b]
}

const Blurhash = ({
  hash,
  className,
}) => {
  const canvasRef = useRef()

  useEffect(() => {
    if (!hash) return

    const { current: canvas } = canvasRef
    canvas.width = canvas.width

    try {
      const ctx = canvas.getContext('2d')
      ctx.putImageData(new ImageData(decode(hash, 32, 32), 32, 32), 0, 0)
    } catch (err) {
      //
    }
  }, [hash])

  return <canvas className={className} ref={canvasRef} width={32} height={32} />
}

Blurhash.propTypes = {
  hash: PropTypes.string,
}

export default Blurhash