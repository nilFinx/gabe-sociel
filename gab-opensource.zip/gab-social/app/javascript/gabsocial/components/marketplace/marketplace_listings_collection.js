import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import debounce from 'lodash/debounce'
import {
  CX,
  BREAKPOINT_EXTRA_SMALL,
} from '../../constants'
import MarketplaceListingCard from '../marketplace/marketplace_listing_card'
import MarketplaceListingCardPlaceholder from '../placeholder/marketplace_listing_card_placeholder'
import Text from '../text'
import ScrollableList from '../scrollable_list'
import MarketplaceListingCollectionHeader from './marketplace_listing_collection_header'

class MarketplaceListingsCollection extends ImmutablePureComponent {

  handleLoadMore = debounce(() => {
    this.props.onLoadMore()
  }, 300, { leading: true })

  render() {
    const {
      isLoading,
      hasMore,
      listingIds,
      title,
      isXS,
      hideHeader,
    } = this.props

    const hasListings = !!listingIds && listingIds.size > 0
    const containerClasses = CX({
      px10: 1,
      marketplaceItemGrid: 1,
      py15: 1,
    })

    const wrapperClasses = CX({
      d: 1,
      w100PC: 1,
      pt15: isXS,
    })

    return (
      <div className={wrapperClasses}>
        {!hideHeader && <MarketplaceListingCollectionHeader title={title} />}
        <ScrollableList
          scrollKey="marketplace_listings_collection"
          role='feed'
          onLoadMore={this.handleLoadMore}
          placeholderComponent={MarketplaceListingCardPlaceholder}
          placeholderCount={6}
          emptyMessage='No listings found'
          hasMore={hasMore}
        >
          {
            !hasListings && !isLoading &&
            <div className={[_s.d, _s.w100PC, _s.px15, _s.py15].join(' ')}>
              <Text>No results found. Please try another search or change filter parameters.</Text>
            </div>
          }
          <div className={containerClasses}>
            {
              hasListings && listingIds.map((listingId) => (
                <MarketplaceListingCard
                  key={`marketplace-listing-card-${listingId}`}
                  id={listingId}
                />
              ))
            }
            {
              isLoading &&
              <>
                {
                  Array.apply(null, {
                    length: 6,
                  }).map((_, i) => (
                    <MarketplaceListingCardPlaceholder
                      key={`marketplace-placeholder-${i}`}
                      isLast={i === 6 - 1}
                    />
                  ))
                }
              </>
            }
          </div>
        </ScrollableList>
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

MarketplaceListingsCollection.propTypes = {
  listingIds: ImmutablePropTypes.list,
  isLoading: PropTypes.bool,
  isError: PropTypes.bool,
  hasMore: PropTypes.bool,
  onLoadMore: PropTypes.func,
  title: PropTypes.string,
}

export default connect(mapStateToProps)(MarketplaceListingsCollection)
