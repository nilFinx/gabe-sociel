import React from 'react'
import PropTypes from 'prop-types'
import isObject from 'lodash/isObject'
// import Draggable from '../draggable'
import { sortableContainer, sortableElement } from 'react-sortable-hoc'
import Button from '../button'
import Image from '../image'
import Dummy from '../dummy'
import Icon from '../icon'

class MarketplaceListingMediaFormItem extends React.PureComponent {

  state = {
    isLoaded: false,
  }

  onLoadImage = () => {
    this.setState({ isLoaded: true })
  }

  onRemoveCard = () => {
    const { index, removeCard } = this.props
    !!removeCard && removeCard(index)
  }

  render() {
    const { file, children, index, moveCard } = this.props
    const { isLoaded } = this.state

    const Wrapper = !!children ? Dummy : Dummy
    const showImage = !!file

    return (
      <Wrapper
        id={index}
        index={index}
        moveCard={moveCard}
        type='MarketplaceListingMediaFormItem'
        className={[_s.d, _s.flexGrow1, _s.maxW120PX, _s.maxH120PX, _s.noUnderline, _s.bgSubtle_onHover, _s.radiusSmall, _s.border1PX, _s.borderColorSecondary, _s.overflowHidden].join(' ')}
      >
        <div className={[_s.d, _s.w100PC, _s.pt100PC].join(' ')}>
          <div className={[_s.d, _s.posAbs, _s.top0, _s.w100PC, _s.right0, _s.bottom0, _s.left0].join(' ')}>
            <div className={[_s.d, _s.w100PC, _s.h100PC, _s.aiCenter, _s.jcCenter, _s.bgTertiary].join(' ')}>
              {showImage && !isLoaded && <Icon id='loading' />}
              {
                showImage &&
                <Image
                  cfWidthPX='120px'
                  height='100%'
                  width='100%'
                  onLoad={this.onLoadImage}
                  src={file.get('preview_url')}
                  className={_s.noSelect}
                />
              }
              {
                showImage && isLoaded &&
                <Button
                  rounded
                  icon='close'
                  iconSize='12px'
                  onClick={this.onRemoveCard}
                  backgroundColor='black'
                  className={[_s.posAbs, _s.px10, _s.top0, _s.right0, _s.mt5, _s.mr5].join(' ')}
                />
              }
              {children}
            </div>
          </div>
        </div>
      </Wrapper>
    )
  }
}

const SortableItem = sortableElement(({ children }) => <>{children}</>)

MarketplaceListingMediaFormItem.propTypes = {
  file: PropTypes.object,
  children: PropTypes.node,
}

export default MarketplaceListingMediaFormItem
