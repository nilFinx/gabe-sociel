import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import { sortableContainer, sortableElement } from 'react-sortable-hoc'
import {
  uploadMarketplaceListingMedia,
  deleteMarketplaceListingMedia,
  setMarketplaceListingMedia,
} from '../../actions/marketplace_listing_editor'
import {
  MAX_MARKETPLACE_IMAGE_UPLOAD,
} from '../../constants'
import Text from '../text'
import Icon from '../icon'
import MarketplaceListingMediaFormItem from './marketplace_listing_media_form_item'
import ProgressBar from '../progress_bar'

const reorderList = (value, startIndex, endIndex) => {
  if (!value || 0 > endIndex || value.size < endIndex) return value
  const srcItem = value.get(startIndex)
  return value.splice(startIndex, 1).splice(endIndex, 0, srcItem)
}

class MarketplaceListingMediaUploadBlock extends ImmutablePureComponent {

  state = {
    hasError: false,
    isDisabled: false,
  }

  onSortEnd = ({ oldIndex, newIndex }) => {
    const { medias } = this.props
    const newMedias = reorderList(medias, oldIndex, newIndex)
    this.props.onSetMedias(newMedias)
  }

  handleOnUpload = (e) => {
    const maxFiles = 8 - this.props.medias.size;
    const selectedFiles = e.target.files;

    if (selectedFiles.length > maxFiles) {
        alert(`You can only upload up to ${maxFiles} more files.`);
        return;
    }

    for (let i = 0; i < selectedFiles.length; i++) {
        this.props.onUpload(selectedFiles[i]);
    }
  }

  handleOnRemove = (index) => {
    const { medias } = this.props
    const media = medias.get(index)
    this.props.onDeleteMedia(media.get('id'))
  }

  render() {
    const { medias, isUploading, isSubmitting, uploadProgress } = this.props
    const { isDisabled, hasError } = this.state
    
    const fileCount = medias.size
    const htmlFor = 'file-input-marketplace-listing'
    const uploadTrigger = (
      <label
        className={[_s.d, _s.posAbs, _s.top0, _s.bottom0, _s.left0, _s.right0, _s.cursorPointer].join(' ')}
        htmlFor={htmlFor}
      >
        <input
          multiple
          id={htmlFor}
          className={_s.displayNone}
          disabled={isDisabled}
          onChange={this.handleOnUpload}
          type="file"
        />
      </label>
    )

    const uploadForm = (
      <div className={[_s.d, _s.minH106PX, _s.mt5, _s.bgPrimary, _s.bgSubtle_onHover, _s.radiusSmall, _s.borderColorInput, _s.border1PX].join(' ')}>
        <div className={[_s.d, _s.h100PC, _s.w100PC, _s.mtAuto, _s.mbAuto].join(' ')}>
          <div className={[_s.d, _s.flexRow, _s.h100PC, _s.w100PC, _s.aiCenter, _s.jcCenter].join(' ')}>
            <div className={[_s.d, _s.h40PX, _s.w40PX, _s.bgSecondary, _s.circle, _s.aiCenter, _s.jcCenter].join(' ')}>
              <Icon id='media' size='16px' className={_s.cPrimary} />
            </div>
            <div className={[_s.d, _s.pl10].join(' ')}>
              <Text size='large' weight='bold' className={_s.pb2}>Add Media</Text>
              <Text color='secondary'>or drag and drop</Text>
            </div>
          </div>
          {uploadTrigger}
        </div>
      </div>
    )

    return (
      <div className={[_s.d, _s.flex1].join(' ')}>
        <div className={_s.text}>
          <Text size='small' color='secondary' weight='bold'>
            {`${fileCount} / ${MAX_MARKETPLACE_IMAGE_UPLOAD}`}
          </Text>
          <Text size='small' color='tertiary'>
            {` · You can add up to ${MAX_MARKETPLACE_IMAGE_UPLOAD} photos.`}
          </Text>
        </div>
        {
          (!isNaN(uploadProgress) && uploadProgress !== 0) &&
          <div className={[_s.d, _s.w100PC, _s.py5].join(' ')}>
            <ProgressBar small progress={uploadProgress} />
          </div>
        }
        <div className={fileCount === 0 ? _s.displayNone : [_s.d, _s.w100PC].join(' ')}>
          <SortableContainer
            lockToContainerEdges
            keyCodes={[]}
            axis="xy"
            onSortEnd={this.onSortEnd}
            helperClass={[_s.z6, _s.bgPrimary, _s.cursorNSResize].join(' ')}
          >
            {medias.map((media, i) => (
              <SortableItem index={i} sortIndex={i}>
                <MarketplaceListingMediaFormItem
                  index={i}
                  file={media}
                  removeCard={this.handleOnRemove}
                />
              </SortableItem>
            ))}
            <div className={[_s.d, _s.radiusSmall, _s.overflowHidden].join(' ')}>
              <MarketplaceListingMediaFormItem>
                <Icon id='media' size='16px' className={_s.cSecondary} />
                <Text color='secondary' className={_s.pt5}>Add Media</Text>
                {uploadTrigger}
              </MarketplaceListingMediaFormItem>
            </div>
          </SortableContainer>
        </div>
        {fileCount === 0 && uploadForm}
      </div>
    )
  }
}

const SortableItem = sortableElement(({ children }) => (
  <div className={[_s.d, _s.w100PC, _s.w100PC, _s.mr2, _s.mb2, _s.radiusSmall, _s.overflowHidden].join(' ')}>
    {children}
  </div>
))

const SortableContainer = sortableContainer(({ children }) => (
  <div className={[_s.d, _s.displayGrid, _s.flexWrap, _s.flexRow, _s.mt5, _s.marketplaceMediaGrid].join(' ')}>
    {children}
  </div>
))

const mapStateToProps = (state) => ({
  medias: state.getIn(['marketplace_listing_editor', 'media_attachments']),
  isUploading: state.getIn(['marketplace_listing_editor', 'is_uploading']),
  isSubmitting: state.getIn(['marketplace_listing_editor', 'isSubmitting']),
  uploadProgress: state.getIn(['marketplace_listing_editor', 'progress'], 0),
})

const mapDispatchToProps = (dispatch) => ({
  onSetMedias(medias) {
    dispatch(setMarketplaceListingMedia(medias))
  },
  onUpload(file) {
    dispatch(uploadMarketplaceListingMedia([file]))
  },
  onDeleteMedia(mediaId) {
    dispatch(deleteMarketplaceListingMedia(mediaId))
  },
})

MarketplaceListingMediaUploadBlock.propTypes = {
  isUploading: PropTypes.bool,
  isDisabled: PropTypes.bool,
  mediaIds: ImmutablePropTypes.list,
  uploadProgress: PropTypes.number,
}

export default connect(mapStateToProps, mapDispatchToProps)(MarketplaceListingMediaUploadBlock)
