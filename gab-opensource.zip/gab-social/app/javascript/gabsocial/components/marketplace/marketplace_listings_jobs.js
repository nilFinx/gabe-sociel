import React from 'react'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { connect } from 'react-redux'
import debounce from 'lodash/debounce'
import {
  CX,
  BREAKPOINT_EXTRA_SMALL,
} from '../../constants'
import ScrollableList from '../scrollable_list'
import ListItemPlaceholder from '../placeholder/list_item_placeholder'
import MarketplaceListingJobListItem from './marketplace_listing_job_list_item'
import MarketplaceListingCollectionHeader from './marketplace_listing_collection_header'

class MarketplaceListingsJobs extends ImmutablePureComponent {

  handleLoadMore = debounce(() => {
    this.props.onLoadMore()
  }, 300, { leading: true })

  render() {
    const {
      isLoading,
      hasMore,
      listingIds,
      isXS,
    } = this.props

    const hasListings = !!listingIds && listingIds.size > 0

    const containerClasses = CX({
      bgPrimary: 1,
      radiusSmall: !isXS,
      overflowHidden: !isXS,
      borderColorSecondary: 1,
      border1PX: 1,
    })

    const wrapperClasses = CX({
      d: 1,
      w100PC: 1,
      maxW860PX: 1,
      mlAuto: !isXS,
      mrAuto: !isXS,
      px15: !isXS,
      pt15: isXS,
    })

    return (
      <div className={wrapperClasses}>
        <MarketplaceListingCollectionHeader title='Jobs' />
        <div className={containerClasses}>
          <ScrollableList
            scrollKey="marketplace_listings_jobs"
            role='feed'
            onLoadMore={this.handleLoadMore}
            placeholderComponent={ListItemPlaceholder}
            placeholderCount={6}
            emptyMessage='No jobs found'
            hasMore={hasMore}
            isLoading={isLoading}
          >
            {
              hasListings && listingIds.map((listingId) => (
                <MarketplaceListingJobListItem
                  key={`marketplace-listing-job-${listingId}`}
                  id={listingId}
                />
              ))
            }
          </ScrollableList>
        </div>
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

export default connect(mapStateToProps)(MarketplaceListingsJobs)
