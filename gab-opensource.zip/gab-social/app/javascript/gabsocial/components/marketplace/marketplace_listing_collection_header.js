import React from 'react'
import ImmutablePureComponent from 'react-immutable-pure-component'
import {
  Map as ImmutableMap,
  List as ImmutableList,
} from 'immutable'
import { connect } from 'react-redux'
import {
  CX,
  BREAKPOINT_EXTRA_SMALL,
  MODAL_MARKETPLACE_LISTING_FILTER,
  MARKETPLACE_LISTING_AVAILABLE_UNIQUE_ATTRIBUTES,
} from '../../constants'
import Text from '../text'
import Icon from '../icon'
import { openModal } from '../../actions/modal'
import {
  changeMarketplaceListingSearchAttr,
  fetchMarketplaceListingsBySearch,
} from '../../actions/marketplace_listing_search'
import { withRouter } from 'react-router-dom'

class MarketplaceListingCollectionHeader extends ImmutablePureComponent {

  state = {
    removedKeys: [],
  }

  handleOnOpenFilterModal = () => {
    const { isXS } = this.props
    this.props.onOpenFilters(isXS)
  }

  handleOnRemoveFilterKey = (theKey) => {
    this.props.onChangeMarketplaceListingSearchAttr(theKey)
    this.props.onFetchMarketplaceListingsBySearch(this.props.history)
  }

  render() {
    const { title, currentItemsFilters, filters, isXS } = this.props

    // basically checking to see which filters are different than the current results on screen filters
    const flattenedFilters = !!currentItemsFilters ? currentItemsFilters.flatMap((value, key) => {
      if (key === 'attrs' && ImmutableMap.isMap(value)) {
        return value
      }
      return ImmutableMap({ [key]: value })
    }) : null
    
    const flattenedCurrentItemsFilters = !!currentItemsFilters ? currentItemsFilters.flatMap((value, key) => {
      if (key === 'attrs' && ImmutableMap.isMap(value)) {
        return value;
      }
      return ImmutableMap({ [key]: value });
    }) : ImmutableMap()
    
    const countNonEmptyValues = !!filters ? filters.flatMap((value, key) => {
      if (key === 'attrs' && ImmutableMap.isMap(value)) {
        return value;
      }
      return ImmutableMap({ [key]: value });
    }).filter((value, key) => {
      if (key === 'category_id' || key === 'category_slug' || key === 'page') return false;
      const otherValue = flattenedCurrentItemsFilters.get(key)
      return otherValue !== value && 
             value !== undefined && 
             value !== null && 
             value !== '' && 
             !(ImmutableList.isList(value) && value.isEmpty())
    }).size : 0

    const hasOtherFilters = !!flattenedFilters ? flattenedFilters.keySeq()
      .filter(key => key !== 'category_id' && key !== 'category_slug' && key !== 'page')
      .some(key => {
        const value = flattenedFilters.get(key);
        return value !== undefined && value !== null && value !== '' && !ImmutableList.isList(value) && value.size !== 0;
    }) : false;
  
    const headerClasses = CX({
      d: 1,
      flexRow: 1,
      flexWrap: 1,
      aiCenter: 1,
      jcSpaceBetween: 1,
      w100PC: 1,
    })

    const btnSize = isXS ? 'normal' : 'medium'
    const iconSize = isXS ? '12px' : '14px'

    return (
      <div className={[_s.d, _s.w100PC, _s.pl10, _s.pr5, _s.pb5, _s.borderBottom1PX, _s.borderColorSecondary].join(' ')}>
        <div className={headerClasses}>
          <Text size={isXS ? 'extraLarge' : 'extraExtraLarge'} weight='bold' className={[_s.maxW100PC, _s.wrap, _s.pb15].join(' ')}>{title}</Text>
          <div className={[_s.d, _s.flexRow, _s.pb15].join(' ')}>
            <button
              onClick={this.handleOnOpenFilterModal}
              className={[_s.d, _s.outlineBrand_onFocus, _s.outlineNone, _s.flexRow, _s.aiCenter, _s.jcCenter, _s.mr10, _s.bgSecondaryDark_onHover, _s.radiusSmall, _s.px10, _s.py5, _s.bgSecondary, _s.cursorPointer, _s.radiusSmall, _s.cursorPointer].join(' ')}
            >
              {
                countNonEmptyValues > 0 &&
                <div className={[_s.h20PX, _s.d, _s.px10, _s.mr10, _s.aiCenter, _s.jcCenter, _s.radiusTiny, _s.bgBrand].join(' ')}>
                  <span className={[_s.d, _s.text, _s.fs14PX, _s.cWhite].join(' ')}>{countNonEmptyValues}</span>
                </div>
              }
              <Icon id='ul-list' className={_s.cPrimary} size={iconSize} />
              <Text weight='medium' color='primary' size={btnSize} className={[_s.ml5, _s.py2].join(' ')}>Filter · Sort</Text>
            </button>
          </div>
        </div>
        {
          hasOtherFilters && 
          <div className={[_s.d, _s.pt5, _s.pb10, _s.flexRow, _s.flexWrap, _s.w100PC].join(' ')}>
            {flattenedFilters.entrySeq().map(([key, value]) => {
              if (key !== 'category_id' && key !== 'category_slug' && key !== 'page' && value && value !== '') {
                let theKey = MARKETPLACE_LISTING_AVAILABLE_UNIQUE_ATTRIBUTES.indexOf(key) > -1 ? ['attrs', key] : key
                let isPrice = key.indexOf('price') > - 1
                return (
                  <button
                    key={`ml-f-${key}`}
                    onClick={() => this.handleOnRemoveFilterKey(theKey)}
                    className={[_s.d, _s.px10, _s.flexRow, _s.mr10, _s.mb10, _s.py5, _s.radiusTiny, _s.bgSecondary, _s.cursorPointer, _s.outlineNone].join(' ')}
                  >
                    <Text size='small'>{key}:&nbsp;</Text>
                    <Text size='small' weight='extraBold'>
                      {isPrice ? '$' : ''}
                      {`${value}`}
                    </Text>
                    <div className={[_s.d, _s.circle, _s.ml5, _s.px2, _s.py2, _s.aiCenter, _s.jcCenter].join(' ')}>
                      <Icon id='close' className={_s.cSecondary} size='10px' />
                    </div>
                  </button>
                )
              }
              return null
            })}
          </div>
        }
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  filters: state.getIn(['marketplace_listing_search', 'filters']),
  currentItemsFilters: state.getIn(['marketplace_listing_search', 'current_items_filters']),
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

const mapDispatchToProps = (dispatch) => ({
  onChangeMarketplaceListingSearchAttr(key) {
    dispatch(changeMarketplaceListingSearchAttr(key, undefined))
  },
  onFetchMarketplaceListingsBySearch(history) {
    dispatch(fetchMarketplaceListingsBySearch(history))
  },
  onOpenFilters(isXS) {
    dispatch(openModal(MODAL_MARKETPLACE_LISTING_FILTER, { isXS }))
  },
})

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(MarketplaceListingCollectionHeader))
