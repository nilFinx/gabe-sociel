import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import {
  Map as ImmutableMap,
} from 'immutable'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { CX } from '../../constants'
import { fetchMarketplaceListingById } from '../../actions/marketplace_listings'
import Text from '../text'
import Image from '../image'
import Icon from '../icon'
import Button from '../button'

class MarketplaceListingCard extends ImmutablePureComponent {

  state = {
    isHovering: false,
    mediaIndex: 0,
  }

  componentDidMount() {
    const { item, onFetchMarketplaceListingById, id } = this.props

    if (!item) onFetchMarketplaceListingById(id)
  }

  componentDidUpdate(prevProps) {
    // const { item, onFetchMarketplaceListingById, id } = this.props
    //
  }

  handleNextClick = () => {
    const { item } = this.props
    const { mediaIndex } = this.state
    const medias = item.get('media_attachments')
    const mediaIdsSize = !!medias ? medias.size : 0
    this.setState({ mediaIndex: (mediaIndex + 1) % mediaIdsSize })
  }

  handlePrevClick = () => {
    const { item } = this.props
    const { mediaIndex } = this.state
    const medias = item.get('media_attachments')
    const mediaIdsSize = !!medias ? medias.size : 0
    this.setState({ mediaIndex: (mediaIdsSize + mediaIndex - 1) % mediaIdsSize })
  }


  handleOnMouseEnter = () => {
    this.setState({ isHovering: true })
  }

  handleOnMouseLeave = () => {
    this.setState({ isHovering: false })
  }

  handleOnClick = (e) => {
    const { item, history } = this.props
    const url = `/marketplace/item/${item.get('id')}`
    // let the swipable views work if clicking arrows
    // otherwise, if clicked on image, go to the listing url
    const isNavigator = !![e.target, e.target.parentNode].find((e) => {
      return ['Previous', 'Next'].indexOf(e.getAttribute('aria-label')) > -1
    })
    if (!isNavigator) history.push(url)
  }

  render() {
    const { item } = this.props
    const { isHovering, mediaIndex } = this.state

    if (!item) return null

    const medias = item.get('media_attachments')
    const mediaIdsSize = !!medias ? medias.size : 0
    const hasNone = mediaIdsSize === 0
    const hasOne = mediaIdsSize === 1
    const hasMany = mediaIdsSize > 1
    const firstImg = !!medias && medias.first()
    
    const locationStr = item.get('location')
    const hasLocationObject = !!item.get('location_object') && ImmutableMap.isMap(item.get('location_object'))
		const locationDisplayName = hasLocationObject ? item.getIn(['location_object', 'name']) || item.getIn(['location_object', 'display_name']) : null  
  
    const priceClasses = CX({
      pb2: 1,
      underline: isHovering,
    })

    const paginationContainerClasses = CX({
      d: 1,
      displayNone: !isHovering,
      posAbs: 1,
      aiCenter: 1,
      z2: 1,
      top0: 1,
      w100PC: 1,
      right0: 1,
      bottom0: 1,
      left0: 1,
    })

    return (
      <button
        className={[_s.d, _s.outlineNone, _s.bgTransparent, _s.cursorPointer, _s.flexGrow1, _s.noUnderline, _s.radiusSmall, _s.overflowHidden].join(' ')}
        onClick={this.handleOnClick}
      >
        <div
          className={[_s.d].join(' ')}
          onMouseEnter={this.handleOnMouseEnter}
          onMouseLeave={this.handleOnMouseLeave}
        >
          <div className={[_s.d, _s.w100PC, _s.mb10].join(' ')}>
            <div className={[_s.d, _s.w100PC, _s.pt100PC].join(' ')}>
              <div className={[_s.d, _s.posAbs,_s.top0, _s.w100PC, _s.right0, _s.bottom0, _s.left0].join(' ')}>
                <div className={[_s.d, _s.w100PC, _s.radiusSmall, _s.overflowHidden, _s.h100PC, _s.aiCenter, _s.jcCenter, _s.bgTertiary, _s.bgPrimary, _s.borderBottom1PX, _s.borderColorSecondary].join(' ')}>
                  { (hasOne && firstImg) && <Image cfWidthPX='400px' height='100%' width='100%' src={firstImg.get('url')} /> }
                  { hasNone && <Icon id='media' className={_s.cSecondary} size='60px' /> }
                  {
                    hasMany && !!medias && !!medias.get(mediaIndex) &&
                    <div className={[_s.d, _s.w100PC, _s.h100PC].join(' ')}>
                      <Image cfWidthPX='400px' height='100%' width='100%' src={medias.get(mediaIndex).get('url', '')} />
                      <div className={paginationContainerClasses}>
                        <Button
                          rounded
                          tabIndex='0'
                          backgroundColor='black'
                          className={[
                            _s.py10,
                            _s.px10,
                            _s.posAbs,
                            _s.top50PC,
                            _s.left0,
                            _s.mtNeg19PX,
                            _s.ml5,
                            _s.z4,
                            _s.bgBlackOpaquest,
                            _s.bgBlackOpaque_onHover,
                          ].join(' ')}
                          onClick={this.handlePrevClick}
                          title='Previous'
                          icon='arrow-left'
                          iconSize='18px'
                        />
                        <Button
                          rounded
                          tabIndex='0'
                          backgroundColor='black'
                          className={[
                            _s.py10,
                            _s.px10,
                            _s.posAbs,
                            _s.top50PC,
                            _s.right0,
                            _s.mtNeg19PX,
                            _s.mr5,
                            _s.z4,
                            _s.bgBlackOpaquest,
                            _s.bgBlackOpaque_onHover,
                          ].join(' ')}
                          onClick={this.handleNextClick}
                          title='Next'
                          icon='arrow-right'
                          iconSize='18px'
                        />
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
          </div>

          <div className={[_s.d, _s.pr10, _s.pb10].join(' ')}>
            <Text weight='bold' size='large' className={priceClasses}>{item.get('price_label')}</Text>
            <Text>{item.get('title')}</Text>
            { !!locationStr && !hasLocationObject && <Text color='tertiary' size='small' className={_s.pt5}>{locationStr}</Text> }
            { hasLocationObject && !!locationDisplayName && <Text color='tertiary' size='small' className={_s.pt5}>{locationDisplayName}</Text> }
          </div>
        </div>
      </button>
    )
  }
}

const mapStateToProps = (state, { id }) => ({
  item: state.getIn(['marketplace_listings', `${id}`]),
})

const mapDispatchToProps = (dispatch) => ({
  onFetchMarketplaceListingById(id) {
    dispatch(fetchMarketplaceListingById(id))
  },
})

MarketplaceListingCard.propTypes = {
  id: PropTypes.string,
  item: ImmutablePropTypes.map,
  onFetchMarketplaceListingById: PropTypes.func,
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(MarketplaceListingCard))
