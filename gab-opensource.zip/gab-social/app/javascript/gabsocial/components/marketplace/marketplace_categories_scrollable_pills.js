import React from 'react'
import { connect } from 'react-redux'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { fetchMarketplaceListingCategories } from '../../actions/marketplace_listing_categories'
import Image from '../image'
import Pills from '../pills'

class MarketplaceCategoriesScrollablePills extends ImmutablePureComponent {
  
  state = {
    fetched: false,
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.shouldLoad && !prevState.fetched) {
      return { fetched: true }
    }

    return null
  }

  componentDidUpdate(prevProps, prevState) {
    if (!prevState.fetched && this.state.fetched && this.props.isLazy) {
      this.props.dispatch(fetchMarketplaceListingCategories())
    }
  }

  componentDidMount() {
    if (!this.props.isLazy) {
      this.props.dispatch(fetchMarketplaceListingCategories())
      this.setState({ fetched: true })
    }
  }

  render() {
    const { categories, theme } = this.props
  
    if (!categories) return null

    const iconBrightness = ['black', 'muted', 'night'].indexOf(theme) > -1 ? '10' : '0'

    const pills = categories.sortBy(Math.random).toJS().map((c) => ({
      to: `/marketplace/listings/${c.slug}`,
      title: (
        <div className={[_s.d, _s.fs13PX, _s.flexRow, _s.aiCenter].join(' ')}>
          <div className={[_s.d, _s.w20PX, _s.h20PX, _s.aiCenter, _s.jcCenter, _s.mr5].join(' ')}>
            <div style={{ filter: `brightness(${iconBrightness})` }}>
              <Image cfWidthPX='14px' height='20px' width='20px' src={c.cover_image_url} />
            </div>
          </div>
          {c.name}
        </div>
      ),
    }))

    pills.unshift({
      title: 'All Categories',
      to: '/marketplace/categories',
    })

    return <Pills pills={pills} />
  }
}

const mapStateToProps = (state) => ({
  theme: state.getIn(['settings', 'displayOptions', 'theme']),
  isLoading: state.getIn(['marketplace_listing_categories', 'isLoading']),
  categories: state.getIn(['marketplace_listing_categories', 'items']),
})

MarketplaceCategoriesScrollablePills.propTypes = {
  categories: ImmutablePropTypes.list.isRequired,
}

export default connect(mapStateToProps)(MarketplaceCategoriesScrollablePills)
