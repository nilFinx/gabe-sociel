import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import moment from 'moment-mini'
import { connect } from 'react-redux'
import { NavLink } from 'react-router-dom'
import { fetchMarketplaceListingById } from '../../actions/marketplace_listings'
import Text from '../text'
import Image from '../image'
import Icon from '../icon'

class MarketplaceListingJobListItem extends ImmutablePureComponent {

  render() {
    const { item } = this.props

    if (!item) return null

    const firstImg = item.get('media_attachments').first()

    const attrs = item.get('attrs')
    const isRemote = !!attrs?.find(a => a.get('key') === 'is_remote')?.get('value') === 'Yes'
    const payStructure = attrs?.find(a => a.get('key') === 'pay_structure')?.get('value')
    const positionType = attrs?.find(a => a.get('key') === 'position_type')?.get('value')
    const sector = attrs?.find(a => a.get('key') === 'sector')?.get('value')

    return (
      <NavLink
        className={[_s.d, _s.w100PC, _s.px15, _s.py15, _s.flexRow, _s.borderColorSecondary, _s.borderBottom1PX, _s.noUnderline, _s.bgSubtle_onHover].join(' ')}
        to={`/marketplace/item/${item.get('id')}`}
      >

        <div className={[_s.d, _s.h40PX, _s.mt7, _s.w40PX, _s.border1PX, _s.radiusSmall, _s.overflowHidden, _s.borderColorSecondary, _s.mr15].join(' ')}>
          { firstImg ?
            <Image
              cfWidthPX='40px'
              height='40px'
              width='40px'
              src={firstImg.get('url')}
            />
            :
            <div className={[_s.bgTertiary, _s.d, _s.aiCenter, _s.jcCenter].join(' ')} style={{ height: '40px', width: '40px'}}>
              <Icon id='media' className={_s.cSecondary} size='14px' />
            </div>
          }
        </div>

        <div className={[_s.d, _s.flex1].join(' ')}>
          <div className={[_s.d].join(' ')}>
            <Text color='secondary' className={_s.pb7}>
              {item.get('location')}
              { isRemote && <>&nbsp;&nbsp;·&nbsp;&nbsp;Remote</> }
            </Text>
            <Text weight='medium' size='large' className={[_s.underline_onHover, _s.pb5].join(' ')}>{item.get('title')}</Text>
            <div className={[_s.d, _s.displayBlock].join(' ')}>
              <Text size='small' color='secondary' className={[_s.pb2, _s.pt2, _s.lineHeight15].join(' ')}>
                {item.get('price_label')}
                { !!payStructure && <>&nbsp;{payStructure}</> }
                { !!positionType && <>&nbsp;&nbsp;·&nbsp;&nbsp;{positionType}</> }
                { !!sector && <>&nbsp;&nbsp;·&nbsp;&nbsp;{sector}</> }
                &nbsp;&nbsp;·&nbsp;&nbsp;
                Posted {moment(item.get('created_at')).format('ll')}
              </Text>
            </div>
          </div>
        </div>
      </NavLink>
    )
  }
}

const mapStateToProps = (state, { id }) => ({
  item: state.getIn(['marketplace_listings', `${id}`], null),
})

MarketplaceListingJobListItem.propTypes = {
  id: PropTypes.string,
  item: ImmutablePropTypes.map,
  onFetchMarketplaceListingById: PropTypes.func,
}

export default connect(mapStateToProps)(MarketplaceListingJobListItem)
