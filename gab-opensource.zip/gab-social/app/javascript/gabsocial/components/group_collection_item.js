import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { NavLink } from 'react-router-dom'
import { PLACEHOLDER_MISSING_HEADER_SRC, CX } from '../constants'
import { shortNumberFormat } from '../utils/numbers'
import Image from './image'
import Icon from './icon'
import Text from './text'
import GroupActionButton from './group_action_button'

class GroupCollectionItem extends ImmutablePureComponent {

  render() {
    const { group, relationships, isAddable, isFull } = this.props

    const isMember = !!relationships ? relationships.get('member') : false
    const isAdmin = !!relationships ? relationships.get('admin') : false
    const isModerator = !!relationships ? relationships.get('moderator') : false

    const coverSrc = group.get('cover_image_thumbnail_url') || group.get('cover_image_medium_url') || group.get('cover_image_url') || ''
    const coverMissing = coverSrc.indexOf(PLACEHOLDER_MISSING_HEADER_SRC) > -1 || !coverSrc

    const navLinkClasses = CX({
      d: 1,
      noUnderline: 1,
      overflowHidden: 1,
      borderColorSecondary: 1,
      boxShadowBlock: 1,
      radiusSmall: 1,
      borderTop1PX: 1,
      mb10: 1,
      ml5: 1,
      mr5: 1,
      bgPrimary: 1,
      h290PX: !isFull,
      hAuto: isFull,
      bgSubtle_onHover: isMember,
    })

    const wClass = isFull ? _s.w100PC : _s.w300PX

    let groupTitle = group.get('title') || ''
    if (isAddable && groupTitle.length > 52) groupTitle = `${groupTitle.substring(0, 52).trim()}...`

    return (
      <div className={[_s.d, wClass].join(' ')}>
        <NavLink
          to={`/groups/${group.get('id')}`}
          className={navLinkClasses}
        >
          <Image
            isLazy
            cfWidthPX='300px'
            src={!coverMissing ? coverSrc : undefined}
            alt={group.get('title')}
            className={_s.h158PX}
          />

          {
            (isMember || isAdmin || isModerator) &&
            <div className={[_s.d, _s.flexRow, _s.posAbs, _s.top0, _s.right0, _s.pt10, _s.mr10].join(' ')}>
              {
                isMember &&
                <Text
                  isBadge
                  className={_s.bgWhite}
                  size='extraSmall'
                  color='brand'
                >
                  Member
                </Text>
              }
              {
                isAdmin &&
                <Text
                  isBadge
                  className={[_s.bgBlack, _s.ml5].join(' ')}
                  size='extraSmall'
                  color='white'
                >
                  Admin
                </Text>
              }
              {
                isModerator &&
                <Text
                  isBadge
                  className={[_s.bgBlack, _s.ml5].join(' ')}
                  size='extraSmall'
                  color='white'
                >
                  Moderator
                </Text>
              }
            </div>
          }

          <div className={[_s.d, _s.px10, _s.my10].join(' ')}>
            <div className={[_s.d, _s.flexRow, _s.aiCenter].join(' ')}>
              <Text color='primary' size='medium' weight='bold'>
                {groupTitle}
              </Text>
              {
                group.get('is_verified') &&
                <Icon id='verified-group' size='14px' className={_s.ml5} />
              }
            </div>

            <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.mt5, _s.mb5].join(' ')}>
              <Text color='secondary' size='small'>
                {shortNumberFormat(group.get('member_count'))}
                &nbsp;
                Members
              </Text>
            </div>

            {
              isAddable &&
              <div className={[_s.d, _s.pt10].join(' ')}>
                <GroupActionButton group={group} relationships={relationships} />
              </div>
            }
          </div>

        </NavLink>
      </div>
    )
  }

}

const mapStateToProps = (state, { id }) => ({
  group: state.getIn(['groups', id]),
  relationships: state.getIn(['group_relationships', id]),
})

GroupCollectionItem.propTypes = {
  group: ImmutablePropTypes.map,
  relationships: ImmutablePropTypes.map,
  isAddable: PropTypes.bool,
}

export default connect(mapStateToProps)(GroupCollectionItem)
