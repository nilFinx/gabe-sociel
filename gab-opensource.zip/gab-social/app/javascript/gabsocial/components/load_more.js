import React from 'react'
import PropTypes from 'prop-types'
import Button from './button'
import Text from './text'

class LoadMore extends React.PureComponent {

  handleClick = (e) => {
    if (!!this.props.onClick) this.props.onClick(e)
  }

  render() {
    const { disabled, visible } = this.props

    if (!visible || disabled) return null

    return (
      <div className={[_s.d, _s.py15, _s.px10].join(' ')}>
        <Button
          isBlock
          radiusSmall
          backgroundColor='tertiary'
          color='primary'
          disabled={disabled || !visible}
          style={{
            visibility: visible ? 'visible' : 'hidden',
          }}
          onClick={this.handleClick}
        >
          <Text color='inherit' align='center' weight='medium' className={_s.py5}>
            Load more
          </Text>
        </Button>
      </div>
    )
  }

}

LoadMore.propTypes = {
  onClick: PropTypes.func,
  disabled: PropTypes.bool,
  visible: PropTypes.bool,
}

LoadMore.defaultProps = {
  visible: true,
}

export default LoadMore