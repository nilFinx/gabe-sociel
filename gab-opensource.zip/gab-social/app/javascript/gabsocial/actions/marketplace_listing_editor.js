import api from '../api'
import resizeImage from '../utils/resize_image'
import { me } from '../initial_state'

export const MARKETPLACE_LISTING_CREATE_REQUEST = 'MARKETPLACE_LISTING_CREATE_REQUEST'
export const MARKETPLACE_LISTING_CREATE_SUCCESS = 'MARKETPLACE_LISTING_CREATE_SUCCESS'
export const MARKETPLACE_LISTING_CREATE_FAIL = 'MARKETPLACE_LISTING_CREATE_FAIL'

export const MARKETPLACE_LISTING_UPDATE_REQUEST = 'MARKETPLACE_LISTING_UPDATE_REQUEST'
export const MARKETPLACE_LISTING_UPDATE_SUCCESS = 'MARKETPLACE_LISTING_UPDATE_SUCCESS'
export const MARKETPLACE_LISTING_UPDATE_FAIL = 'MARKETPLACE_LISTING_UPDATE_FAIL'

export const MARKETPLACE_LISTING_UPLOAD_REQUEST  = 'MARKETPLACE_LISTING_UPLOAD_REQUEST'
export const MARKETPLACE_LISTING_UPLOAD_PROGRESS = 'MARKETPLACE_LISTING_UPLOAD_PROGRESS'
export const MARKETPLACE_LISTING_UPLOAD_SUCCESS  = 'MARKETPLACE_LISTING_UPLOAD_SUCCESS'
export const MARKETPLACE_LISTING_UPLOAD_FAIL 		 = 'MARKETPLACE_LISTING_UPLOAD_FAIL'
export const MARKETPLACE_LISTING_UPLOAD_UNDO     = 'MARKETPLACE_LISTING_UPLOAD_UNDO'
export const MARKETPLACE_LISTING_UPLOAD_SET      = 'MARKETPLACE_LISTING_UPLOAD_SET'

export const MARKETPLACE_LISTING_EDITOR_ATTR_CHANGE = 'MARKETPLACE_LISTING_EDITOR_ATTR_CHANGE'

export const MARKETPLACE_LISTING_EDITOR_RESET = 'MARKETPLACE_LISTING_EDITOR_RESET'
export const MARKETPLACE_LISTING_EDITOR_SETUP = 'MARKETPLACE_LISTING_EDITOR_SETUP'

export const submit = (router, id) => (dispatch, getState) => {
	if (!me) return

	const attrs = getState().getIn(['marketplace_listing_editor', 'attrs']).toJS()
	const media = getState().getIn(['marketplace_listing_editor', 'media_attachments'])
	const mediaIds = media.map(item => item.get('id'))
	
	const options = {
		...attrs,
		media_ids: mediaIds,
	}

	if (!id) {
		dispatch(createMarketplaceListing(options, router))
	} else {
		dispatch(updateMarketplaceListing(id, options, router))
	}
}

/**
 * 
 */
const createMarketplaceListing = (options, router) => (dispatch, getState) => {
	if (!me) return

	// if business and no CTA title + link, return error
	// console.log("options", options)

	dispatch(createMarketplaceListingRequest())

	api(getState).post('/api/v1/marketplace_listings', options).then(({ data }) => {
		dispatch(createMarketplaceListingSuccess(data))
		resetEditor()
		if (router) router.push(`/marketplace/item/${data.id}`)
	}).catch((err) => {
		dispatch(createMarketplaceListingFail(err))
	})
}

const createMarketplaceListingRequest = (id) => ({
	type: MARKETPLACE_LISTING_CREATE_REQUEST,
	id,
})

const createMarketplaceListingSuccess = (item) => ({
	type: MARKETPLACE_LISTING_CREATE_SUCCESS,
	showToast: true,
	item,
})

const createMarketplaceListingFail = (error) => ({
	type: MARKETPLACE_LISTING_CREATE_FAIL,
	showToast: true,
	error,
})

/**
 * 
 */
const updateMarketplaceListing = (id, options, router) => (dispatch, getState) => {
	if (!me) return

	dispatch(updateMarketplaceListingRequest())

	api(getState).put(`/api/v1/marketplace_listings/${id}`, options).then(({ data }) => {
		dispatch(updateMarketplaceListingSuccess(data))
		router.push(`/marketplace/item/${id}`)
	}).catch((err) => dispatch(updateMarketplaceListingFail(err)))
}

const updateMarketplaceListingRequest = () => ({
	type: MARKETPLACE_LISTING_UPDATE_REQUEST,
})

const updateMarketplaceListingSuccess = (data) => ({
	type: MARKETPLACE_LISTING_UPDATE_SUCCESS,
	showToast: true,
	data,
})

const updateMarketplaceListingFail = (error) => ({
	type: MARKETPLACE_LISTING_UPDATE_FAIL,
	showToast: true,
	error,
})

/**
 * 
 */
export const uploadMarketplaceListingMedia = (files) => (dispatch, getState) => {
  if (!me) return

  const uploadLimit = 8
  const media  = getState().getIn(['marketplace_listing_editor', 'media_attachments'])
  const pending  = getState().getIn(['marketplace_listing_editor', 'pending_media_attachments'])
  const progress = new Array(files.length).fill(0)
  let total = Array.from(files).reduce((a, v) => a + v.size, 0)

  if (files.length + media.size + pending > uploadLimit) {
    // dispatch(showAlert(undefined, messages.uploadErrorLimit))
    return
  }

  dispatch(uploadMarketplaceListingMediaRequest())

	try {
		for (const [i, f] of Array.from(files).entries()) {
			if (media.size + i > uploadLimit) break
	
			resizeImage(f).then((file) => {
				const data = new FormData()
				data.append('file', file)
				// Account for disparity in size of original image and resized data
				total += file.size - f.size
	
				return api(getState).post('/api/v1/marketplace_media', data, {
					onUploadProgress: ({ loaded }) => {
						progress[i] = loaded
						dispatch(uploadMarketplaceListingMediaProgress(progress.reduce((a, v) => a + v, 0), total))
					},
				}).then(({ data }) => dispatch(uploadMarketplaceListingMediaSuccess(data)))
			}).catch((error) => {
				dispatch(uploadMarketplaceListingMediaFail(error, true))
			})
		}	
	} catch (err) {
		// console.log("err:", err)
	}
}

const uploadMarketplaceListingMediaRequest = () => ({
  type: MARKETPLACE_LISTING_UPLOAD_REQUEST,
})

const uploadMarketplaceListingMediaProgress = (loaded, total) => ({
  type: MARKETPLACE_LISTING_UPLOAD_PROGRESS,
  loaded: loaded,
  total: total,
})

const uploadMarketplaceListingMediaSuccess = (media) => ({
  type: MARKETPLACE_LISTING_UPLOAD_SUCCESS,
  media: media,
})

const uploadMarketplaceListingMediaFail = (error) => ({
  type: MARKETPLACE_LISTING_UPLOAD_FAIL,
  showToast: true,
  error,
})

export const setMarketplaceListingMedia = (medias) => ({
  type: MARKETPLACE_LISTING_UPLOAD_SET,
  medias,
})

/**
 * delete from editor, wait until user clicks "SAVE" to actually delete!
 */
 export const deleteMarketplaceListingMedia = (media_id) => ({
  type: MARKETPLACE_LISTING_UPLOAD_UNDO,
  media_id,
})

/**
 * 
 */
export const resetEditor = () => ({
	type: MARKETPLACE_LISTING_EDITOR_RESET
})

export const setMarketplaceListing = (item) => ({
	type: MARKETPLACE_LISTING_EDITOR_SETUP,
	item,
})

export const changeMarketplaceListingAttr = (key, value) => ({
	type: MARKETPLACE_LISTING_EDITOR_ATTR_CHANGE,
	listing_key: key,
	listing_value: value,
})
