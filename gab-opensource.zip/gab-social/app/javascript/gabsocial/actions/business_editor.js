import api from '../api'
import { me } from '../initial_state'

export const BUSINESS_EDITOR_ATTR_CHANGE  = 'BUSINESS_EDITOR_ATTR_CHANGE'
export const BUSINESS_EDITOR_RESET        = 'BUSINESS_EDITOR_RESET'
export const BUSINESS_EDITOR_SETUP        = 'BUSINESS_EDITOR_SETUP'

export const setBusiness = (business) => ({
	type: BUSINESS_EDITOR_SETUP,
	business,
})

/**
 *
 */
export const changeBusinessEditorAttr = (attr, value) => ({
  type: BUSINESS_EDITOR_ATTR_CHANGE,
  business_key: attr,
  business_value: value,
})

/**
 * 
 * @returns 
 */
export const resetBusinessEditor = () => ({
  type: BUSINESS_EDITOR_RESET,
})
