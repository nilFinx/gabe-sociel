import isObject from 'lodash/isObject'
import api, { getLinks } from '../api'
import {
  importFetchedStatuses,
  importMediaAttachments,
  importFetchedMarketplaceListings,
} from './importer'

export const MEDIA_ATTACHMENTS_EXPAND_REQUEST = 'MEDIA_ATTACHMENTS_EXPAND_REQUEST'
export const MEDIA_ATTACHMENTS_EXPAND_SUCCESS = 'MEDIA_ATTACHMENTS_EXPAND_SUCCESS'
export const MEDIA_ATTACHMENTS_EXPAND_FAIL    = 'MEDIA_ATTACHMENTS_EXPAND_FAIL'

const expand = (key, id, route, params) => (dispatch, getState) => {
  if (!id) return

  const path = ['media_attachments', key, id]
  const mediaType = params?.type || params?.mediaType || undefined
  if (!!mediaType) path.push(mediaType)

  const block = getState().getIn(path)
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError'))) return

  const queryString = isObject(params) ? `?${new URLSearchParams(params).toString()}` : ''

  // check if initial load already occured and if we need to load more
  const next = !!block ? block.get('next') : null
  const isLoadingMore = !!next
  const url = next || `/api/v1/${route}/${id}/media_attachments${queryString}`

  dispatch(expandRequest(key, id, isLoadingMore, mediaType))

  api(getState).get(url).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    const { statuses, marketplace_listings, media_attachments } = response.data
  
    if (Array.isArray(statuses)) dispatch(importFetchedStatuses(statuses))
    if (Array.isArray(media_attachments)) dispatch(importMediaAttachments(media_attachments))
    if (Array.isArray(marketplace_listings)) dispatch(importFetchedMarketplaceListings(marketplace_listings))
    dispatch(expandSuccess(key, id, mediaType, next ? next.uri : null, media_attachments, response.code === 206, isLoadingMore))
  }).catch((error) => {
    dispatch(expandFail(key, id, mediaType, error))
  })
}

const expandRequest = (key, id, isLoadingMore, mediaType) => ({
  type: MEDIA_ATTACHMENTS_EXPAND_REQUEST,
  key,
  id,
  mediaType,
  isLoadingMore,
})

const expandSuccess = (key, id, mediaType, next, mediaAttachments, partial, isLoadingRecent, isLoadingMore) => ({
  type: MEDIA_ATTACHMENTS_EXPAND_SUCCESS,
  key,
  next,
  mediaType,
  mediaAttachments,
  id,
  partial,
  isLoadingRecent,
  isLoadingMore,
})

const expandFail = (key, id, mediaType, error) => ({
  type: MEDIA_ATTACHMENTS_EXPAND_FAIL,
  key,
  id,
  mediaType,
  error,
})

// : todo : flesh out "params"
// source=status
export const expandMediaAttachmentsByAccountId = (accountId, params) => expand('account', accountId, 'accounts', params)

export const expandMediaAttachmentsByGroupId = (groupId) => expand('group', groupId, 'groups')
  
export const expandMediaAttachmentsByChatConversationId = (chatConversationId) => expand('chat_conversation', chatConversationId, 'chat_conversation')
