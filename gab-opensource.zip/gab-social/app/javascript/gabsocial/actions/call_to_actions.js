import api from '../api'

export const CALL_TO_ACTIONS_FETCH_REQUEST = 'CALL_TO_ACTIONS_FETCH_REQUEST'
export const CALL_TO_ACTIONS_FETCH_SUCCESS = 'CALL_TO_ACTIONS_FETCH_SUCCESS'
export const CALL_TO_ACTIONS_FETCH_FAIL    = 'CALL_TO_ACTIONS_FETCH_FAIL'

/**
 * 
 */
export const fetchCallToActions = () => (dispatch, getState) => {
  const CACHE_KEY = 'gabsocial_call_to_actions_cache'
  const CACHE_EXPIRY = 1000 * 60 * 60 * 6 // 6 hours

  // Try to get cached call to actions
  try {
    const cached = localStorage.getItem(CACHE_KEY)
    if (cached) {
      const { data, timestamp } = JSON.parse(cached)
      
      // Use cache if not expired
      if (Date.now() - timestamp <= CACHE_EXPIRY) {
        dispatch(fetchCallToActionsSuccess(data))
        return
      }
      localStorage.removeItem(CACHE_KEY)
    }
  } catch (e) {
    console.warn('Error reading call to actions cache:', e)
  }

  dispatch(fetchCallToActionsRequest())

  api(getState).get('/api/v1/call_to_actions').then(response => {
    // Cache the new data
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({
        data: response.data,
        timestamp: Date.now()
      }))
    } catch (e) {
      console.warn('Error writing to call to actions cache:', e)
    }
    
    dispatch(fetchCallToActionsSuccess(response.data))
  }).catch(error => dispatch(fetchCallToActionsFail(error)))
}

const fetchCallToActionsRequest = () => ({
  type: CALL_TO_ACTIONS_FETCH_REQUEST,
})

const fetchCallToActionsSuccess = (ctas) => ({
  type: CALL_TO_ACTIONS_FETCH_SUCCESS,
  ctas,
})

const fetchCallToActionsFail = (error) => ({
  type: CALL_TO_ACTIONS_FETCH_FAIL,
  error,
})
