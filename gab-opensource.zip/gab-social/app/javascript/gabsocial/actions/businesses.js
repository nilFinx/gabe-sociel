import api, { getLinks } from '../api'
import isObject from 'lodash/isObject'
import isNil from 'lodash/isNil'
import {
  Map as ImmutableMap,
  List as ImmutableList,
} from 'immutable'
import { me, meBusinesses } from '../initial_state'
import { resetBusinessEditor } from './business_editor'
import { importBusinesses, importFetchedBusinesses, importFetchedMarketplaceListings } from './importer'
import { BUSINESS_PROMOTION_LISTINGS } from '../constants'

export const BUSINESS_CREATE_REQUEST = 'BUSINESS_CREATE_REQUEST'
export const BUSINESS_CREATE_SUCCESS = 'BUSINESS_CREATE_SUCCESS'
export const BUSINESS_CREATE_FAIL    = 'BUSINESS_CREATE_FAIL'

export const BUSINESS_EDIT_REQUEST = 'BUSINESS_EDIT_REQUEST'
export const BUSINESS_EDIT_SUCCESS = 'BUSINESS_EDIT_SUCCESS'
export const BUSINESS_EDIT_FAIL    = 'BUSINESS_EDIT_FAIL'

export const BUSINESS_CATEGORIES_FETCH_REQUEST = 'BUSINESS_CATEGORIES_FETCH_REQUEST'
export const BUSINESS_CATEGORIES_FETCH_SUCCESS = 'BUSINESS_CATEGORIES_FETCH_SUCCESS'
export const BUSINESS_CATEGORIES_FETCH_FAIL    = 'BUSINESS_CATEGORIES_FETCH_FAIL'

export const BUSINESSES_FETCH_MANAGED_REQUEST = 'BUSINESSES_FETCH_MANAGED_REQUEST'
export const BUSINESSES_FETCH_MANAGED_SUCCESS = 'BUSINESSES_FETCH_MANAGED_SUCCESS'
export const BUSINESSES_FETCH_MANAGED_FAIL    = 'BUSINESSES_FETCH_MANAGED_FAIL'

export const BUSINESSES_FETCH_PROMOTED_REQUEST = 'BUSINESSES_FETCH_PROMOTED_REQUEST'
export const BUSINESSES_FETCH_PROMOTED_SUCCESS = 'BUSINESSES_FETCH_PROMOTED_SUCCESS'
export const BUSINESSES_FETCH_PROMOTED_FAIL    = 'BUSINESSES_FETCH_PROMOTED_FAIL'

export const BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_REQUEST = 'BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_REQUEST'
export const BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_SUCCESS = 'BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_SUCCESS'
export const BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_FAIL = 'BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_FAIL'

export const BUSINESS_FETCH_REQUEST = 'BUSINESS_FETCH_REQUEST'
export const BUSINESS_FETCH_SUCCESS = 'BUSINESS_FETCH_SUCCESS'
export const BUSINESS_FETCH_FAIL = 'BUSINESS_FETCH_FAIL'

export const BUSINESSES_FETCH_BY_SEARCH_REQUEST = 'BUSINESSES_FETCH_BY_SEARCH_REQUEST'
export const BUSINESSES_FETCH_BY_SEARCH_SUCCESS = 'BUSINESSES_FETCH_BY_SEARCH_SUCCESS'
export const BUSINESSES_FETCH_BY_SEARCH_FAIL    = 'BUSINESSES_FETCH_BY_SEARCH_FAIL'

export const BUSINESSES_EXPAND_BY_SEARCH_REQUEST = 'BUSINESSES_EXPAND_BY_SEARCH_REQUEST'
export const BUSINESSES_EXPAND_BY_SEARCH_SUCCESS = 'BUSINESSES_EXPAND_BY_SEARCH_SUCCESS'
export const BUSINESSES_EXPAND_BY_SEARCH_FAIL = 'BUSINESSES_EXPAND_BY_SEARCH_FAIL'

export const BUSINESS_SEARCH_RESET = 'BUSINESS_SEARCH_RESET'
export const BUSINESS_SEARCH_QUERY_CHANGE = 'BUSINESS_SEARCH_QUERY_CHANGE'
export const BUSINESS_SEARCH_QUERY_CLEAR = 'BUSINESS_SEARCH_QUERY_CLEAR'
export const BUSINESS_SEARCH_ATTR_CHANGE = 'BUSINESS_SEARCH_ATTR_CHANGE'

export const BUSINESS_VIEW_CHANGE = 'BUSINESS_VIEW_CHANGE'
export const BUSINESS_SEARCH_RESET_INNER_ATTRS = 'BUSINESS_SEARCH_RESET_INNER_ATTRS'
export const BUSINESS_AVAILABLE_ATTRS_SUCCESS = 'BUSINESS_AVAILABLE_ATTRS_SUCCESS'

export const MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_REQUEST = 'MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_REQUEST'
export const MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_SUCCESS = 'MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_SUCCESS'
export const MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_FAIL = 'MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_FAIL'

export const BUSINESS_UPDATE_HOURS_REQUEST = 'BUSINESS_UPDATE_HOURS_REQUEST'
export const BUSINESS_UPDATE_HOURS_SUCCESS = 'BUSINESS_UPDATE_HOURS_SUCCESS'
export const BUSINESS_UPDATE_HOURS_FAIL = 'BUSINESS_UPDATE_HOURS_FAIL'

export const BUSINESS_UPDATE_COUPONS_REQUEST = 'BUSINESS_UPDATE_COUPONS_REQUEST'
export const BUSINESS_UPDATE_COUPONS_SUCCESS = 'BUSINESS_UPDATE_COUPONS_SUCCESS'
export const BUSINESS_UPDATE_COUPONS_FAIL = 'BUSINESS_UPDATE_COUPONS_FAIL'

const isString = val => typeof val === 'string'

/**
 * 
 */
export const businessCreate = (history) => (dispatch, getState) => {
  if (!me) return false

  const attrs = getState().getIn(['business_editor', 'attrs'])
  if (!attrs) return false

  const categories = !!attrs.get('categories') ? attrs.get('categories').map((c) => c.id) : []
  const data = {
    name: attrs.get('name'),
    tagline: attrs.get('tagline'),
    description: attrs.get('description'),
    websites: attrs.get('websites'),
    categories: JSON.stringify(categories),
  }

  dispatch(businessCreateRequest())

  api(getState).post(`/api/v1/businesses`, data).then((result) => {
    dispatch(importBusinesses([result.data]))
    dispatch(businessCreateSuccess(result.data))
    dispatch(resetBusinessEditor())
    
    if (Array.isArray(meBusinesses)) meBusinesses.push(result.data.id)

    if (history) history.push('/marketplace/business/join/thanks')
  }).catch((err) => dispatch(businessCreateFail(err)))
}

const businessCreateRequest = () => ({
  type: BUSINESS_CREATE_REQUEST,
})

const businessCreateSuccess = (business) => ({
  type: BUSINESS_CREATE_SUCCESS,
  business,
})

const businessCreateFail = (error) => ({
  type: BUSINESS_CREATE_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const businessEdit = (history) => (dispatch, getState) => {
  if (!me) return false

  const attrs = getState().getIn(['business_editor', 'attrs'])
  if (!attrs) return false
  const businessId = getState().getIn(['business_editor', 'businessId'])
  if (!businessId) return false

  const categories = !!attrs.get('categories') ? attrs.get('categories').map((c) => c.id) : []

	const formData = new FormData()
	formData.append('name', attrs.get('name'))
	formData.append('tagline',  attrs.get('tagline'))
	formData.append('description', attrs.get('description'))
	formData.append('websites', attrs.get('websites'))
	formData.append('cta_title', attrs.get('cta_title'))
	formData.append('cta_link', attrs.get('cta_link'))
  formData.append('phone_number', attrs.get('phone'))
  formData.append('account_hidden', attrs.get('account_hidden'))
	formData.append('categories', JSON.stringify(categories))
  formData.append('locations', JSON.stringify(attrs.get('location')))

	if (!!attrs.get('logo') && !isString(attrs.get('logo'))) {
		formData.append('avatar', attrs.get('logo'))
	}
  if (!!attrs.get('cover') && !isString(attrs.get('cover'))) {
		formData.append('cover', attrs.get('cover'))
	}

  dispatch(businessEditRequest())

	api(getState).put(`/api/v1/businesses/${businessId}`, formData, {
		headers: {
			'Content-Type': 'multipart/form-data'
		}
	}).then(({ data }) => {
    dispatch(businessEditSuccess(data))
    dispatch(importBusinesses([data]))
    dispatch(resetBusinessEditor())
    if (history) history.push(`/business/${businessId}`)
  }).catch((err) => dispatch(businessEditFail(err)))
}

const businessEditRequest = () => ({
  type: BUSINESS_EDIT_REQUEST,
})

const businessEditSuccess = (business) => ({
  type: BUSINESS_EDIT_SUCCESS,
  business,
})

const businessEditFail = (error) => ({
  type: BUSINESS_EDIT_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const fetchBusinessCategories = () => (dispatch, getState) => {
  // Check if exists already
  if (getState().getIn(['businesses', 'categoriesIsFetched'])) return
  
  dispatch(fetchBusinessCategoriesRequest())

  api(getState).get(`/api/v1/business_categories`)
    .then((response) => dispatch(fetchBusinessCategoriesSuccess(response.data)))
    .catch((err) => dispatch(fetchBusinessCategoriesFail(err)))
}

const fetchBusinessCategoriesRequest = () => ({
  type: BUSINESS_CATEGORIES_FETCH_REQUEST,
})

const fetchBusinessCategoriesSuccess = (businessCategories) => ({
  type: BUSINESS_CATEGORIES_FETCH_SUCCESS,
  businessCategories,
})

const fetchBusinessCategoriesFail = (error) => ({
  type: BUSINESS_CATEGORIES_FETCH_FAIL,
  error,
})

/**
 * 
 */
export const fetchManagedBusinesses = () => (dispatch, getState) => {
  if (!me || !meBusinesses) return

  // Don't refetch or fetch when loading
  const isLoading = getState().getIn(['business_lists', 'managed', 'isLoading'])
  const isFetched = getState().getIn(['business_lists', 'managed', 'isFetched'])

  if (isLoading || isFetched) return

  dispatch(fetchManagedBusinessesRequest())

  api(getState).get(`/api/v1/businesses`).then((response) => {
    const {businesses, business_accounts} = response.data

    dispatch(fetchManagedBusinessesSuccess(businesses, business_accounts))
  }).catch((err) => dispatch(fetchManagedBusinessesFail(err)))
}

const fetchManagedBusinessesRequest = () => ({
  type: BUSINESSES_FETCH_MANAGED_REQUEST,
})

const fetchManagedBusinessesSuccess = (businesses, business_accounts) => ({
  type: BUSINESSES_FETCH_MANAGED_SUCCESS,
  businesses,
  business_accounts,
})

const fetchManagedBusinessesFail = (error) => ({
  type: BUSINESSES_FETCH_MANAGED_FAIL,
  showToast: true,
  error,
})


/**
 * 
 */
export const expandBusinessFrontPage = () => (dispatch, getState) => {
  const hasMore = getState().getIn(['business_lists', 'frontpage', 'hasMore'])
  if (!hasMore) return
  
  dispatch(expandBusinessFrontPageRequest())

  const loadedCategoryIds = getState().getIn(['business_lists', 'frontpage', 'loadedCategoryIds']).toJS()
  let apiUrl = '/api/v1/business_browse';

  if (loadedCategoryIds.length > 0) {
    const ecParam = loadedCategoryIds.join(',');
    apiUrl += `?ec=${ecParam}`;
  }

  api(getState).get(apiUrl).then(({ data }) => {
    const { categories, recent } = data
    const businesses = getAllBusinesses(data)
    dispatch(importFetchedBusinesses(businesses))
    dispatch(expandBusinessFrontPageSuccess(recent, categories)) 
  }).catch((error) => {
    dispatch(expandBusinessFrontPageFail(error))
  })
}

const getAllBusinesses = (data) => {
  const categoriesListings = data.categories.flatMap(result => result.listings)
  const allListings = [...data.recent, ...categoriesListings]
  return allListings
}

const expandBusinessFrontPageRequest = (isLoadingMore) => ({
  type: BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_REQUEST,
  isLoadingMore,
})

const expandBusinessFrontPageSuccess = (recent, categories) => ({
  type: BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_SUCCESS,
  recent,
  categories,
})

const expandBusinessFrontPageFail = (error) => ({
  type: BUSINESS_FRONT_PAGE_LISTINGS_EXPAND_FAIL,
  error,
})

/**
 * 
 */
export const fetchPromotedBusinesses = (promotion, categoryId) => (dispatch, getState) => {
  if (!promotion) return

  // Check existing state first
  if (!categoryId) {
    let existingPromotions = getState().getIn(['business_lists', 'promoted', promotion])
    if (existingPromotions) return
  } else {
    let existingPromotions = getState().getIn(['business_lists', 'promoted_category', categoryId, promotion])
    if (existingPromotions) return
  }

  dispatch(fetchPromotedBusinessesRequest())

  // Convert the promotions array into a query string
  let queryString = `promotion[]=${encodeURIComponent(promotion)}`
  if (!!categoryId) queryString += `&category=${encodeURIComponent(categoryId)}`
  const url = `/api/v1/business_promoted?${queryString}`;
  api(getState).get(url).then((response) => {

    const isListings = BUSINESS_PROMOTION_LISTINGS.indexOf(promotion) > -1
    if (isListings) {
      dispatch(importFetchedMarketplaceListings(response.data))
    } else {
      dispatch(importFetchedBusinesses(response.data))
    }
    dispatch(fetchPromotedBusinessesSuccess(response.data, promotion, categoryId, isListings)) 
  }).catch((err) => dispatch(fetchPromotedBusinessesFail(err)))
}

const fetchPromotedBusinessesRequest = () => ({
  type: BUSINESSES_FETCH_PROMOTED_REQUEST,
})

const fetchPromotedBusinessesSuccess = (businesses, promotion, categoryId, isListings) => ({
  type: BUSINESSES_FETCH_PROMOTED_SUCCESS,
  promotion,
  categoryId,
  isListings,
  businesses,
})

const fetchPromotedBusinessesFail = (error) => ({
  type: BUSINESSES_FETCH_PROMOTED_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const fetchBusinessById = (businessId) => (dispatch, getState) => {
  dispatch(fetchBusinessByIdRequest(businessId))

  api(getState).get(`/api/v1/businesses/${businessId}`).then((response) => {
    dispatch(fetchBusinessByIdSuccess(response.data))
    dispatch(importBusinesses([response.data]))
  }).catch((err) => dispatch(fetchBusinessByIdFail(err)))
}

const fetchBusinessByIdRequest = () => ({
  type: BUSINESS_FETCH_REQUEST,
})

const fetchBusinessByIdSuccess = (business) => ({
  type: BUSINESS_FETCH_SUCCESS,
  business,
})

const fetchBusinessByIdFail = (error) => ({
  type: BUSINESS_FETCH_FAIL,
  showToast: true,
  error,
})


/**
 * 
 * @returns 
 */
export const fetchBusinessesBySearch = (history) => (dispatch, getState) => {
  // get existing category list items state
  const block = getState().getIn(['business_lists', 'search'])
  
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError'))) {
    return
  }

  const filters = block.get('filters')
  
  if (!!history) {
    const queryParams = getQueryParamsFromFilters(filters)
    // Exclude category_slug from queryParams if it exists
    if (queryParams.category_slug) delete queryParams.category_slug
    const qs = queryString.stringify(queryParams)
    history.replace({
      pathname: '/businesses/search',
      search: `?${qs}`,
      isActive: true,
    })
  }
  
  dispatch(fetchBusinessesBySearchRequest())

  const params = getQueryParamsFromFilters(filters)

  api(getState).get(`/api/v1/business_search`, { params }).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(importFetchedBusinesses(response.data))
    dispatch(fetchBusinessesBySearchSuccess(next ? next.uri : null, response.data, filters, response.code === 206))      
  }).catch((error) => {
    dispatch(fetchBusinessesBySearchFail(error))
  })
}

const fetchBusinessesBySearchRequest = () => ({
  type: BUSINESSES_FETCH_BY_SEARCH_REQUEST,
})

const fetchBusinessesBySearchSuccess = (next, data, currentFilters, partial) => ({
  type: BUSINESSES_FETCH_BY_SEARCH_SUCCESS,
  next,
  data,
  partial,
  currentFilters,
})

const fetchBusinessesBySearchFail = (error) => ({
  type: BUSINESSES_FETCH_BY_SEARCH_FAIL,
  error,
})

/**
 * 
 * @returns 
 */
export const expandBusinessesBySearch = () => (dispatch, getState) => {
  // get existing category list items state
  const block = getState().getIn(['business_lists', 'search'])
  
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError') || !block.get('next'))) {
    return
  }

  const next = block.get('next')
  
  dispatch(expandBusinessesBySearchRequest())

  api(getState).get(next).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(importFetchedBusinesses(response.data))
    dispatch(expandBusinessesBySearchSuccess(next ? next.uri : null, response.data, response.code === 206))
  }).catch((error) => {
    dispatch(expandBusinessesBySearchFail(error))
  })
}

const expandBusinessesBySearchRequest = () => ({
  type: BUSINESSES_EXPAND_BY_SEARCH_REQUEST,
})

const expandBusinessesBySearchSuccess = (next, data, partial) => ({
  type: BUSINESSES_EXPAND_BY_SEARCH_SUCCESS,
  next,
  data,
  partial,
})

const expandBusinessesBySearchFail = (error) => ({
  type: BUSINESSES_EXPAND_BY_SEARCH_FAIL,
  error,
})

/**
 * 
 */
export const businessSearchReset = () => ({
  type: BUSINESS_SEARCH_RESET,
})

export const changeBusinessSearchQuery = (value) => ({
  type: BUSINESS_SEARCH_QUERY_CHANGE,
  value,
})

export const clearBusinessSearchQuery = () => ({
  type: BUSINESS_SEARCH_QUERY_CLEAR,
})

export const changeBusinessSearchAttr = (key, value) => ({
  type: BUSINESS_SEARCH_ATTR_CHANGE,
  listing_key: key,
  listing_value: value,
})

/**
 * 
 */
export const setParamsForBusinessSearch = (qs) => (dispatch) => {
  if (!isObject(qs)) return

  if (isNil(qs.query)) {
    qs.query = ''
  }

  for (const key in qs) {
    if (Object.hasOwnProperty.call(qs, key) && key.toLowerCase()) {
      const value = qs[key]
      const setKey = ([].indexOf(key) > -1) ? ['attrs', key] : key
      dispatch(changeBusinessSearchAttr(setKey, value))
    }
  }

  // dispatch(changeMarketplaceListingSearchQuery(value))
  // type: MARKETPLACE_LISTING_SEARCH_SET_PARAMS,
}

/**
 * 
 * @param {*} filters 
 * @returns 
 */
export const getQueryParamsFromFilters = (filters) => {
  if (!filters) return {}
  const basicFilters = ['query', 'category_id', 'category_slug']
  
  const paramAttrs = [].reduce((acc, key) => {
    const value = filters.getIn(['attrs', key], undefined) // gets the value or returns undefined
    if (value !== "" && value !== undefined) {
      acc[key] = value
    }
    return acc
  }, {});
  
  const params = {
    page: 1,
    ...basicFilters.reduce((acc, key) => {
      const value = filters.get(key, undefined)
      if (value !== "" && value !== undefined) {
        return acc.set(key, value)
      }
      return acc;
    }, ImmutableMap()).toJS(),
    ...paramAttrs,
  }

  return params
}

/**
 * Only get APPROVED items by businessId
 */
export const expandMarketplaceListingsByBusiness = (businessId, params={}) => (dispatch, getState) => {
  // must have id
  if (!businessId) return

  // get existing user list items state
  const block = getState().getIn(['marketplace_listings_lists', 'business', businessId])

  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError'))) {
    return
  }

  // check if initial load already occured and if we need to load more
  const isLoadingMore = !!params.maxId

  // if no maxId present, we need to load from the start or "since" 
  if (!params.maxId && !!block && block.get('items', ImmutableList()).size > 0) {
    params.sinceId = params.sinceId || block.getIn(['items', 0])
  }

  const next = !!block ? block.get('next') : null
  const url = next || '/api/v1/marketplace_listing_search'
  const isLoadingRecent = !!params.sinceId
  params = !!next ? {} : {
    params: {
      business_id: businessId,
      max_id: params.maxId,
      since_id: params.sinceId,
    },
  }

  dispatch(expandMarketplaceListingsByBusinessRequest(businessId, isLoadingMore))

  api(getState).get(url, params).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(importFetchedMarketplaceListings(response.data))
    dispatch(expandMarketplaceListingsByBusinessSuccess(businessId, next ? next.uri : null, response.data, response.code === 206, isLoadingRecent, isLoadingMore))
  }).catch((error) => {
    dispatch(expandMarketplaceListingsByBusinessFail(error, businessId))
  })
}

const expandMarketplaceListingsByBusinessRequest = (businessId, isLoadingMore) => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_REQUEST,
  businessId,
  isLoadingMore,
})

const expandMarketplaceListingsByBusinessSuccess = (businessId, next, data, partial, isLoadingRecent, isLoadingMore) => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_SUCCESS,
  next,
  data,
  businessId,
  partial,
  isLoadingRecent,
  isLoadingMore,
})

const expandMarketplaceListingsByBusinessFail = (error, businessId) => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_BUSINESS_FAIL,
  error,
  businessId,
})

/**
 * 
 */
export const updateBusinessHours = (businessId, hours, is247) => (dispatch, getState) => {
  dispatch(updateBusinessHoursRequest(businessId))

  api(getState).post(`/api/v1/businesses/${businessId}/update_hours`, { hours, is247 }).then((response) => {
    dispatch(updateBusinessHoursSuccess(response.data))
    dispatch(importBusinesses([response.data]))
  }).catch((err) => dispatch(updateBusinessHoursFail(err)))
}

const updateBusinessHoursRequest = () => ({
  type: BUSINESS_UPDATE_HOURS_REQUEST,
})

const updateBusinessHoursSuccess = (business) => ({
  type: BUSINESS_UPDATE_HOURS_SUCCESS,
  showToast: true,
  business,
})

const updateBusinessHoursFail = (error) => ({
  type: BUSINESS_UPDATE_HOURS_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const updateBusinessCoupons = (businessId, coupons) => (dispatch, getState) => {
  dispatch(updateBusinessCouponsRequest(businessId))

  api(getState).post(`/api/v1/businesses/${businessId}/update_coupons`, { coupons }).then((response) => {
    dispatch(updateBusinessCouponsSuccess(response.data))
    dispatch(importBusinesses([response.data]))
  }).catch((err) => dispatch(updateBusinessCouponsFail(err)))
}

const updateBusinessCouponsRequest = () => ({
  type: BUSINESS_UPDATE_COUPONS_REQUEST,
})

const updateBusinessCouponsSuccess = (business) => ({
  type: BUSINESS_UPDATE_COUPONS_SUCCESS,
  showToast: true,
  business,
})

const updateBusinessCouponsFail = (error) => ({
  type: BUSINESS_UPDATE_COUPONS_FAIL,
  showToast: true,
  error,
})