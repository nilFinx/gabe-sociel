import api from '../api'
import { fetchRelationships } from './accounts'
import { importFetchedAccounts } from './importer'
import { me } from '../initial_state'

export const FRIEND_ADD_REQUEST = 'FRIEND_ADD_REQUEST'
export const FRIEND_ADD_SUCCESS = 'FRIEND_ADD_SUCCESS'
export const FRIEND_ADD_FAIL    = 'FRIEND_ADD_FAIL'

export const FRIEND_REMOVE_REQUEST = 'FRIEND_REMOVE_REQUEST'
export const FRIEND_REMOVE_SUCCESS = 'FRIEND_REMOVE_SUCCESS'
export const FRIEND_REMOVE_FAIL    = 'FRIEND_REMOVE_FAIL'

export const FRIENDS_FETCH_REQUEST = 'FRIENDS_FETCH_REQUEST'
export const FRIENDS_FETCH_SUCCESS = 'FRIENDS_FETCH_SUCCESS'
export const FRIENDS_FETCH_FAIL    = 'FRIENDS_FETCH_FAIL'

export const TOP_FRIEND_EDITOR_RESET = 'TOP_FRIEND_EDITOR_RESET'
export const TOP_FRIEND_EDITOR_SUGGESTIONS_READY = 'TOP_FRIEND_EDITOR_SUGGESTIONS_READY'
export const TOP_FRIEND_EDITOR_SUGGESTIONS_CLEAR = 'TOP_FRIEND_EDITOR_SUGGESTIONS_CLEAR'
export const TOP_FRIEND_EDITOR_SUGGESTIONS_CHANGE = 'TOP_FRIEND_EDITOR_SUGGESTIONS_CHANGE'

export const fetchFriends = (accountId) => (dispatch, getState) => {
  if (!me) return

  dispatch(fetchFriendsRequest(accountId))

  api(getState).get(`/api/v1/friends/${accountId}/top`).then((response) => {
    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchFriendsSuccess(accountId, response.data))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(fetchFriendsFail(accountId, error))
  })
}

const fetchFriendsRequest = (accountId) => ({
  type: FRIENDS_FETCH_REQUEST,
  accountId,
})

const fetchFriendsSuccess = (accountId, accounts) => ({
  type: FRIENDS_FETCH_SUCCESS,
  accountId,
  friendAccounts: accounts,
})

const fetchFriendsFail = (accountId, error) => ({
  type: FRIENDS_FETCH_FAIL,
  accountId,
  showToast: true,
  error,
})

export const addFriend = (accountId) => (dispatch, getState) => {
  if (!me || !accountId) return

  dispatch(addFriendRequest(me))

  api(getState).post(`/api/v1/friends/${accountId}/add`).then((response) => {
    dispatch(addFriendSuccess(me, response.data))
  }).catch((error) => {
    dispatch(addFriendFail(me, error))
  })
}

const addFriendRequest = (accountId) => ({
  type: FRIEND_ADD_REQUEST,
  accountId,
})

const addFriendSuccess = (accountId, friendAccount) => ({
  type: FRIEND_ADD_SUCCESS,
  accountId,
  showToast: true,
  friendAccount,
})

const addFriendFail = (accountId, error) => ({
  type: FRIEND_ADD_FAIL,
  showToast: true,
  accountId,
  error,
})

export const removeFriend = (accountId) => (dispatch, getState) => {
  if (!me || !accountId) return

  dispatch(removeFriendRequest(me, accountId))

  api(getState).post(`/api/v1/friends/${accountId}/remove`).then((response) => {
    dispatch(removeFriendSuccess(me, response.data.id))
  }).catch((error) => {
    dispatch(removeFriendFail(me, accountId, error))
  })
}

const removeFriendRequest = (accountId, friendAccountId) => ({
  type: FRIEND_REMOVE_REQUEST,
  accountId,
  friendAccountId,
})

const removeFriendSuccess = (accountId, friendAccountId) => ({
  type: FRIEND_REMOVE_SUCCESS,
  showToast: true,
  accountId,
  friendAccountId
})

const removeFriendFail = (accountId, friendAccountId, error) => ({
  type: FRIEND_REMOVE_FAIL,
  showToast: true,
  accountId,
  friendAccountId,
  error,
})


export const resetTopFriendEditor = () => ({
  type: TOP_FRIEND_EDITOR_RESET,
})

export const fetchTopFriendSuggestions = (q) => (dispatch, getState) => {
  if (!me || !q || !q.trim()) {
    dispatch(importFetchedAccounts([]))
    dispatch(fetchTopFriendSuggestionsReady(q, []))
    return
  }

  const params = {
    q,
    resolve: false,
    limit: 25,
  }

  api(getState).get('/api/v1/accounts/search', { params }).then(({ data }) => {
    dispatch(importFetchedAccounts(data))
    dispatch(fetchTopFriendSuggestionsReady(q, data))
  })
  // }).catch(error => dispatch(showAlertForError(error)))
}

const fetchTopFriendSuggestionsReady = (query, accounts) => ({
  type: TOP_FRIEND_EDITOR_SUGGESTIONS_READY,
  query,
  accounts,
})

export const clearTopFriendSuggestions = () => ({
  type: TOP_FRIEND_EDITOR_SUGGESTIONS_CLEAR,
})

export const changeTopFriendSuggestions = (value) => ({
  type: TOP_FRIEND_EDITOR_SUGGESTIONS_CHANGE,
  value,
})