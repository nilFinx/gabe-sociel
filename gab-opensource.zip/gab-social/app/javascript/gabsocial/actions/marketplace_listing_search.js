import api, { getLinks } from '../api'
import isObject from 'lodash/isObject'
import isNil from 'lodash/isNil'
import { Map as ImmutableMap } from 'immutable'
import { importFetchedMarketplaceListings } from './importer'
import queryString from 'query-string'
import { me } from '../initial_state'
import { MARKETPLACE_LISTING_AVAILABLE_UNIQUE_ATTRIBUTES } from '../constants'

export const MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_REQUEST = 'MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_REQUEST'
export const MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_SUCCESS = 'MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_SUCCESS'
export const MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_FAIL = 'MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_FAIL'

export const MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_REQUEST = 'MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_REQUEST'
export const MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_SUCCESS = 'MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_SUCCESS'
export const MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_FAIL = 'MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_FAIL'

export const MARKETPLACE_LISTING_AVAILABLE_ATTRS_REQUEST = 'MARKETPLACE_LISTING_AVAILABLE_ATTRS_REQUEST'
export const MARKETPLACE_LISTING_AVAILABLE_ATTRS_SUCCESS = 'MARKETPLACE_LISTING_AVAILABLE_ATTRS_SUCCESS'
export const MARKETPLACE_LISTING_AVAILABLE_ATTRS_FAIL = 'MARKETPLACE_LISTING_AVAILABLE_ATTRS_FAIL'

export const MARKETPLACE_LISTING_SEARCH_QUERY_CHANGE = 'MARKETPLACE_LISTING_SEARCH_QUERY_CHANGE'
export const MARKETPLACE_LISTING_SEARCH_QUERY_CLEAR = 'MARKETPLACE_LISTING_SEARCH_QUERY_CLEAR'

export const MARKETPLACE_LISTING_SEARCH_ATTR_CHANGE = 'MARKETPLACE_LISTING_SEARCH_ATTR_CHANGE'

export const MARKETPLACE_LISTING_SEARCH_FILTER_CHANGED = 'MARKETPLACE_LISTING_SEARCH_FILTER_CHANGED'

export const MARKETPLACE_LISTING_SEARCH_SET_PARAMS = 'MARKETPLACE_LISTING_SEARCH_SET_PARAMS'

export const MARKETPLACE_LISTING_SEARCH_RESET = 'MARKETPLACE_LISTING_SEARCH_RESET'
export const MARKETPLACE_LISTING_SEARCH_RESET_INNER_ATTRS = 'MARKETPLACE_LISTING_SEARCH_RESET_INNER_ATTRS'

export const MARKETPLACE_LISTING_VIEW_CHANGE = 'MARKETPLACE_LISTING_VIEW_CHANGE'

export const getQueryParamsFromFilters = (filters) => {
  if (!filters) return {}
  const basicFilters = ['query', 'price_min', 'price_max', 'sort_by', 'condition', 'category_id', 'category_slug']
  
  const paramAttrs = MARKETPLACE_LISTING_AVAILABLE_UNIQUE_ATTRIBUTES.reduce((acc, key) => {
    const value = filters.getIn(['attrs', key], undefined) // gets the value or returns undefined
    if (value !== "" && value !== undefined) {
      acc[key] = value
    }
    return acc
  }, {});
  
  const params = {
    page: 1,
    ...basicFilters.reduce((acc, key) => {
      const value = filters.get(key, undefined)
      if (value !== "" && value !== undefined) {
        return acc.set(key, value)
      }
      return acc;
    }, ImmutableMap()).toJS(),
    ...paramAttrs,
  }

  return params
}

/**
 * 
 * @returns 
 */
 export const fetchMarketplaceListingsBySearch = (history) => (dispatch, getState) => {
  // get existing category list items state
  const block = getState().getIn(['marketplace_listing_search'])
  
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError'))) {
    return
  }

  const filters = block.get('filters')
  
  if (!!history) {
    const queryParams = getQueryParamsFromFilters(filters)
    // Exclude category_slug from queryParams if it exists
    if (queryParams.category_slug) delete queryParams.category_slug
    const qs = queryString.stringify(queryParams)
    history.replace({
      pathname: '/marketplace/listings',
      search: `?${qs}`,
      isActive: true,
    })
  }
  
  dispatch(fetchMarketplaceListingsBySearchRequest())

  const params = getQueryParamsFromFilters(filters)

  api(getState).get(`/api/v1/marketplace_listing_search`, { params }).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(importFetchedMarketplaceListings(response.data))
    dispatch(fetchMarketplaceListingsBySearchSuccess(next ? next.uri : null, response.data, filters, response.code === 206))
  }).catch((error) => {
    dispatch(fetchMarketplaceListingsBySearchFail(error))
  })
}

const fetchMarketplaceListingsBySearchRequest = () => ({
  type: MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_REQUEST,
})

const fetchMarketplaceListingsBySearchSuccess = (next, data, currentFilters, partial) => ({
  type: MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_SUCCESS,
  next,
  data,
  partial,
  currentFilters,
})

const fetchMarketplaceListingsBySearchFail = (error) => ({
  type: MARKETPLACE_LISTINGS_FETCH_BY_SEARCH_FAIL,
  error,
})

/**
 * 
 * @returns 
 */
 export const expandMarketplaceListingsBySearch = () => (dispatch, getState) => {
  // get existing category list items state
  const block = getState().getIn(['marketplace_listing_search'])
  
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError') || !block.get('next'))) {
    return
  }

  const next = block.get('next')
  
  dispatch(expandMarketplaceListingsBySearchRequest())

  api(getState).get(next).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(importFetchedMarketplaceListings(response.data))
    dispatch(expandMarketplaceListingsBySearchSuccess(next ? next.uri : null, response.data, response.code === 206))
  }).catch((error) => {
    dispatch(expandMarketplaceListingsBySearchFail(error))
  })
}

const expandMarketplaceListingsBySearchRequest = () => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_REQUEST,
})

const expandMarketplaceListingsBySearchSuccess = (next, data, partial) => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_SUCCESS,
  next,
  data,
  partial,
})

const expandMarketplaceListingsBySearchFail = (error) => ({
  type: MARKETPLACE_LISTINGS_EXPAND_BY_SEARCH_FAIL,
  error,
})

/**
 * 
 */
export const fetchMarketplaceListingAvailableAttributes = () => (dispatch, getState) => {
	if (!me) return

	dispatch(fetchMarketplaceListingAvailableAttributesRequest())

	api(getState).get('/api/v1/marketplace_listing_attributes').then(({ data }) => {
		dispatch(fetchMarketplaceListingAvailableAttributesSuccess(data))
	}).catch((err) => dispatch(fetchMarketplaceListingAvailableAttributesFail(err)))
}

const fetchMarketplaceListingAvailableAttributesRequest = () => ({
	type: MARKETPLACE_LISTING_AVAILABLE_ATTRS_REQUEST,
})

const fetchMarketplaceListingAvailableAttributesSuccess = (data) => ({
	type: MARKETPLACE_LISTING_AVAILABLE_ATTRS_SUCCESS,
	data,
})

const fetchMarketplaceListingAvailableAttributesFail = (error) => ({
	type: MARKETPLACE_LISTING_AVAILABLE_ATTRS_FAIL,
	error,
})

export const setParamsForMarketplaceListingSearch = (qs) => (dispatch) => {
  if (!isObject(qs)) return

  if (isNil(qs.query)) {
    qs.query = ''
  }

  for (const key in qs) {
    if (Object.hasOwnProperty.call(qs, key) && key.toLowerCase()) {
      const value = qs[key]
      const setKey = (MARKETPLACE_LISTING_AVAILABLE_UNIQUE_ATTRIBUTES.indexOf(key) > -1) ? ['attrs', key] : key
      dispatch(changeMarketplaceListingSearchAttr(setKey, value))
    }
  }

  // dispatch(changeMarketplaceListingSearchQuery(value))
  // type: MARKETPLACE_LISTING_SEARCH_SET_PARAMS,
}

/**
 * 
 * @param {*} value 
 * @returns 
 */
export const changeMarketplaceListingSearchQuery = (value) => ({
  type: MARKETPLACE_LISTING_SEARCH_QUERY_CHANGE,
  value,
})

export const clearMarketplaceListingSearchQuery = () => ({
  type: MARKETPLACE_LISTING_SEARCH_QUERY_CLEAR,
})

export const changeMarketplaceListingSearchAttr = (key, value) => ({
  type: MARKETPLACE_LISTING_SEARCH_ATTR_CHANGE,
  listing_key: key,
  listing_value: value,
})

/**
 * 
 */
 export const changeMarketplaceListingSearchFilterChanged = () => ({
  type: MARKETPLACE_LISTING_SEARCH_FILTER_CHANGED,
})

/**
 * 
 */
export const changeMarketplaceListingItemView = (tab) => ({
  type: MARKETPLACE_LISTING_VIEW_CHANGE,
  tab,
})

export const marketplaceSearchReset = () => ({
  type: MARKETPLACE_LISTING_SEARCH_RESET,
})

export const resetMarketplaceListingSearchInnerAttrs = () => ({
  type: MARKETPLACE_LISTING_SEARCH_RESET_INNER_ATTRS,
})