import api from '../api'
import { importFetchedAccounts, importFetchedLists } from './importer'
import { fetchRelationships } from './accounts'
import { me } from '../initial_state'
import {
  SUGGESTION_TYPES,
  SUGGESTION_TYPE_VERIFIED,
  SUGGESTION_TYPE_RELATED,
} from '../constants'
import { fetchListRelationships } from './lists'
import { fetchGroupRelationships, importGroups } from './groups'

export const SUGGESTIONS_FETCH_REQUEST = 'SUGGESTIONS_FETCH_REQUEST'
export const SUGGESTIONS_FETCH_SUCCESS = 'SUGGESTIONS_FETCH_SUCCESS'
export const SUGGESTIONS_FETCH_FAIL    = 'SUGGESTIONS_FETCH_FAIL'

export const SUGGESTIONS_DISMISS = 'SUGGESTIONS_DISMISS'

export const fetchPopularSuggestions = () => fetchSuggestions(SUGGESTION_TYPE_VERIFIED)
export const fetchRelatedSuggestions = () => fetchSuggestions(SUGGESTION_TYPE_RELATED)

/**
 * 
 */
export const fetchSuggestions = (suggestionType) => (dispatch, getState) => {
  const canFetch = me || (!me && suggestionType === SUGGESTION_TYPE_VERIFIED)
  if (!canFetch) return false
  if (SUGGESTION_TYPES.indexOf(suggestionType) < 0) return false

  dispatch(fetchSuggestionsRequest(suggestionType))

  api(getState).get(`/api/v2/suggestions?type=${suggestionType}`).then(({ data }) => {
    const { accounts, lists, groups, tags } = data

    let items = []
    if (Array.isArray(accounts)) {
      items = accounts
      dispatch(importFetchedAccounts(accounts))
      dispatch(fetchRelationships(accounts.map(item => item.id)))
    } else if (Array.isArray(lists)) {
      items = lists
      dispatch(importFetchedLists(lists))
      dispatch(fetchListRelationships(lists.map(item => item.id)))
    } else if (Array.isArray(groups)) {
      items = groups
      dispatch(importGroups(groups))
      dispatch(fetchGroupRelationships(groups.map(item => item.id)))
    } else if (Array.isArray(tags)) {
      items = tags
    }

    dispatch(fetchSuggestionsSuccess(items, suggestionType))
  }).catch(error => dispatch(fetchSuggestionsFail(error, suggestionType)))
}


const fetchSuggestionsRequest = (suggestionType) => ({
  type: SUGGESTIONS_FETCH_REQUEST,
  suggestionType,
})

const fetchSuggestionsSuccess = (items, suggestionType) => ({
  type: SUGGESTIONS_FETCH_SUCCESS,
  items,
  suggestionType
})

const fetchSuggestionsFail = (error, suggestionType) => ({
  type: SUGGESTIONS_FETCH_FAIL,
  skipAlert: true,
  error,
  suggestionType,
})

/**
 * 
 */
export const dismissRelatedSuggestion = (suggestionType, id) => (dispatch, getState) => {
  if (!me) return

  dispatch({
    type: SUGGESTIONS_DISMISS,
    suggestionType,
    id,
  })

  api(getState).delete(`/api/v2/suggestions?type=${suggestionType}&id={${id}`)
}