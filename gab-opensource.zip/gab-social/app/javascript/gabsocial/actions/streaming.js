import { streamingNotification, refreshCount } from './notifications'
import { manageIncomingChatMessage } from './chat_messages'
import { fetchFilters } from './filters'
import { timelinePrependItem, timelineQueue } from '../store/timelines'
import { importFetchedStatus } from './importer'
import { updateStatusStats } from './statuses'
import { timelineStatusDelete } from '../store/timelines'
import store from '../store/index'
import { me } from '../initial_state'

let eventStream;
let dispatch;
let idleTimeout;
const IDLE_TIMEOUT = 10 * 60 * 1000; // 10 minutes

// Track user activity
const updateActivity = () => {
  if (eventStream) {
    if (idleTimeout) {
      clearTimeout(idleTimeout);
    }
    idleTimeout = setTimeout(disconnectDueToIdle, IDLE_TIMEOUT);
  } else {
    // use local storage as a quick mutex to only do this once concurrently
    let mutex = false; //localStorage.getItem('streaming_idle_reconnecting')
    if (!mutex) {
      localStorage.setItem('streaming_idle_reconnecting', 'true')
      setTimeout(() => {
        localStorage.removeItem('streaming_idle_reconnecting')
      }, 2000)
      console.log('Reconnecting streaming connection.')
      connectAltStream(dispatch)
    }
  }
};

// Handle disconnection due to idle timeout
const disconnectDueToIdle = () => {
  if (eventStream) {
    console.log('Disconnecting idle streaming connection.')
    eventStream.close();
    eventStream = null;
    // Set a flag in localStorage to indicate idle disconnect
    localStorage.setItem('streamingDisconnectReason', 'idle');
  }
};

// Initialize activity tracking
const initActivityTracking = () => {
  // Track essential user interactions
  if (window && window._gss_loaded) {
    return;
  }

  const events = ['mousedown', 'keypress', 'touchstart'];
  events.forEach(event => {
    window.addEventListener(event, updateActivity, true);
  });
  
  window._gss_loaded = true;
  // Initial activity timestamp
  updateActivity();
};

export const connectAltStream = (d) => {
  dispatch = d
  if (!eventStream) {
    
    eventStream = new EventSource("/api/v4/streaming")
    eventStream.addEventListener('message', onReceive)

    let reconnecting = localStorage.getItem('streaming_idle_reconnecting')
    if (reconnecting) {
      // fetch the /api/v3/me route
      fetch('/api/v3/me')
        .then(response => response.json())
        .then(data => {
          if (data && data.meta && data.meta.unread_count) {
            dispatch(refreshCount(data.meta.unread_count))
          } else {
            console.log('Failed to fetch unread count')
          }
        })
        .catch(error => {
          console.error('Failed to fetch unread count:', error)
        })
    }

    // Initialize activity tracking when stream connects
    initActivityTracking();
    
    // Set initial idle timeout
    idleTimeout = setTimeout(disconnectDueToIdle, IDLE_TIMEOUT);
  }
}

function onReceive (data) {
  let state = store.getState()
  let event

  try {
    event = JSON.parse(data.data)
    if (event && !event.eventType) {
      event.eventType = 'ping'
    }
    if (event && !event.payload) {
      event.payload = {}
    }
  } catch (error) {
    console.error('Failed to parse incoming data:', error, data.data)
    return
  }

  if (!event || typeof event !== 'object') {
    console.error('Invalid event structure:', event)
    return
  }

  const { type, event: eventType, payload } = event

  if (type === 'ping') return;
  if (type === 'connected') {
    console.log('Gab altStream connected.')
    return
  }

  if (!eventType || !payload) {
    console.error('Missing event type or payload:', event)
    return
  }

  switch(eventType) {
    case 'update':
      //const update = JSON.parse(data.payload)
      //dispatch(updateTimelineQueue(timelineId, JSON.parse(data.payload), accept))
      break
    case 'delete_status':
      dispatch(timelineStatusDelete({ timelineId: 'home', statusId: payload.id}))
      dispatch(timelineStatusDelete({ timelineId: `account:${payload.account_id}`, statusId: payload.id}))
      dispatch(timelineStatusDelete({ timelineId: 'pro', statusId: payload.id}))
      dispatch(timelineStatusDelete({ timelineId: 'group_collection:member', statusId: payload.id}))
      break
    case 'notification':
      if (!payload) {
        console.log('Received invalid notification')
        return;
      }
      try {
        if (typeof payload === 'object' && payload.chat_conversation_id !== undefined) {
          dispatch(manageIncomingChatMessage(payload))
          return;
        }
      } catch (error) {
        // pass
        console.log('Failed to parse notification', payload)
      }
      dispatch(streamingNotification(payload))
      break
    case 'filters_changed':
      dispatch(fetchFilters())
      break
    case 'post_group':
      let sort;
      if (payload.group && payload.group.id) {
        if (window.location.pathname === `/groups/${payload.group.id}`) {
          sort = state.getIn(['timelines', `group:${payload.group.id}`, 'sortByValue'])
          if (!sort || sort == 'newest') {
            dispatch(importFetchedStatus(payload))
            setTimeout(() => { inject(`group:${payload.group.id}`, payload.id) }, 250)
          }
        }
        if (window.location.pathname === `/groups`) {
          sort = state.getIn(['timelines', 'group_collection:member', 'sortByValue'])
          if (!sort || sort == 'newest') {
            dispatch(importFetchedStatus(payload))
            setTimeout(() => { inject(`group_collection:member`, payload.id) }, 250)
          }
        }
        if (window.location.pathname === '/' || window.location.pathname === '/home') {
          sort = state.getIn(['timelines', 'home', 'sortByValue'])
          if (!sort || sort == 'with-groups') {
            if (payload.account_id !== me) {
              dispatch(importFetchedStatus(payload))
              setTimeout(() => { inject('home', payload.id) }, 250)
            }
          }
        }
      }
      break
    case 'for_you_status':
      if (window.location.pathname == '/' || window.location.pathname == '/home') {
        dispatch(importFetchedStatus(payload))
        setTimeout(() => { inject('for-you', payload.id) }, 250)
      }
      break
    case 'post_status':      
      if (payload.in_reply_to_id) {
        // think... atm this is disabled server side...
      } else {
        let sort;
        if (window.location.pathname === `/${payload.account.username}`) {
          sort = state.getIn(['timelines', `account:${payload.account_id}`, 'sortByValue'])
          if (!sort || sort == 'newest' || (sort == 'no-reposts' && !payload.reblog)) {
            dispatch(importFetchedStatus(payload))
            setTimeout(() => { inject(`account:${payload.account_id}`, payload.id) }, 250)
          }
        }
        if (window.location.pathname === '/' || window.location.pathname === '/home') {
          sort = state.getIn(['timelines', 'home', 'sortByValue'])
          if (!sort || sort == 'newest' || sort == 'with-groups' || (sort == 'no-reposts' && !payload.reblog)) {
            if (payload.account_id !== me) {
              dispatch(importFetchedStatus(payload))
              setTimeout(() => { inject('home', payload.id) }, 250)
            }
          }
        }
        if (payload.account.is_pro && window.location.pathname === '/timeline/pro') {
          sort = state.getIn(['timelines', 'pro', 'sortByValue'])
          if (sort == 'newest') {
            dispatch(importFetchedStatus(payload))
            setTimeout(() => { inject('pro', payload.id) }, 250)
          }
        }          
        if (payload.account.is_pro && payload.media_attachments) {
          if (window.location.pathname == '/timeline/photos') {
            let hasImage = payload.media_attachments.some(attachment => attachment.type === 'image')
            if (hasImage) {
              sort = state.getIn(['timelines', 'pro:photos', 'sortByValue'])
              if (sort == 'newest') {
                dispatch(importFetchedStatus(payload))
                setTimeout(() => { inject('pro:photos', payload.id) }, 250)
              }
            }
          }
          if (window.location.pathname == '/timeline/videos') {
            let hasVideo = payload.media_attachments.some(attachment => attachment.type === 'video')
            if (hasVideo) {
              sort = state.getIn(['timelines', 'pro:videos', 'sortByValue'])
              if (sort == 'newest') {
                dispatch(importFetchedStatus(payload))
                setTimeout(() => { inject('pro:videos', payload.id) }, 250)
              }
            }
          }            
        }
        if (payload.account.is_pro && payload.poll && window.location.pathname == '/timeline/polls') {
          sort = state.getIn(['timelines', 'polls', 'sortByValue'])
          if (!sort || sort == 'newest') {
            dispatch(importFetchedStatus(payload))
            setTimeout(() => { inject('polls', payload.id) }, 250)
          }
        }
      }
      break
    case 'edit_status':
      let existing = state.getIn(['statuses', payload.id])
      if (existing) {
        dispatch(importFetchedStatus(payload))
      }
      break
    case 'status_stat':
      let existing2 = state.getIn(['statuses', payload.status_id])
      if (existing2) {
        dispatch(updateStatusStats(payload))
      }
      break
  }
}

function inject(timeline, payload) {
  //if (window.scrollY < 100) {
  //  dispatch(timelinePrependItem(timeline, payload))
  //} else {
    dispatch(timelineQueue(timeline, payload))
  //}
}
