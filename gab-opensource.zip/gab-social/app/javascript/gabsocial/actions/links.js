import api, { getLinks } from '../api'

export const LINK_FETCH_REQUEST = 'LINK_FETCH_REQUEST'
export const LINK_FETCH_SUCCESS = 'LINK_FETCH_SUCCESS'
export const LINK_FETCH_FAIL = 'LINK_FETCH_FAIL'

export const POPULAR_LINKS_FETCH_REQUEST = 'POPULAR_LINKS_FETCH_REQUEST'
export const POPULAR_LINKS_FETCH_SUCCESS = 'POPULAR_LINKS_FETCH_SUCCESS'
export const POPULAR_LINKS_FETCH_FAIL = 'POPULAR_LINKS_FETCH_FAIL'

export const ENTITY_LINKS_FETCH_REQUEST = 'ENTITY_LINKS_FETCH_REQUEST'
export const ENTITY_LINKS_FETCH_SUCCESS = 'ENTITY_LINKS_FETCH_SUCCESS'
export const ENTITY_LINKS_FETCH_FAIL = 'ENTITY_LINKS_FETCH_FAIL'

export const IMPORT_LINK_CARDS = 'IMPORT_LINK_CARDS'

/**
 * 
 */
export const importLinkCards = (cards) => ({
  type: IMPORT_LINK_CARDS,
  cards,
})

/**
 * 
 */
export const fetchLinkCard = (cardId) => (dispatch, getState) => {
  //If card exists, don't refetch
  const card = getState().getIn(['links', 'items', `${cardId}`])
  if (!!card) return

  dispatch(fetchLinkCardRequest(cardId))

  api(getState).get(`/api/v1/links/${cardId}`).then(({ data }) => {
    dispatch(fetchLinkCardSuccess(data))
  })
  .catch((err) => dispatch(fetchLinkCardFail(err)))
}

export const fetchLinkCardRequest = (cardId) => ({
  type: LINK_FETCH_REQUEST,
  cardId,
})

export const fetchLinkCardSuccess = (card) => ({
  type: LINK_FETCH_SUCCESS,
  card,
})

export const fetchLinkCardFail = (error, cardId) => ({
  type: LINK_FETCH_FAIL,
  error,
  cardId,
})

/**
 * 
 */
export const fetchPopularLinks = () => (dispatch, getState) => {
  const isFetched = getState().getIn(['links', 'popular', 'isFetched'], false)
  if (isFetched) return

  dispatch(fetchPopularLinksRequest())

  api(getState).get(`/api/v1/popular_links?type=links`).then(({ data }) => {
    dispatch(fetchPopularLinksSuccess(data))
  })
  .catch((err) => dispatch(fetchPopularLinksFail(err)))
}

const fetchPopularLinksRequest = () => ({
  type: POPULAR_LINKS_FETCH_REQUEST,
})

const fetchPopularLinksSuccess = (cards) => ({
  type: POPULAR_LINKS_FETCH_SUCCESS,
  cards,
})

const fetchPopularLinksFail = (error) => ({
  type: POPULAR_LINKS_FETCH_FAIL,
  error,
})

export const fetchEntityLinks = (key, id, route) => (dispatch, getState) => {
  if (!key || !id) return

  const block = getState().getIn(['links', key, id])
  // check if has block and if it isnt already loading and no error
  if (!!block && (block.get('isLoading') || block.get('isError'))) return

  // check if initial load already occured and if we need to load more
  const next = !!block ? block.get('next') : null
  const isLoadingMore = !!next
  const url = next || `/api/v1/${route}/${id}/preview_cards`

  dispatch(fetchEntityLinksRequest(key, id, isLoadingMore))

  api(getState).get(url).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')
    dispatch(fetchEntityLinksSuccess(key, id, next ? next.uri : null, response.data, response.code === 206, isLoadingMore))
  }).catch((error) => {
    dispatch(fetchEntityLinksFail(key, id, error))
  })
}


const fetchEntityLinksRequest = (key, id, isLoadingMore) => ({
  type: ENTITY_LINKS_FETCH_REQUEST,
  key,
  id,
  isLoadingMore,
})

const fetchEntityLinksSuccess = (key, id, next, cards, partial, isLoadingRecent, isLoadingMore) => ({
  type: ENTITY_LINKS_FETCH_SUCCESS,
  key,
  id,
  next,
  cards,
  partial,
  isLoadingRecent,
  isLoadingMore,
})

const fetchEntityLinksFail = (key, id, error) => ({
  type: ENTITY_LINKS_FETCH_FAIL,
  key,
  id,
  error,
})

export const fetchGroupLinks = (id) => fetchEntityLinks('group', id, 'groups')
export const fetchChatConversationLinks = (id) => fetchEntityLinks('chat_conversation', id, 'chat_conversation')