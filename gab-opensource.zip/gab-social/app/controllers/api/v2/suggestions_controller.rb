# frozen_string_literal: true

class Api::V2::SuggestionsController < Api::BaseController
  include Authorization

  # before_action -> { doorkeeper_authorize! :read }

  def index
    type = params[:type]

    if not ['related', 'verified', 'groups', 'feeds', 'tags'].include?(type)
      raise GabSocial::NotPermittedError, %Q|Unknown Type "#{type}"|
    end

    if type == 'related' && !current_account.nil?
      count = truthy_param?(:unlimited) ? PotentialFriendshipTracker::MAX_ITEMS : 10
      accounts = PotentialFriendshipTracker.get(current_account.id, limit: count)
      accounts_json = accounts.map do |item|
        REST::AccountSerializer.new(item)
      end
      return render json: { accounts: accounts_json }
    elsif type == 'verified'
      accounts = VerifiedSuggestions.get()
      accounts_json = accounts.map do |item|
        REST::AccountSerializer.new(item)
      end
      return render json: { accounts: accounts_json }
    elsif type == 'groups' && !current_account.nil?
      groups = GroupSuggestions.get(current_account.id)
      groups_json = groups.map do |item|
        REST::GroupSerializer.new(item)
      end
      return render json: { groups: groups_json }
    elsif type == 'feeds' && !current_account.nil?
      lists = ListSuggestions.get(current_account.id)
      lists_json = lists.map do |item|
        REST::ListSerializer.new(item)
      end
      return render json: { lists: lists_json }
    elsif type == 'tags' && !current_account.nil?
      tags = TagSuggestions.get(current_account.id)
      tags_json = lists.map do |item|
        item.name
      end
      return render json: { tags: tags_json }
    end

    render json: {}, status: 404
  end

  def destroy
    type = params[:type]

    if current_account.nil?
      raise GabSocial::NotPermittedError, "Error. Not allowed"
    end
    if not ['related', 'verified', 'groups', 'feeds', 'tags'].include?(type)
      raise GabSocial::NotPermittedError, %Q|Unknown Type "#{type}"|
    end
    
    if type == 'related'
      PotentialFriendshipTracker.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'groups'
      GroupSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'feeds'
      ListSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'tags'
      TagSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    else
      render json: { error: true }, status: 422
    end
  end

end
