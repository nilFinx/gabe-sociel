# frozen_string_literal: true

class Api::V2::Timelines::VideoController < Api::BaseController
  before_action :set_sort_type

  after_action :insert_pagination_headers, unless: -> { @statuses.empty? }

  def show
    @statuses = load_statuses
    @statuses.reject { |status| status.proper.nil? }

    render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id),
           data: StatusDataPresenter.new(@statuses)
    filtered_statuses = @statuses.select { |s| s.attrs['was_pro'] == true }
    if !filtered_statuses.empty?
      StathouseStatWorker.perform_async('status', filtered_statuses.map(&:id).map(&:to_s), 'view', current_account ? current_account.id : nil)
    end
  end

  private

  def load_statuses
    ActiveRecord::Base.connected_to(role: :writing) do
      cache_collection videos, Status
    end
  end

  def videos
    theLimit = params[:max_id].nil? ? 20 : limit_param(DEFAULT_STATUSES_LIMIT)
    cacheKey = "video_feed:#{params[:media_type]}:#{@sort_type}:#{params[:max_id] || 1}:#{params[:since_id] || 1}:#{params[:min_id] || 1}:#{params[:page] || 0}:#{params[:only_following] || 0}"
    feed = nil
    if @sort_type != 'newest'
      feed = Rails.cache.fetch(cacheKey, expires_in: 10.minutes) do
        feed = video_feed.get(
          theLimit,
          params[:max_id],
          params[:since_id],
          params[:min_id],
          @sort_type,
          params[:page] || 1,
          params[:only_following] == '1',
          params[:media_type] == 'clips',
        )
      end
    else
      feed = video_feed.get(
        theLimit,
        params[:max_id],
        params[:since_id],
        params[:min_id],
        @sort_type,
        params[:page] || 1,
        params[:only_following] == '1',
        params[:media_type] == 'clips',
      )
    end
    feed
  end

  def video_feed
    VideoFeed.new(current_account)
  end

  def set_sort_type
    @sort_type = 'newest'
    @sort_type = 'top_today' if current_user.nil?
    @sort_type = params[:sort_by] if [
      'hot',
      'newest',
      'recent',
      'top_today',
      'top_weekly',
      'top_monthly',
      'top_yearly',
      'top_all_time',
    ].include? params[:sort_by]

    return @sort_type
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:media_type, :only_following).permit(:media_type, :only_following).merge(core_params)
  end

  def next_path
    api_v2_timelines_video_url pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v2_timelines_video_url pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end

end
