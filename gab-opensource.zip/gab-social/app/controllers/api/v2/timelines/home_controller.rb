# frozen_string_literal: true

class Api::V2::Timelines::HomeController < Api::BaseController

  before_action :require_user!, only: [:show]
  after_action :insert_pagination_headers, unless: -> { @statuses.empty? }

  include UserTrackingConcern
  include SessionTrackingConcern

  def show
    RemindExpiredAccountProWorker.perform_async('1', '2')

    @statuses = load_statuses

    render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id),
           data: StatusDataPresenter.new(@statuses)
    filtered_statuses = @statuses.select { |s| s.attrs['was_pro'] == true }
    if !filtered_statuses.empty?
      StathouseStatWorker.perform_async('status', filtered_statuses.map(&:id).map(&:to_s), 'view', current_account ? current_account.id : nil)
    end
  end

  private

  def load_statuses
    cached_home_statuses
  end

  def cached_home_statuses
    cache_collection home_statuses, Status
  end

  def home_statuses
    theLimit = params[:max_id].nil? ? 20 : limit_param(DEFAULT_STATUSES_LIMIT)
    account_home_feed.get(
      theLimit,
      params[:max_id],
      params[:since_id],
      params[:min_id],
      params[:sort_by_value],
      params[:page]
    )
  end

  def account_home_feed
    set_user_activity
    set_session_activity
    HomeFeed.new(current_account)
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:local, :limit).permit(:local, :limit).merge(core_params)
  end

  def next_path
    api_v2_timelines_home_url pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v2_timelines_home_url pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end

  def regeneration_in_progress?
    false
  end
end
