# frozen_string_literal: true

class Api::V2::Timelines::GroupCollectionController < Api::BaseController
  before_action :require_user!
  before_action :set_collection_type
  before_action :set_sort_type
  before_action :set_statuses

  after_action :insert_pagination_headers, if: -> { !@statuses.empty? && is_rising? }

  def show
    if current_account
      render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id),
           data: StatusDataPresenter.new(@statuses)
    else
      render json: [], 
        each_serializer: REST::StatusTimelineSerializer,
        data: StatusDataPresenter.new(@statuses)
    end
    filtered_statuses = @statuses.select { |s| s.attrs['was_pro'] == true }
    if !filtered_statuses.empty?
      StathouseStatWorker.perform_async('status', filtered_statuses.map(&:id).map(&:to_s), 'view', current_account ? current_account.id : nil)
    end
  end

  def set_collection_type
    @collection_type = nil
    @collection_type = params[:id] if ['featured', 'member'].include? params[:id]

    if @collection_type.nil?
      return render json: { error: 'Invalid collection type' }, status: 422
    end

    return @collection_type
  end

  private

  def set_sort_type
    @sort_type = 'newest'
    @sort_type = params[:sort_by] if [
      'hot',
      'rising',
      'newest',
      'recent',
      'top_today',
      'top_weekly',
      'top_monthly',
      'top_yearly',
      'top_all_time',
    ].include? params[:sort_by]

    if @collection_type === 'featured' && (@sort_type == 'newest' || @sort_type == 'recent')
      @sort_type = 'hot'
    end

    return @sort_type
  end

  def set_statuses
    @statuses = cached_group_collection_statuses
    @statuses = @statuses.reject { |status| status.proper.nil? }
  end

  def cached_group_collection_statuses
    ActiveRecord::Base.connected_to(role: :writing) do
      cache_collection group_collection_statuses, Status
    end
  end

  def group_collection_statuses
    page = if current_account
      params[:page]
    else
      [params[:page].to_i.abs, MIN_UNAUTHENTICATED_PAGES].min
    end

    @groupIds = []
    statuses = nil
    if @collection_type == 'featured'
      @groupIds = FetchGroupsService.new.call("featured")
    elsif @collection_type == 'member' && !current_account.nil?
      @groupIds = current_account.group_accounts.pluck(:group_id)
    end

    if is_rising?
      statuses = RisingQueryBuilder.new.call(
        limit_param(DEFAULT_STATUSES_LIMIT),
        params[:max_id],
        params[:since_id],
        @groupIds
      )
    else
      statuses = SortingQueryBuilder.new.deduped_with_cache(@sort_type, @groupIds, page, nil, { current_account: current_account })
    end

    if current_account
      statuses = statuses.reject {|status| FeedManager.instance.filter?(:home, status, current_account.id) }
    end

    statuses
  end

  def is_rising?
    @sort_type == 'rising'
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:limit).permit(:limit).merge(core_params)
  end

  def next_path
    api_v2_timelines_group_url params[:id], pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v2_timelines_group_url params[:id], pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end
end
