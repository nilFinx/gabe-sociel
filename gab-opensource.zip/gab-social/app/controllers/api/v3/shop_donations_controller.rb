class Api::V3::ShopDonationsController < Api::BaseController

  def index
    data = Rails.cache.fetch("shop_donations", expires_in: 5.minutes) do
      Request.new(:get, "https://shop.dissenter.com/product/group/donations/json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end