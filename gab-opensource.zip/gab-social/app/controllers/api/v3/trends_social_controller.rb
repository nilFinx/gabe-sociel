class Api::V3::TrendsSocialController < Api::BaseController

  def subscriptions
    if !current_account
      return render json: {error: "You must be logged in to use this."}, status: 401
    end
    data = Rails.cache.fetch("trends_social_subscriptions_#{current_account.id}", expires_in: 1.minutes) do
      Request.new(:get, "https://dissenter.com/gab-social-rss-feed/#{current_account.id}/subscriptions").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

  def subscribe
    if !current_account
        return render json: {error: "You must be logged in to use this."}, status: 401
    end
    feed_id = params[:feed_id]
    data = Rails.cache.fetch("trends_feed_#{feed_id}_#{current_account.id}_subscribe", expires_in: 1.minutes) do
      Request.new(:post, "https://dissenter.com/gab-social-rss-feed/#{feed_id}/subscribe", form: {
        "account_id" => current_account.id
      }).perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

  def unsubscribe
    if !current_account
        return render json: {error: "You must be logged in to use this."}, status: 401
    end
    feed_id = params[:feed_id]
    data = Rails.cache.fetch("trends_feed_#{feed_id}_#{current_account.id}_unsubscribe", expires_in: 1.minutes) do
      Request.new(:post, "https://dissenter.com/gab-social-rss-feed/#{feed_id}/unsubscribe", form: {
        "account_id" => current_account.id
      }).perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

  def new
    if !current_account
        return render json: {error: "You must be logged in to use this."}, status: 401
    end
    title = params[:title]
    url = params[:url]
    feedUrl = params[:feedUrl]
    params = ActionController::Parameters.new({
        title: title,
        url: url,
        feedUrl: feedUrl
    })
    params = params.permit(:title, :url, :feedUrl)
    Request.new(:post, "https://dissenter.com/gab-social-rss-feed/#{current_account.id}/new", form: params).perform do |res|
      data = JSON.parse(res.body)
    end
    return render json: data
  end


end