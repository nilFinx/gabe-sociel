class Api::V3::ShopSearchController < Api::BaseController

  def index
    fmt = "json"
    q = params[:q] || ""
    query = ActionController::Parameters.new({
        fmt: fmt,
        q: q
    })
    params = query.permit(:fmt, :q)
    query = params.to_query
    query_hash = Digest::MD5.hexdigest(query)

    data = Rails.cache.fetch("shop_search_#{query_hash}", expires_in: 5.minutes) do
      query_string = query ? "#{query}" : ""
      Request.new(:get, "https://shop.dissenter.com/search?#{query_string}").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end