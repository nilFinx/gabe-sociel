class Api::V3::TrendsCategoriesController < Api::BaseController

  def index
    data = Rails.cache.fetch("trends_categories", expires_in: 5.minutes) do
      Request.new(:get, "https://dissenter.com/feed/categories").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end