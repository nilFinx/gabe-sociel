class Api::V3::TrendsFeedController < Api::BaseController

  def index
    data = Rails.cache.fetch("trends_feed_root", expires_in: 1.day) do
      Request.new(:get, "https://dissenter.com/feed").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

  def show
    feed_id = params[:feed_id]
    fmt = "json"
    p = params[:p] || 1
    query = ActionController::Parameters.new({
        fmt: fmt,
        p: p
    })
    params = query.permit(:fmt, :p)
    query = params.to_query
    data = Rails.cache.fetch("trends_feed_#{feed_id}_#{p}", expires_in: 1.minutes) do
      Request.new(:get, "https://dissenter.com/feed/#{feed_id}?#{query}").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end