class Api::V3::TrendsHeadlineController < Api::BaseController

  def index
    data = Rails.cache.fetch("trends_headline", expires_in: 2.minutes) do
      Request.new(:get, "https://dissenter.com//partner/headline?fmt=json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end