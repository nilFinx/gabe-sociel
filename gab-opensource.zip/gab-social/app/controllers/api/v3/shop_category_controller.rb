class Api::V3::ShopCategoryController < Api::BaseController

  def index
    data = Rails.cache.fetch("shop_category", expires_in: 5.minutes) do
      Request.new(:get, "https://shop.dissenter.com/category?fmt=json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end