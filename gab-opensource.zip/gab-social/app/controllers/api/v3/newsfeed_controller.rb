class Api::V3::NewsfeedController < Api::BaseController

  def index
    data = Rails.cache.fetch("news_feed_json", expires_in: 1.minutes) do
      Request.new(:get, "https://news.gab.com/feed/json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end