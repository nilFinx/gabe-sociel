class Api::V3::ProPlansController < Api::BaseController

  def index
    data = Rails.cache.fetch("pro_plans", expires_in: 10.minutes) do
      Request.new(:get, "https://pro.gab.com/pro-plans/json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end