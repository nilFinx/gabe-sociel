class Api::V3::TrendsPopularController < Api::BaseController

  def index
    data = Rails.cache.fetch("trends_popular", expires_in: 5.minutes) do
      Request.new(:get, "https://dissenter.com/feed/categories/popular-items").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end