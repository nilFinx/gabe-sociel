# frozen_string_literal: true

class Api::V3::ChatbotMediaController < Api::BaseController

  def create
    error = { "result": "error" }
    return render json: error unless params[:token] && params[:file]
    chatbot = Chatbot.find_by(token: params[:token])
    return render json: error unless chatbot
    account = Account.find(chatbot.account_id)
    return render json: error unless account
    @media = account
      .media_attachments
      .create!(
        account: account,
        file: media_params[:file],
        description: media_params[:description],
      )
    render json: @media, serializer: REST::MediaAttachmentSerializer
  end

  private

  def media_params
    params.permit(:file, :description)
  end
end
