# frozen_string_literal: true

class Api::V3::ChatbotReplyController < Api::BaseController

  def create
    error = { "result": "error" }
    return render json: error unless params[:token] && params[:conversation_id] && (params[:text] || params[:media_ids])
    chatbot = Chatbot.find_by(token: params[:token])
    return render json: error unless chatbot
    begin
      chatbot.reply_message(params[:conversation_id], params[:text], params[:media_ids])
      success = { "result": "success" }
      render json: success
    rescue => e
      Rails.logger.error "Error replying for #{chatbot.name}: #{e}"
      chatbot.reply_message(params[:conversation_id], 'Error encountered, please try again later.')
      render json: error
    end
  end

end
