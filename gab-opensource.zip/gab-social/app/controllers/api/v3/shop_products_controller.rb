class Api::V3::ShopProductsController < Api::BaseController

  def index
    data = Rails.cache.fetch("shop_products", expires_in: 5.minutes) do
      Request.new(:get, "https://shop.dissenter.com/product/group/json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end