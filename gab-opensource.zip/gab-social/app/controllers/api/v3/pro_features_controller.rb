class Api::V3::ProFeaturesController < Api::BaseController

  def index
    data = Rails.cache.fetch("pro_features", expires_in: 10.minutes) do
      Request.new(:get, "https://pro.gab.com/features/json").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end