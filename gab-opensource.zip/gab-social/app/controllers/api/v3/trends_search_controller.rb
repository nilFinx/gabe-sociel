class Api::V3::TrendsSearchController < Api::BaseController

  def index
    fmt = "json"
    cpp = params[:cpp] || 30
    q = params[:q] || ""
    p = params[:p] || 1
    query = ActionController::Parameters.new({
        fmt: fmt,
        cpp: cpp,
        q: q,
        p: p
    })
    params = query.permit(:fmt, :cpp, :q, :p)
    query = params.to_query
    query_hash = Digest::MD5.hexdigest(query)

    data = Rails.cache.fetch("trends_search_#{query_hash}", expires_in: 1.minutes) do
      query_string = query ? "?#{query}" : ""
      Request.new(:get, "https://dissenter.com/search/rss?#{query_string}").perform do |res|
        JSON.parse(res.body)
      end
    end
    return render json: data
  end

end