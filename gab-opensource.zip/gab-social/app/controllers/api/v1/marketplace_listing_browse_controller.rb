# frozen_string_literal: true

class Api::V1::MarketplaceListingBrowseController < Api::BaseController
  
  def index
    @listings = load_listings
    render json: @listings
  end

  private

  def load_listings
    excluded_category_ids = parse_exclude_categories(params[:ec])
    categories = fetch_random_categories(excluded_category_ids)

    results = categories.map do |category|
      category_listings = fetch_unique_listings_for_category(category.id)
      serialized_catgory_listings = category_listings.map do |listing|
        REST::MarketplaceListingSerializer.new(listing) 
      end

      # Extract ids
      category_listings_ids = category_listings.map(&:id).map(&:to_s)
      if category_listings_ids.any?
        StathouseStatWorker.perform_async('marketplace_listing', category_listings_ids, 'view', current_account ? current_account.id : nil)
      end

      {
        category: category,
        listings: serialized_catgory_listings
      }
    end

    most_recent = fetch_most_recent_deduped_listings
    serialized_most_recent = most_recent.map do |listing|
      REST::MarketplaceListingSerializer.new(listing)
    end

    # Extract ids
    most_recent_ids = most_recent.map(&:id).map(&:to_s)
    if most_recent_ids.any?
      StathouseStatWorker.perform_async('marketplace_listing', most_recent_ids, 'view', current_account ? current_account.id : nil)
    end
    
    {
      categories: results,
      recent: serialized_most_recent
    }
end
  
  private
  
  def parse_exclude_categories(exclude_param)
    return [] unless exclude_param.present?
    exclude_param.split(',').map(&:to_i)
  end
  
  def fetch_random_categories(exclusions = [])
    limit = params[:ec].present? ? 5 : 3
    MarketplaceListingCategory.where.not(id: exclusions).order('RANDOM()').limit(limit)
  end
  
  def fetch_unique_listings_for_category(category_id)
    sql = <<-SQL
      SELECT m.*
      FROM marketplace_listings m
      JOIN (
        SELECT account_id, MAX(id) AS max_id
        FROM marketplace_listings
        WHERE marketplace_listing_category_id = #{category_id} AND status = 4
        GROUP BY account_id
        ORDER BY MAX(id) DESC
        LIMIT 5
      ) subq ON m.account_id = subq.account_id AND m.id = subq.max_id
      WHERE m.status = 4
      ORDER BY m.id DESC;
    SQL

    MarketplaceListing.find_by_sql(sql)
  end
  
  def fetch_most_recent_deduped_listings
    return [] if params[:ec].present?

    sql = <<-SQL
      SELECT m.*
      FROM marketplace_listings m
      JOIN (
        SELECT account_id, MAX(id) AS max_id
        FROM marketplace_listings
        WHERE status = 4
        GROUP BY account_id
        ORDER BY MAX(id) DESC
        LIMIT 5
      ) subq ON m.account_id = subq.account_id AND m.id = subq.max_id
      WHERE m.status = 4
      ORDER BY m.id DESC;
    SQL
  
    MarketplaceListing.find_by_sql(sql)
  end

end
