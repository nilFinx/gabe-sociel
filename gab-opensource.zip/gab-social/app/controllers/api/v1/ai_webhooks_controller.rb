# frozen_string_literal: true

class Api::V1::AiWebhooksController < Api::BaseController
  before_action :verify_auth_header

  def on_sign_up
    email = params[:email].to_s.downcase
    
    # Find the account by email
    account = Account.find_by(email: email)

    if account
      account.update(attrs: account.attrs.merge('has_ai_acct' => true))

      render status: 202
    else
      render status: 404
    end
  end

  private

  def verify_auth_header
    auth_key = request.headers['X-GAB-AI-WEBHOOK-KEY']
    expected_key = ENV['GAB_AI_WEBHOOK_KEY']

    unless auth_key.present? && auth_key == expected_key
      render json: { error: 'Unauthorized' }, status: :unauthorized
    end
  end
  
end
