# frozen_string_literal: true

class Api::V1::MarketplaceListingSearchController < Api::BaseController

  after_action :insert_pagination_headers

  def index
    @marketplace_listings = marketplace_listing_search
    
    # Extract listing_ids from the @marketplace_listings collection
    listing_ids = @marketplace_listings.map(&:id).map(&:to_s)
    if listing_ids.any?
      StathouseStatWorker.perform_async('marketplace_listing', listing_ids, 'view', current_account ? current_account.id : nil)
    end

    render json: @marketplace_listings, each_serializer: REST::MarketplaceListingSerializer
  end

  private

  def insert_pagination_headers
    links = []
    links << [next_path, [%w(rel next)]]
    response.headers['Link'] = LinkHeader.new(links) unless links.empty?
  end

  def next_path
    if records_continue?
      api_v1_marketplace_listing_search_index_url pagination_params(page: next_page)
    end
  end

  def records_continue?
    @marketplace_listings.size == limit_param(DEFAULT_MARKETPLACE_LISTINGS_LIMIT)
  end

  def next_page
    page = params[:page]
    if !page.nil?
      page = page.to_i + 1
    else
      page = 2
    end
    page
  end

  def pagination_params(core_params)
    permitted_keys = [:query, :category_id, :category_slug, :account_id, :location, :price_min, :price_max, :condition, :sort_by, :page, :business_id] + 
                  MarketplaceListingAttributes::UNIQUE_KEYS[:attrs].map(&:to_sym)

    params.slice(*permitted_keys)
          .permit(*permitted_keys)
          .merge(core_params)
  end

  def marketplace_listing_search
    permitted_keys = [:query, :category_id, :category_slug, :account_id, :location, :price_min, :price_max, :condition, :sort_by, :page, :id, :business_id] + 
    MarketplaceListingAttributes::UNIQUE_KEYS[:attrs].map(&:to_sym)

    MarketplaceListingSearchService.new.call(
      current_account,
      DEFAULT_MARKETPLACE_LISTINGS_LIMIT,
      **params.slice(*permitted_keys).permit(*permitted_keys).to_h.symbolize_keys
    )
  end

  def search_params
    permitted_keys = [:query, :category_id, :category_slug, :account_id, :location, :price_min, :price_max, :condition, :sort_by, :page, :business_id] + 
    MarketplaceListingAttributes::UNIQUE_KEYS[:attrs].map(&:to_sym)

    params.permit(*permitted_keys)
  end

end
