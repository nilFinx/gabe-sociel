# frozen_string_literal: true

class Api::V1::MarketplaceListingCategoriesController < EmptyController

  def index
    data = Rails.cache.fetch("v1_marketplace_listing_categories", expires_in: 15.minutes) do
      MarketplaceListingCategory.alphabetical.all.map { |mlc| REST::MarketplaceListingCategorySerializer.new(mlc) }
    end
    render json: data.to_json, content_type: 'application/json'
  end

end
