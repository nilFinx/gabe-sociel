# frozen_string_literal: true

class Api::V1::Groups::RemovedAccountsController < Api::BaseController
  include Authorization

  before_action -> { doorkeeper_authorize! :write, :'write:groups' }

  before_action :require_user!
  before_action :set_group

  after_action :insert_pagination_headers, only: :show

  def show
    authorize @group, :allow_if_is_group_admin_or_moderator?

    @accounts = load_accounts
    render json: @accounts, each_serializer: REST::AccountSerializer
  end

  def create
    authorize @group, :allow_if_is_group_admin_or_moderator?

    current_group_account = @group.group_accounts.where(account: current_account.id).first
    action_account = Account.find(params[:account_id])

    # Do not allow anything to happen to group owners/creators
    if @group.account_id.to_s == action_account.id.to_s
      return render json: { error: 'Unable to remove account.' }, status: 422
    end
    
    # do not allow if is moderator or admin and current user is not admin
    acct = @group.group_accounts.where(account_id: params[:account_id]).first
    if !acct.nil? && (acct.role == 'admin' || acct.role == 'moderator') && !current_group_account.nil? && current_group_account.role != 'admin'
      return render json: { error: 'You cannot remove an admin or moderator. Only admins can do that' }, status: 422
    end

    begin
      @account = Account.find(params[:account_id])
      @group.removed_accounts << @account
      GroupAccount.where(group: @group, account: @account).destroy_all
    rescue => e
      Rails.logger.error "Exception in removed_accounts_controller#create. #{e.class}: #{e.message}"
      # Succeed anyway
    end
    render_empty_success
  end

  def destroy
    authorize @group, :allow_if_is_group_admin_or_moderator?

    begin
      @account = @group.removed_accounts.find(params[:account_id])
      GroupRemovedAccount.where(group: @group, account: @account).destroy_all
    rescue => e
      Rails.logger.error "Exception in removed_accounts_controller#destroy. #{e.class}: #{e.message}"
      # Succeed anyway
    end
    render_empty_success
  end

  private

  def set_group
    @group = Group.find(params[:group_id])
  end

  def load_accounts
    if unlimited?
      @group.removed_accounts.includes(:account_stat).all
    else
      @group.removed_accounts.includes(:account_stat).paginate_by_max_id(limit_param(DEFAULT_ACCOUNTS_LIMIT), params[:max_id], params[:since_id])
    end
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    return if unlimited?

    if records_continue?
      api_v1_group_removed_accounts_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    return if unlimited?

    unless @accounts.empty?
      api_v1_group_removed_accounts_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @accounts.last.id
  end

  def pagination_since_id
    @accounts.first.id
  end

  def records_continue?
    @accounts.size == limit_param(DEFAULT_ACCOUNTS_LIMIT)
  end

  def pagination_params(core_params)
    params.slice(:limit).permit(:limit).merge(core_params)
  end

  def unlimited?
    params[:limit] == '0'
  end
end
