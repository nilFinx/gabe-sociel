# frozen_string_literal: true

class Api::V1::Groups::AdminsController < Api::BaseController
  include Authorization

  before_action -> { doorkeeper_authorize! :read, :'read:groups' }, only: [:show]
  before_action -> { doorkeeper_authorize! :write, :'write:groups' }, except: [:show]

  before_action :require_user!
  before_action :set_group

  def show
    final = load_json_data
    return render json: final
  end

  private

  def set_group
    @group = Group.find(params[:group_id])
  end

  def load_json_data
    authorize @group, :admins_visible?

    group_accounts = @group.group_accounts.where(role: [:admin, :moderator]).all
    
    accounts = []
    roles = {}
    
    accounts = group_accounts.map do |ga|
      REST::AccountSerializer.new(ga.account)
    end

    group_accounts.each do |ga|
      roles[ga.account_id.to_s] = ga.role
    end

    final = {}
    if !group_accounts.empty?
      final['group_id'] = @group.id.to_s
      final['accounts'] = accounts
      final['roles'] = roles
    end

    return final
  end
end
