# frozen_string_literal: true

class Api::V1::Groups::MediaAttachmentsController < Api::BaseController
  before_action :set_group
  after_action :insert_pagination_headers

  def index
    if @group.nil? || !@group.is_media_visible?
      return render json: { "error": true }, status: 422
    end
    @media_attachments = load_media

    statusIds = []
    medias = []

    @media_attachments.each do |media|
      medias << REST::MediaAttachmentSerializer.new(media)
      s = media.status_id
      statusIds << s if !statusIds.include?(s)
    end

    statuses = []
    statuses = Status.where(id: statusIds) if !statusIds.empty?
    statuses_s = statuses.map do |status|
      # V2:
      # REST::StatusSerializer.new(status, { exclude_media: true, exclude_account: true })
      REST::StatusSerializer.new(status)
    end

    final = {}
    if !medias.empty?
      final['group'] = REST::GroupSerializer.new(@group)
      final['media_attachments'] = medias
      final['statuses'] = statuses_s if !statuses_s.empty?
    end

    return render json: final
  end

  private

  def set_group
    @group = Group.find(params[:group_id])
  end

  def load_media
    # don't show anything if no user and group is private or not visible
    return [] if current_account.nil?
    return [] if !@group.is_visible
    # don't show anything if group is private and user not a member
    return [] if @group.is_private && !@group.group_accounts.where(account_id: current_account.id).exists?

    scope = MediaAttachment.recent.excluding_scheduled.attached_to_group_top_level_status(@group.id)
    scope = scope.logged_out_limited if current_account.nil?
    scope = scope.not_pro_limited if current_account && !current_account.is_pro?

    if !query_params[:type].nil? && !query_params[:type].empty?
      if query_params[:type] == 'image' || query_params[:type] == 'video' || query_params[:type] == 'gifv'
        scope = scope.where(type: query_params[:type])
      else
        return render json: { "error": true }, status: 422
      end
    end

    scope = scope.paginate_by_max_id(
      limit_param(DEFAULT_MEDIA_ATTACHMENTS_LIMIT),
      params[:max_id],
      params[:since_id]
    )

    scope
  end
  
  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    if records_continue?
      api_v1_group_media_attachments_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    unless @media_attachments.empty?
      api_v1_group_media_attachments_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @media_attachments.last.id
  end

  def pagination_since_id
    @media_attachments.first.id
  end

  def records_continue?
    @media_attachments.size == limit_param(DEFAULT_MEDIA_ATTACHMENTS_LIMIT)
  end

  def pagination_params(core_params)
    params
      .slice(:limit, :type)
      .permit(:limit, :type)
      .merge(core_params)
  end

  def query_params
    params.permit(:type)
  end
end
