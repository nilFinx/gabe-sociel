# frozen_string_literal: true
include RoutingHelper
class Api::V1::MediaController < Api::BaseController
  before_action -> { doorkeeper_authorize! :write, :'write:media' }
  before_action :require_user!

  def create
    
    if !current_account.is_pro? && media_params[:file].size > 50.megabytes
      Rails.logger.warn "MediaController: Non-pro user exceeded file size limit"
      return render json: { error: 'non pro limit' }, status: 441
    end
    
    if !current_account.is_pro? && current_account.media_attachments.where('created_at > ?', Time.zone.now.beginning_of_day).sum(:file_file_size) > 50.megabytes
      Rails.logger.warn "MediaController: Non-pro user exceeded daily upload limit"
      return render json: { error: 'non pro limit' }, status: 442
    end
    @media = current_account
      .media_attachments
      .create!(
        account: current_account,
        file: media_params[:file],
        description: media_params[:description]
      )
    @media.update(cdn_url: bunny_url_by_object(@media, @media.file, "file"), small_cdn_url: bunny_url_by_object(@media, @media.file, "small"))
    render json: @media, serializer: REST::MediaAttachmentSerializer
  rescue Paperclip::Errors::StorageMethodNotFound => err
    Rails.logger.error "Paperclip::Errors::StorageMethodNotFound: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'storage error' }, status: 500
  rescue Paperclip::Errors::CommandNotFoundError => err
    Rails.logger.error "Paperclip::Errors::CommandNotFoundError: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'command error' }, status: 500
  rescue Paperclip::Errors::MissingRequiredValidatorError => err
    Rails.logger.error "Paperclip::Errors::MissingRequiredValidatorError: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'content type or file name error' }, status: 422
  rescue Paperclip::Errors::NotIdentifiedByImageMagickError => err
    Rails.logger.error "Paperclip::Errors::NotIdentifiedByImageMagickError: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'metadata error' }, status: 422
  rescue Paperclip::Errors::InfiniteInterpolationError => err
    Rails.logger.error "Paperclip::Errors::InfiniteInterpolationError: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'interpolation error' }, status: 500
  rescue Paperclip::Error => err
    Rails.logger.error "Paperclip::Error: #{err.message}\n#{err.backtrace.join("\n")}"
    render json: { error: 'server error 1' }, status: 500
  rescue StandardError => err
    Rails.logger.error "Media attach other error: #{err.message}"
    Rails.logger.error "err.class: #{err.class}"
    Rails.logger.error "err.to_json: #{err.to_json}"
    Rails.logger.error "Backtrace: #{err.backtrace.join("\n")}"
    if err.to_s.include?('Validation failed')
      render json: { error: 'format error' }, status: 400
    else
      render json: { error: 'server error 2' }, status: 500
    end
  end

  def update
    Rails.logger.info "MediaController: Starting media update process"
    
    target_media = nil
    @pending_media = current_account.pending_media_attachments.find_by(id: params[:id])
    @media = current_account.media_attachments.find_by(id: params[:id])
    
    if @pending_media.nil?
      if !@media.nil?
        target_media = @media
        Rails.logger.info "MediaController: Updating existing media attachment"
        @media.update!(media_params)
        render json: target_media, serializer: REST::MediaAttachmentSerializer
      end
    else
      target_media = @pending_media
      Rails.logger.info "MediaController: Updating pending media attachment"
      @pending_media.update!(media_params)
      render json: target_media, serializer: REST::PendingMediaAttachmentSerializer
    end
    
    if target_media.nil?    
      Rails.logger.warn "MediaController: Media not found for update"
      render json: { error: 'media not found' }, status: 404
    end
  rescue StandardError => err
    Rails.logger.error "Media update error: #{err.message}"
    Rails.logger.error "err.class: #{err.class}"
    Rails.logger.error "err.to_json: #{err.to_json}"
    Rails.logger.error "Backtrace: #{err.backtrace.join("\n")}"
    render json: { error: 'server error' }, status: 500
  end

  private

  def media_params
    params.permit(:file, :description, :focus)
  end
end
