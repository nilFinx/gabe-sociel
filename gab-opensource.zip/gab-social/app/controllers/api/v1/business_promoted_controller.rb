# frozen_string_literal: true

class Api::V1::BusinessPromotedController < Api::BaseController

  include Redisable

  # redis example
  # redis.with do |conn|
  #   conn.get()
  # end

  def index
    records = load_businesses_or_listings
    if records.first.is_a?(Business)
      render json: records, each_serializer: REST::BusinessSerializer
    
      # Extract ids
      business_ids = records.map(&:id).map(&:to_s)
      if business_ids.any?
        StathouseStatWorker.perform_async('business', business_ids, 'view', current_account ? current_account.id : nil)
      end
    else
      render json: records, each_serializer: REST::MarketplaceListingSerializer

      # Extract ids 
      listing_ids = records.map(&:id).map(&:to_s)
      if listing_ids.any?
        StathouseStatWorker.perform_async('marketplace_listing', listing_ids, 'view', current_account ? current_account.id : nil)
      end
    end
  end

  private

  def load_businesses_or_listings
    category = params[:category] if params[:category].present? 
    promotion_ids = params[:promotion].map(&:to_i) if params[:promotion].present?

    # If specific promotion IDs are present, find and return their listings
    if promotion_ids && (promotion_ids & [2, 100, 101, 102, 103]).any?
      business_ids_with_specific_promotions = Business.where("promotions @> ARRAY[?]::integer[]", promotion_ids).order('RANDOM()').pluck(:id)
      return MarketplaceListing.only_running.visible_in_injections.where(business_id: business_ids_with_specific_promotions).order('RANDOM()').limit(12)
    end
    
    # : todo : 
    # check pro here

    # Otherwise, return businesses
    businesses = promotion_ids ? Business.is_approved.where("promotions @> ARRAY[?]::integer[]", promotion_ids).order('RANDOM()').limit(12) : Business.none
    if !category.nil?
      # Assuming you have a business_category_id
      category_ids = BusinessCategory.find_category_and_descendants(category)
      category_ids_as_strings = category_ids.map(&:to_s)

      # Now, find businesses that have these category IDs in their categories array
      businesses = businesses.where("categories && ARRAY[?]::varchar[]", category_ids_as_strings)
    end

    return businesses
  end  
end
