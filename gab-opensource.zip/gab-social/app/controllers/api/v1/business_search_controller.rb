# frozen_string_literal: true

class Api::V1::BusinessSearchController < Api::BaseController

  after_action :insert_pagination_headers

  def index
    @businesses = business_search
    
    # Extract ids from the @businesses collection
    business_ids = @businesses.map(&:id).map(&:to_s)
    if business_ids.any?
      StathouseStatWorker.perform_async('business', business_ids, 'view', current_account ? current_account.id : nil)
    end

    render json: @businesses, each_serializer: REST::BusinessSerializer
  end

  private

  def insert_pagination_headers
    links = []
    links << [next_path, [%w(rel next)]]
    response.headers['Link'] = LinkHeader.new(links) unless links.empty?
  end

  def next_path
    if records_continue?
      api_v1_business_search_index_url pagination_params(page: next_page)
    end
  end

  def records_continue?
    @businesses.size == limit_param(DEFAULT_MARKETPLACE_LISTINGS_LIMIT)
  end

  def next_page
    page = params[:page]
    if !page.nil?
      page = page.to_i + 1
    else
      page = 2
    end
    page
  end

  def pagination_params(core_params)
    permitted_keys = [:query, :category_id, :category_slug, :page]
    params.slice(*permitted_keys)
          .permit(*permitted_keys)
          .merge(core_params)
  end

  def business_search
    permitted_keys = [:query, :category_id, :category_slug, :page]

    BusinessSearchService.new.call(
      current_account,
      DEFAULT_MARKETPLACE_LISTINGS_LIMIT,
      **params.slice(*permitted_keys).permit(*permitted_keys).to_h.symbolize_keys
    )
  end

  def search_params
    permitted_keys = [:query, :category_id, :category_slug, :page]
    params.permit(*permitted_keys)
  end

end
