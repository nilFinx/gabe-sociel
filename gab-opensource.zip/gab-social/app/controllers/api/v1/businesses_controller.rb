# frozen_string_literal: true

class Api::V1::BusinessesController < Api::BaseController
  include Authorization

  before_action :require_user!, except: [:show]
  before_action :set_business, only: [:update, :show, :destroy, :update_coupons, :update_hours]
  before_action :ensure_ownership!, only: [:update, :destroy, :update_coupons, :update_hours]

  def index
    managed_and_owned_businesses = current_account.managed_businesses + current_account.owned_businesses
    @unique_businesses = managed_and_owned_businesses.uniq { |business| business.id }
  
    # Fetching BusinessAccounts associated with the current account
    @business_accounts = current_account.business_accounts.includes(:business)

    serialized_businesses = @unique_businesses.map do |business|
      REST::BusinessSerializer.new(business)
    end
    serialized_business_accounts = @business_accounts.map do |business_account|
      REST::BusinessAccountSerializer.new(business_account)
    end

    # : todo :
    # if listing_ids.any?
    #   StathouseStatWorker.perform_async('marketplace_listing', listing_ids, 'view', current_account ? current_account.id : nil)
    # end

    # Preparing the response
    response = {
      businesses: serialized_businesses,
      business_accounts: serialized_business_accounts
    }
    render json: response
  end

  def show
    authorize @business, :show?
    render json: @business, serializer: REST::BusinessSerializer
    StathouseStatWorker.perform_async('business', @business.id.to_s, 'view', current_account ? current_account.id : nil)
  end

  def destroy
    authorize @business, :destroy?
    # 
  end

  def update
    authorize @business, :update?

    # Prepare the business_params
    prepared_params = business_params

    # Merge cta attributes if they are present
    if cta_params.present?
      current_cta = @business.cta || {}
      updated_cta = current_cta.merge({
        'title' => cta_params[:cta_title],
        'link' => cta_params[:cta_link]
      }).compact # Remove nil values

      prepared_params[:cta] = updated_cta
    end

    @business.update(prepared_params)

    if params[:account_hidden].present?
      businessAccount = BusinessAccount.where(account_id: @business.account.id, business_id: @business.id).first
      if !businessAccount.nil?
        new_v = params[:account_hidden] == "false" ? 1 : 0
        businessAccount.update(visibility: new_v)
      end
    else 
      # 
    end

    render json: @business, serializer: REST::BusinessSerializer
  end

  def create
    @business = Business.create!(business_params.merge(account: current_account))
    render json: @business, serializer: REST::BusinessSerializer
  end

  def update_hours
    new_hours = params[:hours]
    is247 = params[:is247]
  
    if is247
      # [0] we use as 24/7
      if @business.update(hours: [0])
        render json: @business, serializer: REST::BusinessSerializer
      else
        render json: @business.errors, status: :unprocessable_entity
      end
    else
      mon_open = new_hours[:mon][:o]
      mon_close = new_hours[:mon][:c]

      if !validate_time_format(mon_open) || !validate_time_format(mon_close)
        render json: { error: 'Invalid hours format (Monday)' }, status: :unprocessable_entity
      end

      tue_open = new_hours[:tue][:o]
      tue_close = new_hours[:tue][:c]
      if !validate_time_format(tue_open) || !validate_time_format(tue_close)
        render json: { error: 'Invalid hours format (Tuesday)' }, status: :unprocessable_entity
      end

      wed_open = new_hours[:wed][:o]
      wed_close = new_hours[:wed][:c]
      if !validate_time_format(wed_open) || !validate_time_format(wed_close)
        render json: { error: 'Invalid hours format (Wednesday)' }, status: :unprocessable_entity
      end

      thur_open = new_hours[:thur][:o]
      thur_close = new_hours[:thur][:c]
      if !validate_time_format(thur_open) || !validate_time_format(thur_close)
        render json: { error: 'Invalid hours format (Thursday)' }, status: :unprocessable_entity
      end

      fri_open = new_hours[:fri][:o]
      fri_close = new_hours[:fri][:c]
      if !validate_time_format(fri_open) || !validate_time_format(fri_close)
        render json: { error: 'Invalid hours format (Friday)' }, status: :unprocessable_entity
      end

      sat_open = new_hours[:sat][:o]
      sat_close = new_hours[:sat][:c]
      if !validate_time_format(sat_open) || !validate_time_format(sat_close)
        render json: { error: 'Invalid hours format (Saturday)' }, status: :unprocessable_entity
      end

      sun_open = new_hours[:sun][:o]
      sun_close = new_hours[:sun][:c]
      if !validate_time_format(sun_open) || !validate_time_format(sun_close)
        render json: { error: 'Invalid hours format (Sunday)' }, status: :unprocessable_entity
      end

      final_hours = {
        mon: {
          o: mon_open,
          c: mon_close,
        },
        tue: {
          o: tue_open,
          c: tue_close,
        },
        wed: {
          o: wed_open,
          c: wed_close,
        },
        thur: {
          o: thur_open,
          c: thur_close,
        },
        fri: {
          o: fri_open,
          c: fri_close,
        },
        sat: {
          o: sat_open,
          c: sat_close,
        },
        sun: {
          o: sun_open,
          c: sun_close,
        },
      }

      if @business.update(hours: final_hours)
        render json: @business, serializer: REST::BusinessSerializer
      else
        render json: @business.errors, status: :unprocessable_entity
      end
    end
  end

  def update_coupons
    new_coupons = valid_coupons
  
    if new_coupons && new_coupons.is_a?(Array) && new_coupons.length > 0
      if @business.update(coupons: new_coupons)
        render json: @business, serializer: REST::BusinessSerializer
      else
        render json: @business.errors, status: :unprocessable_entity
      end
    else
      if @business.update(coupons: nil)
        render json: @business, serializer: REST::BusinessSerializer
      else
        render json: @business.errors, status: :unprocessable_entity
      end
    end
  end

  private
  
  def ensure_ownership!
    # : todo : use BusinessAccount
    if @business.account.id == current_account.id
      true
    else
      render json: { error: 'Unauthorized' }, status: 501
    end
  end

  def set_business
    @business = Business.includes(:account).find(params[:id])
    # important!
    authorize @business, :show?
  end

  def cta_params
    params.permit(:cta_title, :cta_link)
  end

  def business_params
    thep = params.permit(
      :name,
      :tagline,
      :avatar,
      :cover,
      :description,
      :websites,
      :phone_number,
      :locations,
      :categories,
    )

    if !thep[:locations].nil?
      thep[:locations] = JSON.parse(thep[:locations])
    end
    
    if !thep[:categories].nil?
      thep[:categories] = JSON.parse(thep[:categories])
    end

    thep[:avatar] = nil if thep[:avatar] == 'undefined'
    thep[:cover] = nil if thep[:cover] == 'undefined'

    # Split the websites string into an array
    thep[:websites] = thep[:websites].split(',') if thep[:websites].present?

    thep
  end

  # hours

  def validate_time_format(time_str)
    pattern = /^\d{2}:\d{2}$/
  
    if time_str.match?(pattern)
      # "Valid format"
      return true
    else
      # "Error: Invalid format"
      return false
    end
  end

  def coupons_params
    params.permit(:coupons)
  end

  def valid_coupons
    # Ensure the coupons are in a format that can be worked with
    coupons = params[:coupons]
    new_coupons = []
    coupons.each do |coupon|
      if valid_coupon_type?(coupon['type']) && valid_coupon_code?(coupon['code']) && valid_coupon_amount?(coupon['type'], coupon['amount'])
        new_coupons.append({
          type: coupon['type'],
          code: coupon['code'],
          amount: coupon['amount'],
        })
      end
    end
    return new_coupons
  end
  
  def valid_coupon_type?(type)
    ['Free Shipping', 'Coupon', 'Discount'].include?(type)
  end

  def valid_coupon_code?(code)
    code.present?
  end

  def valid_coupon_amount?(type, amount)
    return true if type == 'Free Shipping'
    amount.present?
  end

end
