# frozen_string_literal: true

class Api::V1::PromotionsController < EmptyController

  def index
    data = Rails.cache.fetch("v1_promotions", expires_in: 15.minutes) do
      Promotion.active.map { |p| REST::PromotionSerializer.new(p) }
    end
    render json: data.to_json, content_type: 'application/json'
  end

end
