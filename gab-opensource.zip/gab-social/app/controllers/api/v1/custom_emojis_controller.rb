# frozen_string_literal: true

class Api::V1::CustomEmojisController < EmptyController
  include Redisable

  def index
    data = nil
    redis.with do |conn|
      data = conn.get("v1_custom_emojis_controller")
      if data.blank?
        data = []
        CustomEmoji.local.each do |ce|
          data << REST::CustomEmojiSerializer.new(ce)
        end
        conn.setex("v1_custom_emojis_controller", 15.minutes, data.to_json)
      else
        data = JSON.parse(data)
      end
    end
    render json: data.to_json, content_type: 'application/json'
  end

end
