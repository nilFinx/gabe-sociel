# frozen_string_literal: true

class Api::V1::Timelines::RelatedController < Api::BaseController

  after_action :insert_pagination_headers, unless: -> { @statuses.empty? }

  def show
    @status_id = resource_params[:id]
    @related_status = Status.find(@status_id)
    @group_id = @related_status.group_id
    @max_id = resource_params[:max_id]
    @statuses = load_statuses
    render json: @statuses, 
      each_serializer: REST::StatusSerializer, 
      relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id)
    filtered_statuses = @statuses.select { |s| s.attrs['was_pro'] == true }
    if !filtered_statuses.empty?
      StathouseStatWorker.perform_async('status', filtered_statuses.map(&:id).map(&:to_s), 'view', current_account ? current_account.id : nil)
    end  
  end

  private

  def load_statuses
    ActiveRecord::Base.connected_to(role: :writing) do
      cache_collection related_statuses, Status
    end
  end

  def related_statuses    
    limit = 20

    since = GabSocial::Snowflake.id_at(1.month.ago)
    if @group_id.nil?
      since = GabSocial::Snowflake.id_at(2.weeks.ago)
    end
    
    base_query = Status.popular_accounts
                    .with_public_visibility
                    .without_reblogs
                    .without_replies
                    .joins(:account, :status_stat, account: :account_stat)
                    .where(accounts: { suspended_at: nil, spam_flag: nil })
                    .where("status_stats.favourites_count > ?", 5)
                    .where("account_stats.followers_count > ?", 25)
                    .where("statuses.id != ?", @status_id)
                    .where("statuses.id > ?", since)

    # if clicked on status from related, ensure not seeing the same statuses again
    # ...so skip to a random time
    if @max_id.nil?
      limit = 10
      skip = Time.now - rand(1.hour..7.days)
      base_query = base_query.where("statuses.id < ?", GabSocial::Snowflake.id_at(skip))
    end

    if !@group_id.nil?
      # if first load, and has group, only show this group stuff
      if @max_id.nil?
        base_query = base_query.where(group_id: @group_id)
      end
      # else, anything
    end

    base_query = base_query.paginate_by_max_id(limit, @max_id)

    base_query
  end

  def resource_params
		params.permit(:id, :max_id, :since_id)
	end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:limit).permit(:limit).merge(core_params)
  end

  def next_path
    api_v1_timelines_related_url pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v1_timelines_related_url pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end

end
