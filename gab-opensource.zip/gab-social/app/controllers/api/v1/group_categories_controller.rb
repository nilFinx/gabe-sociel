# frozen_string_literal: true

class Api::V1::GroupCategoriesController < EmptyController

  def index
    data = Rails.cache.fetch("v1_group_categories", expires_in: 15.minutes) do
      GroupCategories.all.map { |gc| REST::GroupCategoriesSerializer.new(gc) }
    end
    render json: data.to_json, content_type: 'application/json'
  end

end
