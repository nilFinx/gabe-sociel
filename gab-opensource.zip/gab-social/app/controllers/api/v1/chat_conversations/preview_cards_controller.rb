# frozen_string_literal: true

class Api::V1::ChatConversations::PreviewCardsController < Api::BaseController
  before_action :require_user!
  before_action :set_chat_conversation
  after_action :insert_pagination_headers

  def index
    @preview_cards = load_cards
    render json: @preview_cards, each_serializer: REST::PreviewCardSerializer
  end

  private

  def set_chat_conversation
    # make sure current_account OWNS this chat conversation
    @chat_conversation_account = current_account
      .chat_conversation_accounts
      .where(chat_conversation: params[:chat_conversation_id]).first!
  end

  def load_cards
    return [] if current_account.nil?

    scope = PreviewCard.joins(:chat_messages).where(chat_messages: {
      chat_conversation_id: @chat_conversation_account.chat_conversation_id,
    })

    scope = scope.paginate_by_max_id(
      limit_param(DEFAULT_PREVIEW_CARDS_LIMIT),
      params[:max_id],
      params[:since_id]
    )

    scope
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    if records_continue?
      api_v1_chat_conversation_preview_cards_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    unless @preview_cards.empty?
      api_v1_chat_conversation_preview_cards_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @preview_cards.last.id
  end

  def pagination_since_id
    @preview_cards.first.id
  end

  def records_continue?
    @preview_cards.size == limit_param(DEFAULT_PREVIEW_CARDS_LIMIT)
  end

  def pagination_params(core_params)
    params
      .slice(:limit)
      .permit(:limit)
      .merge(core_params)
  end
end
