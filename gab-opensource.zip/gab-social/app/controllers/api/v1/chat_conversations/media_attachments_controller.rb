# frozen_string_literal: true

class Api::V1::ChatConversations::MediaAttachmentsController < Api::BaseController
  before_action :require_user!
  before_action :set_chat_conversation
  after_action :insert_pagination_headers

  def index
    @media_attachments = load_media

    medias = []

    @media_attachments.each do |media|
      medias << REST::MediaAttachmentSerializer.new(media)
    end

    final = {}
    if !medias.empty?
      final['chat_conversation_id'] = @chat_conversation_account.chat_conversation.id.to_s
      final['media_attachments'] = medias
    end

    return render json: final
  end

  private

  def set_chat_conversation
    # make sure current_account OWNS this chat conversation
    @chat_conversation_account = current_account
      .chat_conversation_accounts
      .where(chat_conversation: params[:chat_conversation_id]).first!
  end

  def load_media
    return [] if current_account.nil?

    scope = MediaAttachment.recent.joins(:chat_messages).where(chat_messages: {
      chat_conversation_id: @chat_conversation_account.chat_conversation_id,
    })
    scope = scope.logged_out_limited if current_account.nil?
    scope = scope.not_pro_limited if current_account && !current_account.is_pro?

    if !query_params[:type].nil? && !query_params[:type].empty?
      if query_params[:type] == 'image' || query_params[:type] == 'video' || query_params[:type] == 'gifv'
        scope = scope.where(type: query_params[:type])
      else
        return render json: { "error": true }, status: 422
      end
    end

    scope = scope.paginate_by_max_id(
      limit_param(DEFAULT_MEDIA_ATTACHMENTS_LIMIT),
      params[:max_id],
      params[:since_id]
    )

    scope
  end
  
  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    if records_continue?
      api_v1_chat_conversation_media_attachments_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    unless @media_attachments.empty?
      api_v1_chat_conversation_media_attachments_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @media_attachments.last.id
  end

  def pagination_since_id
    @media_attachments.first.id
  end

  def records_continue?
    @media_attachments.size == limit_param(DEFAULT_MEDIA_ATTACHMENTS_LIMIT)
  end

  def pagination_params(core_params)
    params
      .slice(:limit, :type)
      .permit(:limit, :type)
      .merge(core_params)
  end

  def query_params
    params.permit(:type, :chat_conversation_id)
  end
end
