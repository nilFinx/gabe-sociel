# frozen_string_literal: true

class Api::V1::BusinessCategoriesController < EmptyController
  include Redisable

  def index
    data = nil
    redis.with do |conn|
      data = conn.get("v1_business_categories")
      if data.blank?
        data = []
        BusinessCategory.ordered.all.each do |bc|
          data << REST::BusinessCategorySerializer.new(bc)
        end
        conn.setex("v1_business_categories", 15.minutes, data.to_json)
      else
        data = JSON.parse(data)
      end
    end
    render json: data.to_json, content_type: 'application/json'
  end

end
