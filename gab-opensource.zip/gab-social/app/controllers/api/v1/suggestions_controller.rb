# frozen_string_literal: true

class Api::V1::SuggestionsController < Api::BaseController
  include Authorization

  # before_action -> { doorkeeper_authorize! :read }

  def index
    type = params[:type]

    if not ['related', 'verified', 'groups', 'feeds', 'tags'].include?(type)
      raise GabSocial::NotPermittedError, %Q|Unknown Type "#{type}"|
    end

    if type == 'related' && !current_account.nil?
      count = truthy_param?(:unlimited) ? PotentialFriendshipTracker::MAX_ITEMS : 10
      @accounts = PotentialFriendshipTracker.get(current_account.id, limit: count)

      return render json: @accounts, each_serializer: REST::AccountSerializer
    elsif type == 'verified'
      @accounts = VerifiedSuggestions.get()
      return render json: @accounts, each_serializer: REST::AccountSerializer
    elsif type == 'groups' && !current_account.nil?
      @groups = GroupSuggestions.get(current_account.id)
      return render json: @groups, each_serializer: REST::GroupSerializer
    elsif type == 'feeds' && !current_account.nil?
      @lists = ListSuggestions.get(current_account.id)
      return render json: @lists, each_serializer: REST::ListSerializer
    elsif type == 'tags' && !current_account.nil?
      @tags = TagSuggestions.get(current_account.id)
      return render json: @tags, each_serializer: REST::TagSerializer
    end

    render json:[], status: 200
  end

  def destroy
    type = params[:type]

    if current_account.nil?
      raise GabSocial::NotPermittedError, "Error. Not allowed"
    end
    if not ['related', 'verified', 'groups', 'feeds', 'tags'].include?(type)
      raise GabSocial::NotPermittedError, %Q|Unknown Type "#{type}"|
    end
    
    if type == 'related' && !current_account.nil?
      PotentialFriendshipTracker.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'groups' && !current_account.nil?
      GroupSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'feeds' && !current_account.nil?
      ListSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    elsif type == 'tags' && !current_account.nil?
      TagSuggestions.remove(current_account.id, params[:id])
      render_empty_success
    else
      render json: { error: true }, status: 422
    end
  end

end
