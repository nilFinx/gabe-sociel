class Api::V1::LocationController < Api::BaseController
  before_action :require_user!
  before_action :rate_limit, only: [:index]

  def index
    q = (params[:q] || "").strip
    query_params = {
      q: q,
      format: 'json'
    }
    
    return render json: {} if q.blank?
    
    url = "https://nominatim.openstreetmap.org/search?q=#{q}&format=json&limit=1&addressdetails=1"
    headers = {
      'User-Agent' => 'local-host-3000'
    }

    data = fetch_data(url, query_params, headers)

    session[:last_request_time] = Time.current
    return render json: data
  end

  private

  def fetch_data(url, params, headers)
    Request.new(:get, url).perform do |res|
      return JSON.parse(res.body)
    end
  end

  def rate_limit
    true
    # if session[:last_request_time] && Time.current - session[:last_request_time] < 5.seconds
    #   render json: { error: 'Rate limit exceeded. Please wait a few seconds before trying again.' }, status: :too_many_requests
    # end
  end
end
