# frozen_string_literal: true

class Api::V1::CallToActionsController < Api::BaseController
  
  def index
    @ctas = Rails.cache.fetch(cta_cache_key, expires_in: 1.hour) do
      if (current_account && current_account.is_pro?) || current_account.nil?
        # Filter out CTAs with 'go-pro' action for pro users
        CallToAction.where.not(primaryBtnAction: 'go-pro')
                    .where.not(secondaryBtnAction: 'go-pro')
                    .order("RANDOM()")
                    .limit(10)
      else
        CallToAction.order("RANDOM()").limit(10)
      end
    end

    render json: @ctas, each_serializer: REST::CallToActionSerializer
  end  

  private

  def cta_cache_key
    # Include pro status in cache key to maintain separate caches
    is_pro = current_account&.is_pro? || false
    "cta_random_set:#{is_pro}"
  end

end
