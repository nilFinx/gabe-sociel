# frozen_string_literal: true

class Api::V1::MarketplaceListingAttributesController < EmptyController
  def index
    render json: MarketplaceListingAttributes::ATTRIBUTES
  end
end