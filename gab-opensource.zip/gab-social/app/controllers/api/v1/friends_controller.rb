# frozen_string_literal: true

class Api::V1::FriendsController < Api::BaseController
  before_action :require_user!, except: [:top]
  before_action :set_account

  def top
    if current_account.nil?
      return not_found
    end

    friends = Friend.where(account: @account).limit(10)
    accounts = friends.map(&:target_account)
    render json: accounts, each_serializer: REST::AccountSerializer
  end

  def add
    FriendAddService.new.call(current_user.account, @account)
    render json: @account, serializer: REST::AccountSerializer
  end

  def remove
    FriendRemoveService.new.call(current_user.account, @account)
    render json: @account, serializer: REST::AccountSerializer
  end

  private

  def set_account
    @account = Account.find(params[:id])
  end

end
