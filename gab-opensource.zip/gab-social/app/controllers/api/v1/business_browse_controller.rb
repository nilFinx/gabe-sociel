# frozen_string_literal: true

class Api::V1::BusinessBrowseController < Api::BaseController
  
  def index
    @listings = load_listings
    render json: @listings
  end

  private

  def load_listings
    excluded_category_ids = parse_exclude_categories(params[:ec])
    categories = fetch_random_categories(excluded_category_ids)
  
    results = categories.each_with_object([]) do |category, array|
      businesses = fetch_businesses_for_category(category.id.to_s)
      next if businesses.empty? # Skip the category if no businesses are found
  
      serialized_listings = businesses.map do |listing|
        REST::BusinessSerializer.new(listing) 
      end
  
      # Extract ids
      business_ids_by_category = businesses.map(&:id).map(&:to_s)
      if business_ids_by_category.any?
        StathouseStatWorker.perform_async('business', business_ids_by_category, 'view', current_account ? current_account.id : nil)
      end
      
      array << {
        category: category,
        listings: serialized_listings
      }
    end
  
    most_recent = fetch_most_recent_deduped_listings
    serialized_most_recent = most_recent.map do |listing|
      REST::BusinessSerializer.new(listing)
    end
      
    # Extract ids
    most_recent_ids = most_recent.map(&:id).map(&:to_s)
    if most_recent_ids.any?
      StathouseStatWorker.perform_async('business', most_recent_ids, 'view', current_account ? current_account.id : nil)
    end

    {
      categories: results,
      recent: serialized_most_recent
    }
  end
  
  private
  
  def parse_exclude_categories(exclude_param)
    return [] unless exclude_param.present?
    exclude_param.split(',').map(&:to_i)
  end
  
  def fetch_random_categories(exclusions = [])
    limit = params[:ec].present? ? 5 : 3
    BusinessCategory.where.not(id: exclusions).order('RANDOM()').limit(limit)
  end
  
  def fetch_businesses_for_category(category_id)
    category_id = "#{category_id}"
    sql = <<-SQL
      SELECT m.*
      FROM businesses m
      JOIN (
        SELECT account_id, MAX(id) AS max_id
        FROM businesses
        WHERE CAST(? AS VARCHAR) = ANY(categories) AND status = 2
        GROUP BY account_id
        ORDER BY random()
        LIMIT 4
      ) subq ON m.account_id = subq.account_id AND m.id = subq.max_id
      WHERE m.status = 2
      ORDER BY random();
    SQL

    Business.find_by_sql([sql, category_id.to_s])
  end
  
  def fetch_most_recent_deduped_listings
    return [] if params[:ec].present?

    sql = <<-SQL
      SELECT m.*
      FROM businesses m
      JOIN (
        SELECT account_id, MAX(id) AS max_id
        FROM businesses
        WHERE status = 2 AND pro_tier <> 0
        GROUP BY account_id
        ORDER BY random()
        LIMIT 4
      ) subq ON m.account_id = subq.account_id AND m.id = subq.max_id
      WHERE m.status = 2 AND m.pro_tier <> 0
      ORDER BY random();
    SQL
  
    Business.find_by_sql(sql)
  end

end
