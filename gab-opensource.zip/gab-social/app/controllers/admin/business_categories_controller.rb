class Admin::BusinessCategoriesController < Admin::BaseController	
	before_action :set_category, except: [:index, :new, :create]

	def index
		@business_categories = BusinessCategory.all

	end

	def new
    # @categories = BusinessCategory.all # for setting parent categories
		@business_category = BusinessCategory.new
	end

	def show
		# 
	end

	def update
		if @business_category.update(resource_params)
			redirect_to admin_business_categories_path, notice: 'Updated'
		else
			render action: :show
		end
	end

	def create
		@business_category = BusinessCategory.new(resource_params)
		
		if @business_category.save
			log_action :create, @business_category
			redirect_to admin_business_categories_path, notice: "Success"
		else
			render :new
		end
	end

	def destroy
		@business_category.destroy!
		log_action :destroy, @business_category
		flash[:notice] = "Deleted"
		redirect_to admin_business_categories_path
	end

	private

	def set_category
		@business_category = BusinessCategory.find(params[:id])
	end

	def resource_params
		params.require(:business_category).permit(:name, :slug, :description)
	end

end
