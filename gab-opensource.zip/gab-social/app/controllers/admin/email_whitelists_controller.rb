class Admin::EmailWhitelistsController < Admin::BaseController
  before_action :set_email_whitelist, only: [:destroy]

  def index
    @email_whitelists = EmailWhitelist.order(created_at: :desc).page(params[:page])
  end

  def new
    @email_whitelist = EmailWhitelist.new
  end

  def create
    @email_whitelist = EmailWhitelist.new(email_whitelist_params)
    @email_whitelist.created_by = current_user

    if @email_whitelist.save
      redirect_to admin_email_whitelists_path, notice: 'Email has been whitelisted successfully'
    else
      render :new
    end
  end

  def destroy
    @email_whitelist.destroy
    redirect_to admin_email_whitelists_path, notice: 'Email has been removed from whitelist'
  end

  private

  def set_email_whitelist
    @email_whitelist = EmailWhitelist.find(params[:id])
  end

  def email_whitelist_params
    params.require(:email_whitelist).permit(:email, :reason)
  end
end
