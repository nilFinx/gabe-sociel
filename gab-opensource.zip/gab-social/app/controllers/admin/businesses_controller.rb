# require 'faker'
# frozen_string_literal: true

module Admin
  class BusinessesController < BaseController
    before_action :set_business, except: [:index, :approve_all]
  
    # mass approve
    # sort/filter by pro/verified accounts created businesses

    def index
      number = 100

      # Assuming you have a BusinessCategory model and an Account model
      # business_categories_ids = BusinessCategory.pluck(:id)
      # account_ids = Account.pluck(:id)

      # number.times do
      #   Business.create!(
      #     name: Faker::Company.name,
      #     tagline: Faker::Company.catch_phrase,
      #     description: Faker::Company.bs,
      #     websites: [Faker::Internet.url],
      #     categories: business_categories_ids.sample(rand(1..3)), # random 1 to 3 category IDs
      #     account_id: account_ids.sample # random account ID
      #   )
      # end

      # Business.transaction do
      #   Business.order('RANDOM()').limit(5).each do |business|
      #     pro_tier = [1, 2, 3].sample # Random pro_tier between 1 and 3
      #     pro_expires_at = Date.today + rand(365..730).days # Random date over a year in the future

      #     business.update(
      #       pro_tier: pro_tier,
      #       pro_expires_at: pro_expires_at,
      #       promotions: [1, 2, 100,200,103,202]
      #     )
      #   end
      # end
        
      authorize :business, :index?
      @businesses = filtered_businesses.page(params[:page])
    end

    def show
      authorize :business, :index?
    end

    def update
      authorize @business, :update?

      # Handle the conversion of the websites string to an array
      websites_array = params[:business][:websites]&.split(',').map(&:strip)
      params[:business][:websites] = websites_array
      
      if @business.update(resource_params)
        if resource_params[:status] == 'approved'
          create_new_business_account_with_owner(@business)
        end

        redirect_to admin_business_path(@business.id), notice: 'Business updated successfully.'
      else
        redirect_to admin_business_path(@business.id), notice: 'Error.'
      end
    end
  
    def destroy
      authorize @business, :destroy?
      @business.destroy!
      log_action :destroy, @business
      flash[:notice] = 'Business destroyed'
      redirect_to admin_businesses_path
    end

    def approve
      @business.update!(status: 2)
      create_new_business_account_with_owner(@business)
      redirect_to admin_business_path(@business.id), notice: 'Successfully approved business'
    end

    def approve_all
      # Select businesses that are not approved, rejected or pro, not new, and not spam or suspended
      businesses_to_approve = Business.includes(:account)
                                     .where(status: 0) # Not already approved, rejected
                                     .where.not(accounts: { is_pro: true }) # Not pro accounts
                                     .where('accounts.created_at <= ?', 14.days.ago) # Exclude new accounts
                                     .where(accounts: { spam_flag: nil, suspended_at: nil }) # Exclude spam/suspended
    
      # Update each selected business
      businesses_to_approve.find_each do |business|
        business.update!(status: 2)
        create_new_business_account_with_owner(business)
      end
    
      # Redirect to a relevant path with a success message
      redirect_to admin_businesses_path, notice: 'Successfully approved all eligible businesses'
    end

    def edit
      # 
    end
  
    def remove_business_avatar
      authorize @business, :remove_business_avatar?

      @business.avatar = nil
      @business.avatar_cdn_url = nil
      @business.save!

      redirect_to admin_business_path(@business.id), notice: 'Successfully removed avatar'
    end

    def update_business_avatar
      authorize @business, :update?

      if @business.update(avatar_params)
        @business.update(avatar_cdn_url: bunny_url_by_object(@business, @business.avatar, "avatar"))
        redirect_to admin_business_path(@business.id), notice: 'Avatar updated successfully.'
      else
        redirect_to admin_business_path(@business.id), notice: 'Error.'
      end
    end

    def remove_business_cover
      authorize @business, :remove_business_avatar?

      @business.cover = nil
      @business.cover_cdn_url = nil
      @business.save!

      redirect_to admin_business_path(@business.id), notice: 'Successfully removed cover'
    end

    def update_business_cover
      authorize @business, :update?

      if @business.update(cover_params)
        @business.update(cover_cdn_url: bunny_url_by_object(@business, @business.cover, "cover"))
        redirect_to admin_business_path(@business.id), notice: 'Cover updated successfully.'
      else
        redirect_to admin_business_path(@business.id), notice: 'Error.'
      end
    end

    def update_cta
      authorize @business, :update?

      if @business.update(cta_params)
        redirect_to admin_business_path(@business.id),  notice: 'CTA updated successfully.'
      else
        redirect_to admin_business_path(@business.id), notice: 'Error.'
      end
    end

    def update_pro
      authorize @business, :update?
      # Make sure business_params is not nil before processing
      if params[:nothing].present?
        pro_tier = process_pro_tier(params[:nothing])

        if @business.update(pro_tier: pro_tier, pro_expires_at: params[:nothing][:pro_expires_at])
          redirect_to admin_business_path(@business), notice: 'Pro information updated successfully.'
        else
          redirect_to admin_business_path(@business.id), notice: 'Error updating Pro information.'
        end
      else
        redirect_to admin_business_path(@business.id), notice: 'No parameters provided for Pro update.'
      end
    end

    def update_promotion
      authorize @business, :update?
    
      # Convert the promotion_ids from the form into an array of integers
      # Assuming the checkboxes are named `business[promotion_ids][]` in the form
      promotion_ids = params[:business] ? (params[:business][:promotion_ids] || []).map(&:to_i) : []
    
      # Update the promotions for the business
      if @business.update(promotions: promotion_ids)
        redirect_to admin_business_path(@business), notice: 'Promotions updated successfully.'
      else
        render :edit, alert: 'Error updating promotions.'
      end
    end    
    
    private
  
    def set_business
      @business = Business.find(params[:id])
    end
  
    def resource_params
      params.require(:business).permit(
        :name, :tagline, :description, :status, :pro_tier, { websites: [] }
      )
    end
  
    def filtered_businesses
      BusinessFilter.new(filter_params).results
    end

    def filter_params
      params.permit(
        :name,
        :title,
        :id,
        :status,
        :tier,
        :pro_tier,
        :account_id,
        :by_spam,
        :by_pro,
        :by_new,
        :sort,
      )
    end

    def avatar_params
      params.require(:business).permit(:avatar)
    end

    def cover_params
      params.require(:business).permit(:cover)
    end

    def cta_params
      params.require(:business).permit(cta: [:title, :link])
    end

    def create_new_business_account_with_owner(business) 
      # Check if the business account relationship already exists
      unless BusinessAccount.exists?(account_id: business.account.id, business_id: business.id)
        # Create a new BusinessAccount relationship for this approval
        BusinessAccount.create!(account_id: business.account.id, business_id: business.id, title: 'Owner', role: BusinessAccount.roles[:owner], visibility: BusinessAccount.visibilities[:private])
      end
    end

    def process_pro_tier(business_params)
      # Check if business_params is not nil
      return {} unless business_params

      pro_tier = if business_params[:gold_tier] != "0"
                  :gold
                elsif business_params[:silver_tier] != "0"
                  :silver
                elsif business_params[:bronze_tier] != "0"
                  :bronze
                else
                  :none
                end

      pro_tier
    end

  end
end
  