class Admin::CallToActionsController < Admin::BaseController	
	before_action :set_cta, except: [:index, :new, :create]

	def index
		@ctas = CallToAction.all
	end

	def new
		@cta = CallToAction.new
	end

	def show
		# 
	end

	def update
		if @cta.update(resource_params)
			redirect_to admin_call_to_actions_path, notice: 'Updated'
		else
			render action: :show
		end
	end

	def create
		@cta = CallToAction.new(resource_params)
		
		if @cta.save
			redirect_to admin_call_to_actions_path, notice: "Success"
		else
			render :new
		end
	end

	def destroy
		@cta.destroy!
		flash[:notice] = "Deleted"
		redirect_to admin_call_to_actions_path
	end

	private

	def set_cta
		@cta = CallToAction.find(params[:id])
	end

	def resource_params
		params.require(:call_to_action).permit(:title, :key, :content, :primaryBtnTitle, :primaryBtnAction, :secondaryBtnTitle, :secondaryBtnAction)
	end

end
