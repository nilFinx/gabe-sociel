# frozen_string_literal: true

module Admin
  class RemovedByGroupsController < BaseController
    before_action :set_account

    PER_PAGE = 25

    def index
      authorize :account, :index?
      # @groups = @group_removed_accounts.includes(:group).map(&:group).uniq

      @group_removed_accounts = @account.group_removed_accounts.page(params[:page]).per(PER_PAGE)
      @group_ids = @group_removed_accounts.includes(:group).map(&:group_id)
      @groups = Group.where(id: @group_ids)
    end

    def set_account
      @account = Account.find(params[:account_id])
    end
  end
end
