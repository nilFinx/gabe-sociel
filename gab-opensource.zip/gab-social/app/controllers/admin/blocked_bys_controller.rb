# frozen_string_literal: true

module Admin
  class BlockedBysController < BaseController
    before_action :set_account

    PER_PAGE = 25

    def index
      authorize :account, :index?
      @blocked_by = @account.blocked_by.local.recent.page(params[:page]).per(PER_PAGE)
    end

    def set_account
      @account = Account.find(params[:account_id])
    end
  end
end
