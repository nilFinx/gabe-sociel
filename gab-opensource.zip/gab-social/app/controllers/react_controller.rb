# frozen_string_literal: true

class ReactController < ApplicationController
  include Authorization

  before_action :authenticate_user!, only: [:react, :home]

  before_action :set_account, only: [:status_embed, :status_show, :account_show]
  before_action :set_status, only: [:status_embed, :status_show]
  before_action :check_account_suspension, only: [:status_embed, :status_show, :account_show]
  before_action :redirect_to_original, only: [:status_show]

  before_action :set_referrer_policy_header, only: [:react, :home, :status_embed, :status_show, :account_show]
  before_action :set_initial_state_json, only: [:react, :home, :status_embed, :status_show, :account_show]
  before_action :set_data_for_meta, only: [:react, :status_embed, :status_show, :account_show, :group_show]

  before_action :set_instance_presenter

  after_action :consider_recalculating, only: [:react]

  def react
    #
  end

  def groupBySlug
    @group = Group.where(slug: params[:groupSlug], is_archived: false).first
    unless @group.nil?
      return redirect_to "/groups/#{@group.id}"
    end

    return not_found
  end

  def feedBySlug
    # NOTE: at the moment, only an admin can create a list with a custom slug
    # and a list the uses a slug uses the singular version of GAB.COM/FEED/SLUG
    # instead of the plural version of GAB.COM/FEEDS/ID when using ids
    @list = List.where(slug: params[:listSlug]).public_only.first
    unless @list.nil?
      return redirect_to "/feeds/#{@list.id}"
    end

    return not_found
  end

  def status_show
    render 'react'
  end

  def status_embed
    # : todo :
  end

  def account_show
    render 'react'
  end

  private

  def set_account
    @account = Account.find_acct!(params[:username])
  end

  def set_status
    @status = @account.statuses.find(params[:statusId])
    if (@status.nil? || @status.proper.nil?)
      raise ActiveRecord::RecordNotFound
    end

    authorize @status, :show?
  rescue GabSocial::NotPermittedError
    # Reraise in order to get a 404
    raise ActiveRecord::RecordNotFound
  end

  def check_account_suspension
    gone if @account.suspended?
  end

  def redirect_to_original
    if @status.reblog?
      if !@status.proper.nil?
        redirect_to ::TagManager.instance.url_for(@status.reblog)
      else
        raise ActiveRecord::RecordNotFound
      end
    end
  end

  def set_data_for_meta
    return if find_route_matches && current_account

    base_title = "Gab.com"
    base_description = "The Home of Free Speech and the Parallel Economy. Join our community where people who support family, faith and free speech can speak freely and shop at businesses who share their values."
    
    @isPro = !current_account.nil? && current_account.is_pro

    if request.path == '/'
      @actual_meta_title = base_title
      @actual_meta_description = base_description

    elsif request.path == '/groups'
      @actual_meta_title = 'Groups - Explore and Join - ' + base_title
      @actual_meta_description = 'Discover various groups that align with your interests and values. ' + base_description

    elsif request.path == '/groups/browse/member'
      @actual_meta_title = 'Member Groups Directory - ' + base_title
      @actual_meta_description = 'Browse groups managed by our community members. ' + base_description
      
    elsif request.path == '/groups/browse/featured'
      @actual_meta_title = 'Featured Groups - ' + base_title
      @actual_meta_description = 'Dive into the groups that are making waves in our community. ' + base_description

    elsif request.path == '/groups/browse/categories'
      @actual_meta_title = 'Group Categories - ' + base_title
      @actual_meta_description = 'Navigate groups by categories to find your perfect fit. ' + base_description
    
    elsif request.path == '/news'
      @actual_meta_title = 'Latest News and Updates - ' + base_title
      @actual_meta_description = 'Stay informed with the latest news and updates. ' + base_description

    elsif request.path == '/timeline/pro'
      @actual_meta_title = 'Pro Timeline - ' + base_title
      @actual_meta_description = 'Discover the GabPRO timeline with posts from our community. ' + base_description

    elsif request.path == '/timeline/polls'
      @actual_meta_title = 'Community Polls - ' + base_title
      @actual_meta_description = 'Engage in polls and voice your opinion on various topics. ' + base_description

    elsif request.path == '/timeline/links'
      @actual_meta_title = 'Shared Links - ' + base_title
      @actual_meta_description = 'Explore the most shared and trending links in our community. ' + base_description

    elsif request.path == '/timeline/videos'
      @actual_meta_title = 'Community Videos - ' + base_title
      @actual_meta_description = 'Watch and share videos that resonate with your values and interests. ' + base_description

    elsif request.path == '/timeline/clips'
      @actual_meta_title = 'Featured Clips - ' + base_title
      @actual_meta_description = 'Catch up on short clips that are trending within our community. ' + base_description

    elsif request.path == '/timeline/photos'
      @actual_meta_title = 'Photo Galleries - ' + base_title
      @actual_meta_description = 'Browse through amazing photos shared by our community. ' + base_description

    elsif request.path == '/marketplace'
      @actual_meta_title = 'Marketplace - ' + base_title
      @actual_meta_description = 'Shop and support businesses that align with your values. ' + base_description

    elsif request.path == '/marketplace/categories'
      @actual_meta_title = 'Marketplace Categories - ' + base_title
      @actual_meta_description = 'Browse our marketplace by categories to find products and services of your interest. ' + base_description

    elsif request.path == '/marketplace/listings'
      @actual_meta_title = 'Latest Listings - ' + base_title
      @actual_meta_description = 'Explore the newest listings in our marketplace. ' + base_description

    elsif request.path == '/marketplace/business/join'
      @actual_meta_title = 'Boost Your Business in the Parallel Economy with Gab!'
      @actual_meta_description = "List your Business in the Parallel Economy! Gab has a community of people who support family, faith and free speech. Connect with customers who share your values and enhance your online visibility."
    
    elsif request.path.match(/^\/groups/)
      groupIdFromPath = request.path.sub("/groups", "").gsub("/", "")
      @group = Group.where(id: groupIdFromPath, is_archived: false).first
    elsif request.path.match(/^\/feeds/)
      listIdFromPath = request.path.sub("/feeds", "").gsub("/", "")
      @list = List.public_only.where(id: listIdFromPath).first
    elsif request.path.match(/^\/marketplace\/item/)
      listingIdFromPath = request.path.sub("/marketplace/item", "").gsub("/", "")
      @marketplace_listing = MarketplaceListing.only_running.where(id: listingIdFromPath).first
    elsif request.path.match(/^\/business/)
      businessIdFromPath = request.path.sub("/business", "").gsub("/", "")
      @business = Business.where(id: businessIdFromPath).is_approved.first
    elsif request.path.match(/^\/tags/)
      tagNameFromPath = request.path.sub("/tag", "").gsub("/", "")
      @actual_meta_title = "Hashtag Timeline - ##{tagNameFromPath} - " + base_title
      @actual_meta_description = 'Discover content and discussions based on specific tags. ' + base_description
    elsif request.path.start_with?('/marketplace/listings/')
      slug = request.path.split('/').last
      if slug.present?
        # : todo : find category with slug and use pretty name
        @actual_meta_title = "Marketplace - #{slug.capitalize} - " + base_title
        @actual_meta_description = "Browse our marketplace for the best deals on #{slug}. " + base_description
      else
        @actual_meta_title = 'Marketplace Listings - ' + base_title
        @actual_meta_description = 'Browse our marketplace for the best deals. ' + base_description
      end
    elsif find_public_route_matches
      return
    elsif request.path.count("/") == 1 && request.path.length === 1
      #
    elsif request.path.count("/") == 1 && !request.path.include?("@")
      acctFromPath = request.path.sub("/", "")
      @account = Account.find_local!(acctFromPath)
    end
  end

  def authenticate_user!
    return if user_signed_in?
    if find_public_route_matches
      return
    elsif find_route_matches
      # if no current user, dont allow to navigate to these paths
      redirect_to(homepage_path)
    end

    return false
  end

  def find_route_matches
    request.path.match(/\A\/(businesses|business|watch|home|news|timeline|api|deck|suggestions|links|chat_conversations|chat_conversation_accounts|messages|shortcuts|list|lists|notifications|tags|compose|follow_requests|admin|account|settings|filters|timeline|blocks|mutes|warnings)/)
  end

  def find_public_route_matches
    request.path.match(/\A\/(about|news|search|group|groups|explore|feeds|marketplace|timeline|businesses|business)/)
  end

  def set_initial_state_json
    initial_state = InitialStatePresenter.new(initial_state_params)
    serializable_resource = InitialStateSerializer.new(initial_state)

    @initial_state_json = serializable_resource.to_json
    temp_data = JSON.parse(@initial_state_json)
    temp_data["country_code"] = request.headers["CF-IPCountry"]
    @initial_state_json = temp_data.to_json
  end

  def initial_state_params
    if !current_user.nil? && !current_session.nil?
      {
        settings: Web::Setting.find_by(user: current_user)&.data || {},
        push_subscription: current_account.user.web_push_subscription(current_session),
        current_account: current_account,
        token: current_session.token,
      }
    else
      return {}
    end
  end

  def set_referrer_policy_header
    response.headers['Referrer-Policy'] = 'origin'
  end

  def set_instance_presenter
    @instance_presenter = InstancePresenter.new
  end

  def consider_recalculating
    if request.path.match(/^\/home/) || request.path.match(/^\//)
      return if current_account.nil?
      Rails.cache.fetch("recalc:#{Time.current.strftime('%Y%m%d')}:#{current_account.id}", expires_in: 1.day) do
        RecalculateAccountStatsWorker.perform_async(current_account.id)
        true
      end
    end
  end
end
