# frozen_string_literal: true

class Settings::AiAgentsController < Settings::BaseController
  layout 'admin'

  before_action :authenticate_user!
  before_action :require_admin!
  before_action :set_ai_agent, only: [:show, :update, :destroy]

  def index
    @ai_agents = AiAgent.order(id: :desc).page(params[:page])
  end

  def new
    @ai_agent = AiAgent.new
  end

  def show
    #
  end

  def create
    ai_agent_params = { :name => params[:ai_agent][:name], 
      :model_code => params[:ai_agent][:model_code],
      :type => params[:ai_agent][:type],
      :account_id => params[:ai_agent][:account_id],
      :endpoint => params[:ai_agent][:endpoint],
      :active => params[:ai_agent][:active],
      :system => params[:ai_agent][:system],
      :data => params[:ai_agent][:data],
    }
    puts ai_agent_params.inspect
    @ai_agent = AiAgent.new(ai_agent_params)

    if @ai_agent.save
      redirect_to settings_ai_agents_path, notice: 'Ai Agent created'
    else
      render :new
    end
  end

  def update
    ai_agent_params = { :name => params[:ai_agent][:name], 
      :model_code => params[:ai_agent][:model_code],
      :type => params[:ai_agent][:type],
      :account_id => params[:ai_agent][:account_id],
      :endpoint => params[:ai_agent][:endpoint],
      :active => params[:ai_agent][:active],
      :system => params[:ai_agent][:system],
      :data => params[:ai_agent][:data],
    }
    if @ai_agent.update(ai_agent_params)
      redirect_to settings_ai_agents_path, notice: I18n.t('generic.changes_saved_msg')
    else
      render :show
    end
  end

  private

  def set_ai_agent
    @ai_agent = AiAgent.find(params[:id])
  end

end
