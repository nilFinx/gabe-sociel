# frozen_string_literal: true

class Settings::NotificationsController < Settings::BaseController
  layout 'admin'

  before_action :authenticate_user!

  def show
    campaign_param = params[:c]
    valid_values = ['dr', 'pe', 'rep', 'iai', 'ip']
    if valid_values.include?(campaign_param)
      @campaign_param_id = campaign_param
    end
  end

  def update
    campaign_param = params[:c]

    user_settings.update(user_settings_params.to_h)

    if current_user.save
      if campaign_param.present?
        redirect_to settings_notifications_path(c: campaign_param), notice: I18n.t('generic.changes_saved_msg')
      else
        redirect_to settings_notifications_path, notice: I18n.t('generic.changes_saved_msg')
      end
    else
      render :show
    end
  end

  private

  def user_settings
    UserSettingsDecorator.new(current_user)
  end

  def user_settings_params
    params.require(:user).permit(
      notification_emails: %i(follow follow_request reblog favourite mention digest report pro_reminder donate_reminder ai_reminder emails_from_gabcom),
      interactions: %i(must_be_follower must_be_following must_be_following_dm)
    )
  end
end
