# frozen_string_literal: true

class Settings::ChatbotsController < Settings::BaseController
  layout 'admin'

  before_action :authenticate_user!
  before_action :require_admin!
  before_action :set_chatbot, only: [:show, :update, :destroy]

  def index
    @chatbots = Chatbot.order(id: :desc).page(params[:page])
  end

  def new
    @chatbot = Chatbot.new
  end

  def show
    #
  end

  def create
    chatbot_params = { :name => params[:chatbot][:name], 
      :endpoint => params[:chatbot][:endpoint], 
      :token => params[:chatbot][:token],
      :account_id => params[:chatbot][:account_id] 
    }
    puts chatbot_params.inspect
    @chatbot = Chatbot.new(chatbot_params)

    if @chatbot.save
      redirect_to settings_chatbots_path, notice: 'Chatbot created'
    else
      render :new
    end
  end

  def update
    chatbot_params = { :name => params[:chatbot][:name], 
      :endpoint => params[:chatbot][:endpoint], 
      :token => params[:chatbot][:token],
      :account_id => params[:chatbot][:account_id] 
    }
    if @chatbot.update(chatbot_params)
      redirect_to settings_chatbots_path, notice: I18n.t('generic.changes_saved_msg')
    else
      render :show
    end
  end

  private

  def set_chatbot
    @chatbot = Chatbot.find(params[:id])
  end

end
